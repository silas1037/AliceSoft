// Test.h

#ifndef __TEST_H__
#define __TEST_H__

#define DLLEXPORT __declspec(dllexport)

typedef unsigned short* pword;

class IString;
class ISys3xDIB;
class IWinMsg;
class ITimer;
class IUI;
class ISys3xCG;
class ISys3xStringTable;
class IDrawText;
class ISys3xMsgBuf;
class ISys3xSystem;

extern "C" {
	DLLEXPORT void	Test(void);
	DLLEXPORT void	Test2(int a);
	DLLEXPORT void	Test3(int a, int b);
	DLLEXPORT void	Test4(pword pTest, pword pW2, IString* ret);
	DLLEXPORT void	CrossFade(ISys3xDIB* IDIB, int nTime);
	DLLEXPORT void	CrossEddy(ISys3xDIB* IDIB, int nTime);
}

#endif // __TEST_H__

