///////////////////////////////////////////////////////////////////////////////
//  CreateInterface.h
//  Coder.Yudai Senoo :-)

#ifndef __CREATEINTERFACE_H__
#define __CREATEINTERFACE_H__

#include <objbase.h>

#define DLLEXPORT __declspec(dllexport)

class IInterface;
extern "C" {
	DLLEXPORT IInterface*	CreateInterface(const GUID* pGuid);
}

#endif // __CREATEINTERFACE_H__

