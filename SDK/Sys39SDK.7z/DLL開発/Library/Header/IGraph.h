///////////////////////////////////////////////////////////////////////////////
//  IGraph.h
//  Coder.Yudai Senoo :-)

#ifndef __IGRAPH_H__
#define __IGRAPH_H__

#include "IInterface.h"

class ISurface;
struct IGraph : public IInterface {
	virtual bool	Init(void) = 0;					// ������

	virtual void	SetUseCPUEx(bool bUse) = 0;		// �b�o�t�g�����߂��g�p���邩�ǂ����̃t���O�ݒ�

	virtual void	Copy(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;
	virtual void	CopyAlphaMap(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;

	virtual void	CopyBright(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nRate) = 0;

	// ���l�Q�ƃu�����h
	virtual void	Blend(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nAlpha) = 0;
	virtual void	BlendSrcBright(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nAlpha, int nRate) = 0;
	virtual void	BlendAddSatur(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;

	// ���}�b�v�Q�ƃu�����h
	virtual void	BlendAlphaMap(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;													// DestPixel = Blend(DestPixel, SrcPixel, SrcAlphaMap)
	virtual void	BlendAlphaMapSrcOnly(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;											// DestPixel = Satur(DestPixel + Src x AlphaMap)
	virtual void	BlendAlphaMapColor(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nR, int nG, int nB) = 0;						// DestPixel = Blend(DestPixel, Color, SrcAlphaMap)
	virtual void	BlendAlphaMapColorAlpha(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nR, int nG, int nB, int nAlpha) = 0;	// DestPixel = Blend(DestPixel, Color, SrcAlphaMap x nAlpha)
	virtual void	BlendAlphaMapAlpha(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nAlpha) = 0;									// DestPixel = Blend(DestPixel, SrcPixel, SrcAlphaMap x nAlpha)
	virtual void	BlendAlphaMapBright(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nRate) = 0;									// DestPixel = Blend(DestPixel, SrcPixel x nRate, SrcAlphaMap)
	virtual void	BlendAlphaMapAlphaSrcBright(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nAlpha, int nRate) = 0;				// DestPixel = Blend(DestPixel, SrcPixel x nRate, SrcAlphaMap x nAlpha)

	virtual void	BlendUseAMapColor(ISurface* pDestSurface, int nDx, int nDy, int nWidth, int nHeight, ISurface* pAlphaSurface, int nAx, int nAy, int nR, int nG, int nB, int nAlpha) = 0;

	// �t�H�g�V���b�v�t�B���^
	virtual void	BlendScreen(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;	// �t�H�g�V���b�v�t�B���^�F�X�N���[��
	virtual void	BlendMultiply(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;	// �t�H�g�V���b�v�t�B���^�F��Z

	virtual void	BlendScreenAlpha(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight, int nAlpha) = 0;	// �t�H�g�V���b�v�t�B���^�F�X�N���[���w��

	// �h��Ԃ�
	virtual void	Fill(ISurface* pSurface, int nX, int nY, int nWidth, int nHeight, int nR, int nG, int nB) = 0;
	virtual void	FillAlphaMap(ISurface* pSurface, int nX, int nY, int nWidth, int nHeight, int nAlpha) = 0;
	virtual void	FillAlphaColor(ISurface* pSurface, int nX, int nY, int nWidth, int nHeight, int nR, int nG, int nB, int nRate) = 0;

	virtual void	SaturDP_DPxSA(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;		// DestPixel = Satur(DestPixel + SrcAlpha)

	// �������w��
	virtual void	ScreenDA_DAxSA(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;		// DestAlpha = Screen(DestAlpha, SrcAlpha)
	virtual void	AddDA_DAxSA(ISurface* pDestSurface, int nDx, int nDy, ISurface* pSrcSurface, int nSx, int nSy, int nWidth, int nHeight) = 0;		// DestAlpha = Satur(DestAlpha + SrcAlpha)

	// ��`����
	virtual void	BrightDestOnly(ISurface* pSurface, int nX, int nY, int nWidth, int nHeight, int nRate) = 0;

	// �e�N�X�`�����b�v
	virtual void	CopyTextureWrap(ISurface* pDestSurface, int nDx, int nDy, int nDWidth, int nDHeight, ISurface* pSrcSurface, int nSx, int nSy, int nSWidth, int nSHeight, int nU, int nV) = 0;
	virtual void	CopyTextureWrapAlpha(ISurface* pDestSurface, int nDx, int nDy, int nDWidth, int nDHeight, ISurface* pSrcSurface, int nSx, int nSy, int nSWidth, int nSHeight, int nU, int nV, int nAlpha) = 0;

	// �g��k��
	virtual void	CopyStretch(ISurface* pSurface, int nDx, int nDy, int nDWidth, int nDHeight, ISurface* pSrcSurface, float fSx, float fSy, float fSWidth, float fSHeight) = 0;
	virtual void	CopyStretchBlend(ISurface* pSurface, int nDx, int nDy, int nDWidth, int nDHeight, ISurface* pSrcSurface, float fSx, float fSy, float fSWidth, float fSHeight, int nAlpha) = 0;
	virtual void	CopyStretchBlendAlphaMap(ISurface* pSurface, int nDx, int nDy, int nDWidth, int nDHeight, ISurface* pSrcSurface, float fSx, float fSy, float fSWidth, float fSHeight) = 0;

};

#endif // __IGRAPH_H__

