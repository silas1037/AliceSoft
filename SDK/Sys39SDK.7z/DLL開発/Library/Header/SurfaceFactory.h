///////////////////////////////////////////////////////////////////////////////
//  SurfaceFactory.h
//  Coder.Yudai Senoo :-)

#ifndef __SURFACEFACTORY_H__
#define __SURFACEFACTORY_H__

#include <objbase.h>
#include "ISurfaceFactory.h"

// {D6433348-4DB3-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_ISurfaceFactory = 
{ 0xd6433348, 0x4db3, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

// AddRef()�ɂ��Q�ƃJ�E���^�����삷��o�[�W����
// {65C9F15F-260C-474e-8712-F6990745B61F}
static const GUID IID_ISurfaceFactory_RefCounter = 
{ 0x65c9f15f, 0x260c, 0x474e, { 0x87, 0x12, 0xf6, 0x99, 0x7, 0x45, 0xb6, 0x1f } };

#endif // __SURFACEFACTORY_H__

