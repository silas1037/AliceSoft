///////////////////////////////////////////////////////////////////////////////
//  DrawText.h
//  Coder.Yudai Senoo :-)

#ifndef __DRAWTEXT_H__
#define __DRAWTEXT_H__

#include <objbase.h>
#include "IDrawText.h"

// {EF3C3E60-572B-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_IDrawText = 
{ 0xef3c3e60, 0x572b, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

#endif // __DRAWTEXT_H__

