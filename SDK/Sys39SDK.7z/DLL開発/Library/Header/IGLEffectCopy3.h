///////////////////////////////////////////////////////////////////////////////
//  DefClass.h
//  Coder.Yudai Senoo :-)

#ifndef __IGLEffectCopy3_H__
#define __IGLEffectCopy3_H__

#include "IGLEffectCopy.h"

struct ISys3x;
struct IGLEffectCopy3 : public IGLEffectCopy {
	virtual void	SetISys3x(ISys3x* pISys3x) = 0;
};

#endif // __IGLEffectCopy3_H__

