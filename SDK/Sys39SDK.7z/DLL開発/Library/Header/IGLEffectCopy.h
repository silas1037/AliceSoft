///////////////////////////////////////////////////////////////////////////////
//  IGLEffectCopy.h
//  Coder.Yudai Senoo :-)

#ifndef __IGLEFFECTCOPY_H__
#define __IGLEFFECTCOPY_H__

#include "IInterface.h"

class IWinMsg;
struct ICheckClick;
class ITimer;
class ISys3xDIB;
class ISurface;
struct IGLEffectCopy : public IInterface {
	// �C���^�[�t�F�C�X�̐ݒ�
	virtual void	SetIWinMsg(IWinMsg* pIWinMsg) = 0;
	virtual void	SetICheckClick(ICheckClick* pICheckClick) = 0;
	virtual void	SetITimer(ITimer* pITimer) = 0;

	virtual bool	Effect(int nEffect,
		ISys3xDIB* pWriteSurface, int nWx, int nWy,
		ISurface* pDestSurface, int nDx, int nDy,
		ISurface* pSrcSurface, int nSx, int nSy,
		int nWidth, int nHeight,
		unsigned int unTotalTime,
		unsigned int* punEndType) = 0;
	// �߂�l == false                     : WinMsg�ɂ��I��
	// �߂�l == true && *punEndType == -1 : nEffect������łȂ��ꍇ
	// �߂�l == true && *punEndType ==  0 : ����I��
	// �߂�l == true && *punEndType ==  1 : �L�[�����ɂ��I��

};

#endif // __IGLEFFECTCOPY_H__

