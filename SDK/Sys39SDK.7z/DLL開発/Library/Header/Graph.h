///////////////////////////////////////////////////////////////////////////////
//  Graph.h
//  Coder.Yudai Senoo :-)

#ifndef __GRAPH_H__
#define __GRAPH_H__

#include <objbase.h>
#include "IGraph.h"

// {58AD7D01-4DAE-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_IGraph = 
{ 0x58ad7d01, 0x4dae, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

#endif // __GRAPH_H__

