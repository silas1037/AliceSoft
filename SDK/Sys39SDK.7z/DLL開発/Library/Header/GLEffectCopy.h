///////////////////////////////////////////////////////////////////////////////
//  GLEffectCopy.h
//  Coder.Yudai Senoo :-)

#ifndef __GLEFFECTCOPY_H__
#define __GLEFFECTCOPY_H__

#include <objbase.h>
#include "IGLEffectCopy.h"

// {F9B66380-84D4-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_IGLEffectCopy =
{ 0xf9b66380, 0x84d4, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

// {AC5F0925-9D0E-4e48-99F6-D0ECA6CC34FF}
static const GUID IID_IGLEffectCopy2 = 
{ 0xac5f0925, 0x9d0e, 0x4e48, { 0x99, 0xf6, 0xd0, 0xec, 0xa6, 0xcc, 0x34, 0xff } };

// {0B53D5BC-EAB9-43c9-9487-BE0654D8FAEF}
static const GUID IID_IGLEffectCopy3 = 
{ 0xb53d5bc, 0xeab9, 0x43c9, { 0x94, 0x87, 0xbe, 0x6, 0x54, 0xd8, 0xfa, 0xef } };

#endif // __GLEFFECTCOPY_H__

