///////////////////////////////////////////////////////////////////////////////
//  IGraph2.h
//  Coder.Yudai Senoo :-)

#ifndef __IGRAPH2_H__
#define __IGRAPH2_H__

#include "IGraph.h"

struct ISys3x;
struct IGraph2 : public IGraph {
	virtual void	SetISys3x(ISys3x* pISys3x) = 0;
};

#endif // __IGRAPH2_H__

