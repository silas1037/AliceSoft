///////////////////////////////////////////////////////////////////////////////
//  FileControl.h
//  Coder.Yudai Senoo :-)

#ifndef __FILECONTROL_H__
#define __FILECONTROL_H__

#include <objbase.h>
#include "IReadFile.h"
#include "IWriteFile.h"

// {2E45D500-C5E8-11d4-ACBF-00C0F6B0E9BE}
static const GUID IID_IReadFile = 
{ 0x2e45d500, 0xc5e8, 0x11d4, { 0xac, 0xbf, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

// {16BCB8C0-C5E0-11d4-ACBF-00C0F6B0E9BE}
static const GUID IID_IWriteFile = 
{ 0x16bcb8c0, 0xc5e0, 0x11d4, { 0xac, 0xbf, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

#endif // __FILECONTROL_H__

