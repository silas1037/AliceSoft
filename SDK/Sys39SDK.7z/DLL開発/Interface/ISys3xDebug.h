///////////////////////////////////////////////////////////////////////////////
//  ISys3xDebug.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XDEBUG_H__
#define __ISYS3XDEBUG_H__

#include <objbase.h>

struct ISys3xDebug {
	virtual void*	GetHWND(void) = 0;

	virtual void*	GetInterface(const GUID* pGuid) = 0;
};

#endif // __ISYS3XDEBUG_H__

