///////////////////////////////////////////////////////////////////////////////
//  Sys3xDebug.h
//  Coder.Yudai Senoo :-)

#ifndef __SYS3XDEBUG_H__
#define __SYS3XDEBUG_H__

#include <objbase.h>

// {C46F9063-66D5-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_ISys3xTrace = 
{ 0xc46f9063, 0x66d5, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

// {1EBF8981-66E5-11d4-BEB2-00C0F6B0E9BE}
static const GUID IID_ISys3xTraceControl = 
{ 0x1ebf8981, 0x66e5, 0x11d4, { 0xbe, 0xb2, 0x0, 0xc0, 0xf6, 0xb0, 0xe9, 0xbe } };

// {01903B75-78F8-487b-9757-A948BD09D24A}
static const GUID IID_ISys3xTraceCallStack = 
{ 0x1903b75, 0x78f8, 0x487b, { 0x97, 0x57, 0xa9, 0x48, 0xbd, 0x9, 0xd2, 0x4a } };

#endif // __SYS3XDEBUG_H__

