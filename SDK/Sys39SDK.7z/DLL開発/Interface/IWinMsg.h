///////////////////////////////////////////////////////////////////////////////
//  IWinMsg.h
//  Coder.Yudai Senoo :-)

#ifndef __IWINMSG_H__
#define __IWINMSG_H__

class IWinMsg {
public:
	virtual bool	Peek(void) = 0;		// ���b�Z�[�W�s�[�N
};

#endif // __IWINMSG_H__

