///////////////////////////////////////////////////////////////////////////////
//  ISys3xTrace.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XTRACE_H__
#define __ISYS3XTRACE_H__

#include "windows.h"

struct ISys3xTrace {
	virtual bool	GetAddr(int* pnFileNum, unsigned int* punAddr) = 0;
};

#endif // __ISYS3XTRACE_H__

