///////////////////////////////////////////////////////////////////////////////
//  IMusicLoader.h
//  Coder.Yudai Senoo :-)

#ifndef __IMUSICLOADER_H__
#define __IMUSICLOADER_H__

struct IMusicLoader {
	virtual bool	Load(void* pvData) = 0;		// ���������璼�ڃ��[�h
};

#endif // __IMUSICLOADER_H__

