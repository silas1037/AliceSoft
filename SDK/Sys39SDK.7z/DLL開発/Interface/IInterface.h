///////////////////////////////////////////////////////////////////////////////
//  IInterface.h
//  Coder.Yudai Senoo :-)

#ifndef __IINTERFACE_H__
#define __IINTERFACE_H__

class IInterface {
public:
	virtual int		AddRef(void) = 0;
	virtual int		Release(void) = 0;					// ���
};

#endif // __IINTERFACE_H__

