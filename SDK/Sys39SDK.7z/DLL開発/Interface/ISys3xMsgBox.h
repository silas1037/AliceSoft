///////////////////////////////////////////////////////////////////////////////
//  ISys3xMsgBox.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XMSGBOX_H__
#define __ISYS3XMSGBOX_H__

struct ISys3xMsgBox {
	virtual int		Open(char* pszMsg, unsigned int unType) = 0;	// �߂�l��WinAPI��MessageBox()�Ɠ���
};

#endif // __ISYS3XMSGBOX_H__

