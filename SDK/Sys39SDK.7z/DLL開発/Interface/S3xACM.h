///////////////////////////////////////////////////////////////////////////////
//  S3xACM.h
//  Coder.Yudai Senoo :-)

#ifndef __S3XACM_H__
#define __S3XACM_H__

#include <objbase.h>
#include "IS3xACM.h"

// {C875A271-BB3A-4b54-8873-129B04BDE86F}
static const GUID IID_IS3xACM = 
{ 0xc875a271, 0xbb3a, 0x4b54, { 0x88, 0x73, 0x12, 0x9b, 0x4, 0xbd, 0xe8, 0x6f } };

#endif // __S3XACM_H__

