///////////////////////////////////////////////////////////////////////////////
//  ISys3xMsgString.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XMSGSTRING_H__
#define __ISYS3XMSGSTRING_H__

#include "IString.h"

struct ISys3xMsgString : public IString {
	virtual void	Clear(void) = 0;	// ������̍폜
};

#endif // __ISYS3XMSGSTRING_H__

