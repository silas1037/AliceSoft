///////////////////////////////////////////////////////////////////////////////
//  S3xNet.h
//  Coder.Yudai Senoo :-)

#ifndef __S3XNET_H__
#define __S3XNET_H__

#include <objbase.h>
#include "IS3xNet.h"

// {906D58A4-95E8-473a-83C1-3ABEBE4A5DF4}
static const GUID IID_IS3xNet = 
{ 0x906d58a4, 0x95e8, 0x473a, { 0x83, 0xc1, 0x3a, 0xbe, 0xbe, 0x4a, 0x5d, 0xf4 } };

#endif // __S3XNET_H__

