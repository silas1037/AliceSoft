///////////////////////////////////////////////////////////////////////////////
//  IMusicLoop.h
//  Coder.Yudai Senoo :-)

#ifndef __IMUSICLOOP_H__
#define __IMUSICLOOP_H__

struct IMusicLoop {
	virtual bool	SetCount(int nCount) = 0;		// ���[�v�񐔂̐ݒ�
	virtual int		GetCount(void) = 0;				// ���[�v�񐔂̎擾
};

#endif // __IMUSICLOOP_H__

