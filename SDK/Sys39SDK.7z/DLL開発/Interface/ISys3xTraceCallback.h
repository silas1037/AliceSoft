///////////////////////////////////////////////////////////////////////////////
//  ISys3xTraceCallback.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XTRACECALLBACK_H__
#define __ISYS3XTRACECALLBACK_H__

#include "windows.h"

struct ISys3xTraceCallback {
	virtual bool	Call(int nFileNum, unsigned int unAddr, int nEndCmd) = 0;
};

#endif // __ISYS3XTRACECALLBACK_H__

