///////////////////////////////////////////////////////////////////////////////
//  IString.h
//  Coder.Yudai Senoo :-)

#ifndef __ISTRING_H__
#define __ISTRING_H__

class IString {
public:
	virtual char*	Get(void) = 0;				// ������̎擾
	virtual void	Set(char* pszText) = 0;		// ������̐ݒ�
};

#endif // __ISTRING_H__

