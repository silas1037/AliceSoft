///////////////////////////////////////////////////////////////////////////////
//  ISys3xTraceControl.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XTRACECONTROL_H__
#define __ISYS3XTRACECONTROL_H__

struct ISys3xTraceCallback;
struct ISys3xTraceControl {
	virtual bool	Run(void) = 0;
	virtual bool	Pause(void) = 0;
	virtual bool	Step(void) = 0;

	virtual bool	IsRun(void) = 0;	// ���s�����ꎞ��~�����ǂ���

	virtual bool	AddTraceCallback(ISys3xTraceCallback* pISys3xTraceCallback) = 0;
};

#endif // __ISYS3XTRACECONTROL_H__

