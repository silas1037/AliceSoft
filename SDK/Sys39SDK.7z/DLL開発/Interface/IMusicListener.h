///////////////////////////////////////////////////////////////////////////////
//  IMusicListener.h
//  Coder.Yudai Senoo :-)

#ifndef __IMUSICLISTENER_H__
#define __IMUSICLISTENER_H__

#include "windows.h"

struct IMusicListener {
	virtual bool	SetPos(float fX, float fY, float fZ) = 0;
	virtual bool	GetPos(float* pfX, float* pfY, float* pfZ) = 0;
	
	virtual bool	Commit(void) = 0;	// �R�~�b�g
};

/*
	IMusic3D�̐ݒ���X�V���邽�߂̃C���^�[�t�F�C�X�ł��B
*/


#endif // __IMUSICLISTENER_H__

