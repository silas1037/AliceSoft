///////////////////////////////////////////////////////////////////////////////
//  ISys3xVariable.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XVARIABLE_H__
#define __ISYS3XVARIABLE_H__

struct ISys3xVariable {
	// �ݒ�
	virtual bool	SetData(int nPage, int nIndex, unsigned short wData) = 0;		// �ϐ���ݒ�
	
	// �擾
	virtual bool	GetData(int nPage, int nIndex, unsigned short* pwData) = 0;		// �ϐ����擾
	virtual int		GetArrayTableSize(int nPage) = 0;								// �z��̃T�C�Y���擾
	virtual bool	IsArray(int nPage, int nIndex) = 0;								// �z�񂩂ǂ���
	virtual bool	GetArrayInfo(int nPage, int nIndex, int* pnPointerPage, int* pnPointerOffset) = 0;

};

#endif // __ISYS3XVARIABLE_H__

