///////////////////////////////////////////////////////////////////////////////
//  IS3xACM.h
//  Coder.Yudai Senoo :-)

#ifndef __IS3XACM_H__
#define __IS3XACM_H__

#include "IInterface.h"

typedef unsigned char BYTE;
typedef unsigned long DWORD;

struct IS3xACM : public IInterface {
	virtual bool	Decode(BYTE* pbyData, DWORD dwSize, void* pDestWave, void* pSrcWave) = 0;

	virtual BYTE*	GetDecodeData(void) = 0;
	virtual	DWORD	GetDecodeSize(void) = 0;

	virtual void	FreeDecodeData(void) = 0;

};

#endif // __IS3XACM_H__

