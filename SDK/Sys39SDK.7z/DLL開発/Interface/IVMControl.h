///////////////////////////////////////////////////////////////////////////////
//  IVMControl.h
//  Coder.Yudai Senoo :-)

#ifndef __IVMCONTROL_H__
#define __IVMCONTROL_H__

typedef unsigned long DWORD;

struct IVMControl {
	virtual bool	Load(void* pvData, int nSize) = 0;	//	�ǂݍ���

	// �ݒ�
	virtual bool	SetCurIP(DWORD dwIP) = 0;
	
	// �擾
	virtual void*	GetCurBinary(void) = 0;
	virtual DWORD	GetCurIP(void) = 0;
	virtual DWORD	GetEndIP(void) = 0;
	
};

#endif // __IVMCONTROL_H__

