///////////////////////////////////////////////////////////////////////////////
//  ISys3x.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3X_H__
#define __ISYS3X_H__

#include <objbase.h>

struct ISys3x {
	virtual void*	GetInterface(const GUID* pGuid) = 0;
};

#endif // __ISYS3X_H__

