///////////////////////////////////////////////////////////////////////////////
//  ISys3xDebugPlugin.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XDEBUGPLUGIN_H__
#define __ISYS3XDEBUGPLUGIN_H__

struct ISys3xDebug;
struct ISys3xDebugPlugin {
	virtual bool	Init(ISys3xDebug* pISys3xDebug) = 0;
	
	virtual bool	Open(void) = 0;
	virtual bool	Close(void) = 0;
	
	virtual char*	GetName(void) = 0;
};

#endif // __ISYS3XDEBUGPLUGIN_H__

