///////////////////////////////////////////////////////////////////////////////
//  IMusicPause.h
//  Coder.Yudai Senoo :-)

#ifndef __IMUSICPAUSE_H__
#define __IMUSICPAUSE_H__

struct IMusicPause {
	virtual bool	Pause(void) = 0;		// �ꎞ��~
	virtual bool	Restart(void) = 0;		// �ĊJ
	virtual bool	IsPause(void) = 0;		// �ꎞ��~�����ǂ���
};

#endif // __IMUSICPAUSE_H__

