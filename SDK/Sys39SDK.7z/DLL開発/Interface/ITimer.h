///////////////////////////////////////////////////////////////////////////////
//  ITimer.h
//  Coder.Yudai Senoo :-)

#ifndef __ITIMER_H__
#define __ITIMER_H__

class ITimer {
public:
	virtual void			Init(void) = 0;		// �^�C�}�[������
	virtual unsigned int	Get(void) = 0;		// ���Ԏ擾
};

#endif // __ITIMER_H__

