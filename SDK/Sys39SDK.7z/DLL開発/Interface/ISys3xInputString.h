///////////////////////////////////////////////////////////////////////////////
//  ISys3xInputString.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XINPUTSTRING_H__
#define __ISYS3XINPUTSTRING_H__

class IString;
struct ISys3xInputString {
	virtual bool	Get(char* pszTitle, int nMax, IString* pIString) = 0;
};

#endif // __ISYS3XINPUTSTRING_H__

