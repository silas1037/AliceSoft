///////////////////////////////////////////////////////////////////////////////
//  ISys3xStringTable.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XSTRINGTABLE_H__
#define __ISYS3XSTRINGTABLE_H__

#include "IString.h"

class ISys3xStringTable {
public:
	virtual IString*		Get(int nNum) = 0;		// ������C���^�[�t�F�C�X���擾
};

#endif // __ISYS3XSTRINGTABLE_H__

