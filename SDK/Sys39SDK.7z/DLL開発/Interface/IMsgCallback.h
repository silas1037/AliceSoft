///////////////////////////////////////////////////////////////////////////////
//  IMsgCallback.h
//  Coder.Yudai Senoo :-)

#ifndef __IMSGCALLBACK_H__
#define __IMSGCALLBACK_H__

struct IMsgCallback {
	virtual bool	Callback(int nIndex, char* pszText) = 0;
};

#endif // __IMSGCALLBACK_H__

