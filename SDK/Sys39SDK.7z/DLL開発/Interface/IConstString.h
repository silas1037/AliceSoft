///////////////////////////////////////////////////////////////////////////////
//  IConstString.h
//  Coder.Yudai Senoo :-)

#ifndef __ICONSTSTRING_H__
#define __ICONSTSTRING_H__

class IConstString {
public:
	virtual char*	Get(void) = 0;		// ������̎擾
};

#endif // __ICONSTSTRING_H__

