///////////////////////////////////////////////////////////////////////////////
//  ILinkFile.h
//  Coder.Yudai Senoo :-)

#ifndef __ILINKFILE_H__
#define __ILINKFILE_H__

#include "IInterface.h"

struct IMemory;
struct ILinkFile : public IInterface {
	virtual IMemory*	Get(int nNum) = 0;		// �f�[�^�̎擾

};

#endif // __ILINKFILE_H__

