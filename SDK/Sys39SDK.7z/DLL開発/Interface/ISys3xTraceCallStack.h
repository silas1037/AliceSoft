///////////////////////////////////////////////////////////////////////////////
//  ISys3xTraceCallStack.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XTRACECALLSTACK_H__
#define __ISYS3XTRACECALLSTACK_H__

struct ISys3xTraceCallStack {
	virtual int		GetNumof(void) = 0;
	
	virtual int		GetType(int nNum) = 0;
	virtual char*	GetName(int nNum) = 0;
};

#endif // __ISYS3XTRACECALLSTACK_H__

