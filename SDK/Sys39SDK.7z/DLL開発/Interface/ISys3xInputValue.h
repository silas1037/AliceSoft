///////////////////////////////////////////////////////////////////////////////
//  ISys3xInputValue.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XINPUTVALUE_H__
#define __ISYS3XINPUTVALUE_H__

struct ISys3xInputValue {
	virtual bool	Get(char* pszTitle, int nMin, int nMax, int nIni, int* pnResult) = 0;
};

#endif // __ISYS3XINPUTVALUE_H__

