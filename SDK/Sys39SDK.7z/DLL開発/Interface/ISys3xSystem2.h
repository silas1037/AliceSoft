///////////////////////////////////////////////////////////////////////////////
//  ISys3xSystem2.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XSYSTEM2_H__
#define __ISYS3XSYSTEM2_H__

#include "ISys3xSystem.h"

class ISys3xSystem2 : public ISys3xSystem {
public:
	virtual void	SetEnableMsgSkip(bool bFlag) = 0;
};

#endif // __ISYS3XSYSTEM2_H__

