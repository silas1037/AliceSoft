///////////////////////////////////////////////////////////////////////////////
//  ISys3xMsgBuf.h
//  Coder.Yudai Senoo :-)

#ifndef __ISYS3XMSGBUF_H__
#define __ISYS3XMSGBUF_H__

enum {
	// A����ނł̓���w��
	KPS_A_TOP = 0, // �ŏ��̔ԍ��ɖ߂�
	KPS_A_R   = 1, // �q�R�}���h�Ɠ��l�̔ԍ��X�V
	KPS_A_SPC = 2, // ��s��}�����čX�V
	KPS_A_NON = 3, // �������Ȃ�
};

class ISys3xMsgBuf {
public:
	virtual void	Enable(bool bFlag) = 0;
	virtual void	SetIncNumberAtR(bool bFlag) = 0;
	virtual void	SetModeAtA(int nMode) = 0;
	virtual void	SetTopNumber(unsigned int unNum) = 0;
	virtual void	SetCurNumber(unsigned int unNum) = 0;
	virtual void	IncCurNumber(void) = 0;
	virtual void	DecCurNumber(void) = 0;
	virtual void	ResetCurNumber(void) = 0;
	
	virtual bool	IsEnable(void) = 0;
	
	virtual unsigned int	GetCurNumber(void) = 0;
	virtual unsigned int	GetModeAtA(void) = 0;
	
	virtual void	PutR(void) = 0;
};

#endif // __ISYS3XMSGBUF_H__

