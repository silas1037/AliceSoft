## advfix v 0.3

import re
import codecs
import os


###############################################################
## config settings
###############################################################

adv_in_path = ""
adv_out_path = ""

###############################################################


for filename in os.listdir(adv_in_path + "\\"):
    
    fileHandle = codecs.open(adv_in_path + filename, "rb", "shiftjisx0213")
    

    print filename

    lines = []

    try:
        x = fileHandle.readline()
        while x:
            x = fileHandle.readline()
            lines.append(x)
        
    except UnicodeDecodeError:
        print str(len(lines)) + lines[-1]
        fileHandle.close()
        continue

    fileHandle.close()

    i = 0
    while i < len(lines):
        original_line = lines[i]
        lines[i] = lines[i].replace("\tF1 ", "\t F1,")
        lines[i] = lines[i].replace("\tF3 ", "\t F3,")
        lines[i] = lines[i].replace("\tJ0 ", "\t J0,")
        lines[i] = lines[i].replace("\tJ1 ", "\t J1,")

        if lines[i].find("\tMT ") != -1:
            lines[i] = lines[i].replace("\tMT ", "\tMT \"").replace(":\r\n", "\":\r\n")

        if lines[i].find("\tMS ") != -1:
            lines[i] = lines[i].replace(",", ",\"", 1).replace(":\r\n", "\":\r\n")

        if lines[i].find("\tMI ") != -1:
            split_lines = lines[i].split(",")
            lines[i] = ""
            j = 0
            while j < len(split_lines):
                lines[i] += split_lines[j]
                if j != len(split_lines) - 1:
                    lines[i] += ","
                if j == 1:
                    lines[i] += "\""
                j += 1
            lines[i] = lines[i].replace(":\r\n", "\":\r\n")

        if (lines[i].find("\tQE ") != -1) or (lines[i].find("\tLE ") != -1):
            split_lines = lines[i].split(",")
            lines[i] = ""
            j = 0
            while j < len(split_lines):
                lines[i] += split_lines[j]
                if j == 1:
                    lines[i] += "\""
                if j != len(split_lines) - 1:
                    lines[i] += ","
                if j == 0:
                    lines[i] += "\""
                j += 1
            
        i += 1        
    
    
    fileHandle = codecs.open(adv_out_path + filename, "wb", "shiftjisx0213")

    try:
        fileHandle.writelines(lines)
    except:
        print "Failure :("
        fileHandle.close()
        continue

    fileHandle.close()

print "Done!"

