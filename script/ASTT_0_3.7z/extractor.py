##########################################
## extractor.py  v0.3
##########################################

import re
import codecs
import os

##########################################
## config
##########################################

do_checkinit = True
do_showmessage = True

# directory that contains the .adv files that will be edited
adv_path = "c:\\alicesoft\\project\\adv\\"

# directory that .sjs files will be output to
script_path = "c:\\alicesoft\\project\\script\\"


##########################################
## end of config
##########################################


re_message = re.compile("\t+'|\t+R|\t+X\s.|\t+.*'.*'|\t+.*\".*\"")
# re_string_command = re.compile("\t+X\s.|\t+.*'.*'|\t+.*\".*\"")      not used, but might be handy later...

def ShowMessage(message):
    if do_showmessage:
        print message
    return

# inits an adv file
def InitADVFile(filename):
    ShowMessage("Initializing " + filename)
    block_number = 0
    fileHandle = codecs.open(adv_path + "\\" + filename, "rb", "shiftjisx0213")
    lines = fileHandle.readlines()
    fileHandle.close()

    lines.insert(0, ";ASTT\r\n")
    i = 1
    while i < len(lines):
        if re_message.match(lines[i]):
            # found the beginning of a message block
            block_number += 1
            lines.insert(i, ";ASTT BEGIN_J " + str(block_number).zfill(6) + "\r\n")
            # go to the end of the message block
            i += 1
            first_message_line = i
            while i < len(lines) and re_message.match(lines[i]):
                lines[i] = ";" + lines[i]
                i += 1
            last_message_line = i-1
            lines.insert(i, ";ASTT END\r\n")
            i += 1
            lines.insert(i, ";ASTT BEGIN_E " + str(block_number).zfill(6) + "\r\n")
            i += 1
            while first_message_line <= last_message_line:
                lines.insert(i, lines[first_message_line][1:].strip() + "\r\n")
                i += 1
                first_message_line += 1
            lines.insert(i, ";ASTT END\r\n")            
            
        i += 1        

    fileHandle = codecs.open(adv_path + "\\" + filename, "wb", "shiftjisx0213")
    fileHandle.writelines(lines)
    fileHandle.close()

    ShowMessage("Initialization complete!  Total message blocks: " + str(block_number))    
    return


# checks all files in adv_path and inits them if they haven't been
def CheckInitADVFiles():
    for filename in os.listdir(adv_path):
        if filename.endswith(".ADV"):
            ShowMessage("Checking " + filename + " for initialization")
            fileHandle = codecs.open(adv_path + "\\" + filename, "rb", "shiftjisx0213")
            line = fileHandle.readline()
            fileHandle.close()
            if not line.startswith(";ASTT"):
                InitADVFile(filename)
        
    return


# dumps original + current translation to .sjs in the script_path directory
def OutputScript(filename):
    ShowMessage("Dumping " + filename)
    fileHandle = codecs.open(adv_path + "\\" + filename, "rb", "shiftjisx0213")
    lines = fileHandle.readlines()
    fileHandle.close()

    out_lines = [filename.decode("sjis") + "\r\n\r\n"]

    i = 0
    while i < len(lines):
        if lines[i].startswith(";ASTT BEGIN_J"):
            if (lines[i+1][1:].strip() == "R"):  #leading R
                out_lines.append(";\r\n")
            while not lines[i].startswith(";ASTT END"):
                if (lines[i][1:].strip() != "R"):
                    out_lines.append(lines[i].strip(";").strip() + "\r\n")
                elif (lines[i-1][1:].strip() == "R"): # double Rs in message
                    out_lines.append(";\r\n")
                i += 1
            if (lines[i-1][1:].strip() == "R"):  # trailing R in message
                out_lines.append(";\r\n")
            out_lines.append(";ASTT END\r\n")
            i += 1
            while not lines[i].startswith(";ASTT BEGIN_E"):
                i += 1
            while not lines[i].startswith(";ASTT END"):
                first_char = lines[i].strip()[0]
                if (first_char == "'" or lines[i].startswith(";ASTT BEGIN_E")):
                    out_lines.append(lines[i].strip().strip("'") + "\r\n")
                elif first_char != "R" and first_char != ";":
                    out_lines.append("{" + lines[i].strip() + "}" + "\r\n")
                i += 1
            out_lines.append(";ASTT END\r\n\r\n")
        i += 1


    fileHandle = codecs.open(script_path + "\\" + filename.replace(".ADV", ".SJS"), "wb", "shiftjisx0213")
    fileHandle.writelines(out_lines)
    fileHandle.close()        

    return



if do_checkinit:
    CheckInitADVFiles()

for filename in os.listdir(adv_path):
    if filename.endswith(".ADV"):
        OutputScript(filename)

ShowMessage("Done!")    
