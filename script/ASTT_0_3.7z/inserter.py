##########################################
## inserter.py v 0.3
##########################################

import re
import codecs
import os
import textwrap

##########################################
## config
##########################################

chars_per_line = 75

insert_ZH_commands = True

do_check = False
do_showmessage = True

# directory that contains the .adv files that will be updated
adv_path = "c:\\alicesoft\\tt_project\\sdk\\game\\source\\"


# directory that the .sjs files are in
script_path = "c:\\alicesoft\\tt_project\\script\\"


##########################################
## end of config
##########################################


re_message = re.compile("\t+'|\t+R|\t+X\s.|\t+.*'.*'|\t+.*\".*\"")
# re_string_command = re.compile("\t+X\s.|\t+.*'.*'|\t+.*\".*\"")      not used, but might be handy later...

def ShowMessage(message):
    if do_showmessage:
        print message
    return




# checks all files in adv_path for initialization
def CheckADVFiles():
    for filename in os.listdir(adv_path):
        if filename.endswith(".ADV"):            
            fileHandle = codecs.open(adv_path + filename, "rb", "shiftjisx0213")
            line = fileHandle.readline()
            fileHandle.close()
            if not line.startswith(";ASTT"):
                ShowMessage(filename + " has not been initialized!  Use the extractor program to initialize.")
                exit()
    return


def WordWrap(text, offset):

    #if len(text) <= chars_per_line - offset:
    #    return [text.replace("\r\n", "")]

    if offset == 0:
        retval = textwrap.wrap(text, chars_per_line)
    else:
        if offset > chars_per_line - 10:
            offset = chars_per_line - 10
            
        tmp_wrap = textwrap.wrap(text, chars_per_line - offset)

        if tmp_wrap == []:
            return []
        
        text2 = text[len(tmp_wrap[0]):]
        retval = [tmp_wrap[0]]
        retval.extend(textwrap.wrap(text2, chars_per_line))

    i = 0
    while i < len(retval):
        retval[i] += ""        
        i += 1        
        
    return retval


# inserts current translation from .sjs to the .adv files in the adv_path directory
def InsertScript(filename):
    ShowMessage("Inserting " + filename)
    fileHandle = codecs.open(script_path + filename, "rb", "shiftjisx0213")
    lines = fileHandle.readlines()
    fileHandle.close()

    fileHandle = codecs.open(adv_path + filename.replace(".SJS", ".ADV"), "rb", "shiftjisx0213")
    adv_lines = fileHandle.readlines()
    fileHandle.close()

    # var0055 = evil
    #for i in adv_lines:
    #    if i.find("VAR0160") != -1:
    #        print "    YES!"

    
    i = 0
    while i < len(lines):        
        if lines[i].startswith(";ASTT BEGIN_E"):
            message_id = lines[i].strip()[-6:]
            i += 1
            if insert_ZH_commands:
                insert_lines = ["ZH 1:\r\n"]
            else:
                insert_lines = []
            is_first_line = True
            while not lines[i].startswith(";ASTT END"):
                newline = ""
                brace_index = lines[i].find("{")
                if brace_index == -1:
                    if not is_first_line:
                        insert_lines.append("R\r\n")
                    newline = lines[i].replace("'", "\\'").rstrip()
                    added_lines = False
                    for k in WordWrap(newline, 0):
                        insert_lines.append("'" + k + "'\r\n")
                        insert_lines.append("R\r\n")
                        added_lines = True
                    if added_lines:
                        insert_lines.pop()  # remove that last R since we don't want one trailing at the end of the message
                else:
                    if not is_first_line:
                        insert_lines.append("R\r\n")

                    curpos = 0
                    offset = 0
                    added_lines = False
                    for k in WordWrap(lines[i][curpos:brace_index], 0):
                        insert_lines.append("'" + k.replace("'", "\\'").replace("\r\n", "") + " '\r\n")
                        insert_lines.append("R\r\n")
                        added_lines = True
                        offset = len(k)
                    if added_lines:
                        insert_lines.pop()  # remove that last R since we don't want one trailing at the end of the message

                    brace_index_2 = lines[i].find("}")

                    tmp_line = ""
                    apostrophe_index_1 =  lines[i].find("'", brace_index, brace_index_2)
                    if apostrophe_index_1 != -1:
                        apostrophe_index_2 =  lines[i].rfind("'", apostrophe_index_1 + 1, brace_index_2)
                        if apostrophe_index_2 != -1:
                            # we have a command that has a string argument
                            tmp_line = lines[i][brace_index + 1 : apostrophe_index_1 + 1]
                            tmp_line += (lines[i][apostrophe_index_1 + 1 : apostrophe_index_2]).replace("'", "\\'")
                            tmp_line += lines[i][apostrophe_index_2 : brace_index_2]
                        else:
                            tmp_line = (lines[i][brace_index + 1 : brace_index_2]).replace("'", "\\'")
                    else:
                        tmp_line = lines[i][brace_index + 1 : brace_index_2]
                    insert_lines.append(tmp_line + "\r\n")
                    offset += len(tmp_line)
                    if (len(lines[i][brace_index_2 + 1 : ]) > 0):
                        for k in WordWrap(lines[i][brace_index_2 + 1 : ], offset):
                            if added_lines:
                                insert_lines.append("'" + k.lstrip().replace("'", "\\'").replace("\r\n", "") + "'\r\n")
                            else:
                                insert_lines.append("'" + k.replace("'", "\\'").replace("\r\n", "") + "'\r\n")
                            insert_lines.append("R\r\n")
                            added_lines = True
                        if added_lines:
                            insert_lines.pop()  # remove that last R since we don't want one trailing at the end of the message
                                        
                is_first_line = False                                    
                i += 1
    
            # insert_lines now has the lines we want to insert into the .adv            

            j = 0
            found_id = False
            while j < len(adv_lines):
                if adv_lines[j].startswith(";ASTT BEGIN_E " + message_id):
                    found_id = True
                    j += 1
                    while not adv_lines[j].startswith(";ASTT END"):
                        del adv_lines[j]
                    insert_lines.reverse()
                    for s in insert_lines:
                        adv_lines.insert(j, s)
                j += 1
            if not found_id:
                ShowMessage("Couldn't find message with ID " + message_id)
                exit()

        i += 1

    fileHandle = codecs.open(adv_path + filename.replace(".SJS", ".ADV"), "wb", "shiftjisx0213")
    fileHandle.writelines(adv_lines)
    fileHandle.close()        

    return



if do_check:
    CheckADVFiles()

for filename in os.listdir(script_path):
    if filename.endswith(".SJS"):        
        InsertScript(filename)
        

ShowMessage("Done!")    
