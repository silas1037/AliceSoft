##########################################
## progress_check.py v 0.3
##
## Estimates your translation progress, assuming lines
## with only non-Japanese (printable) chars are translated
##########################################

import codecs
import os
import string

##########################################
## config
##########################################

# directory that the .sjs files are in
script_path = "c:\\alicesoft\\tt_project\\script\\"

##########################################
## end of config
##########################################

# checks a translation script to see how many lines still have translating work to do
# This is a very rough estimate as it counts as translated any message that has no Japanese
# characters.
def AnalyzeScript(filename):
    fileHandle = codecs.open(script_path + filename, "rb", "shiftjisx0213")
    lines = fileHandle.readlines()
    fileHandle.close()

    message_count = 0
    translated_count = 0
       
    i = 0
    while i < len(lines):        
        if lines[i].startswith(";ASTT BEGIN_E"):
            message_count += 1
            is_translated = True
            i += 1
            while not lines[i].startswith(";ASTT END"):
                #if (not (lines[i].replace(" ", "").replace("\r\n", "").isalnum())) and lines[i].strip() != "":
                for c in lines[i]:
                    if c not in string.printable:
                        is_translated = False
                i += 1

            if is_translated:
                translated_count += 1
        i += 1

    return (message_count, translated_count)


total_messages = 0
translated_messages = 0

for filename in os.listdir(script_path):
    if filename.endswith(".SJS"):        
        (m, t) = AnalyzeScript(filename)
        if m != 0:
            print filename + ": " + str(t) + " / " + str(m) + "  (" + str(round(100 * t/m, 1)) + "%) messages translated"
            total_messages += m
            translated_messages += t

print "\nTotal:   " + str(translated_messages) + " / " + str(total_messages) + "  (" + str(round(100 * translated_messages/total_messages, 1)) + "%) messages translated!"

  
