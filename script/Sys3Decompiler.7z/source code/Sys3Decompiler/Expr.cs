﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace Sys3Decompiler
{
    public class Expr
    {
        private static Expr Empty = new Expr();

        public string value;
        public int IntValue;
        public Expr e1, e2;
        public Expr()
        {

        }
        public Expr(int value)
        {
            this.IntValue = value;
        }
        public Expr(string value, int v1)
        {
            this.value = value;
            this.e1 = new Expr(v1);
        }

        public Expr(string value)
        {
            this.value = value;
        }
        public Expr(string value, Expr e1)
        {
            this.value = value;
            this.e1 = e1;
        }
        public Expr(string value, string v1)
        {
            this.value = value;
            this.e1 = new Expr(v1);
        }
        public Expr(string value, Expr e1, Expr e2)
        {
            this.value = value;
            this.e1 = e1;
            this.e2 = e2;
        }
        public Expr(string value, Expr e1, string v2)
        {
            this.value = value;
            this.e1 = e1;
            this.e2 = new Expr(v2);
        }
        public Expr(string value, string v1, Expr e2)
        {
            this.value = value;
            this.e1 = new Expr(v1);
            this.e2 = e2;
        }

        static Dictionary<string, int> precedence = GetPrecedence();

        private static Dictionary<string, int> GetPrecedence()
        {
            var dic = new Dictionary<string, int>();
            dic.Add("*", 16);
            dic.Add("/", 16);
            dic.Add("%", 16);
            dic.Add("+", 14);
            dic.Add("-", 12);

            dic.Add("!=", 10);
            dic.Add("==", 10);
            dic.Add("<=", 8);
            dic.Add("<", 8);
            dic.Add(">=", 8);
            dic.Add(">", 8);
            dic.Add("&", 6);
            dic.Add("^", 4);
            dic.Add("|", 2);
            return dic;
        }

        public static int Precedence(string op)
        {
            if (String.IsNullOrEmpty(op) || !precedence.ContainsKey(op))
            {
                return -1;
            }
            return precedence[op];
        }

        public int Precedence()
        {
            return Precedence(this.value);
        }

        private void ToString(StringBuilder sb)
        {
            int p = Precedence();

            if (p != -1)
            {
                bool e1Lower = false;
                bool e2Lower = false;

                var e1 = this.e1 ?? Expr.Empty;
                var e2 = this.e2 ?? Expr.Empty;

                int p1 = e1.Precedence();
                int p2 = e2.Precedence();

                bool p1SamePrecedence = (p1 == p && this.value == e1.value);
                bool p2SamePrecedence = (p2 == p && this.value == e2.value);

                bool p1NeedsParenthesis = p1 != -1 && p1 <= p;
                bool p2NeedsParenthesis = p2 != -1 && p2 <= p;

                if (p1SamePrecedence && (p2 == -1 || (p2SamePrecedence && e2.value == this.value)))
                {
                    p1NeedsParenthesis = false;
                }
                if (p2SamePrecedence && p1 != -1 && (p1SamePrecedence && e1.value == this.value) && p2 == -1)
                {
                    p2NeedsParenthesis = false;
                }

                if (p1NeedsParenthesis)
                {
                    e1Lower = true;
                }
                if (p2NeedsParenthesis)
                {
                    e2Lower = true;
                }

                if (e1Lower)
                {
                    sb.Append("(");
                }

                e1.ToString(sb);

                if (e1Lower)
                {
                    sb.Append(")");
                }

                sb.Append(" ");
                sb.Append(this.value);
                sb.Append(" ");

                if (e2Lower)
                {
                    sb.Append("(");
                }

                e2.ToString(sb);

                if (e2Lower)
                {
                    sb.Append(")");
                }
            }
            else
            {
                if (this.value == "[")
                {
                    e1.ToString(sb);
                    sb.Append("[");
                    e2.ToString(sb);
                    sb.Append("]");
                }
                else if (this.value == "var" && this.e1 != null)
                {
                    string varName;
                    if (this.e1.value == null)
                    {
                        int varNumber = this.e1.IntValue;
                        varName = ScoFiles.DefaultInstance.AddVariable(varNumber);
                    }
                    else
                    {
                        int varNumber;
                        if (IntUtil.TryParse(this.e1.value, out varNumber))
                        {
                            varName = ScoFiles.DefaultInstance.AddVariable(varNumber);
                        }
                        else
                        {
                            varName = this.e1.value;
                        }
                    }
                    sb.Append(varName);
                }
                else
                {
                    if (this.value != null)
                    {
                        sb.Append(this.value);
                    }
                    else
                    {
                        sb.Append(this.IntValue.ToString());
                    }
                    if (this.e1 != null)
                    {
                        e1.ToString(sb);
                    }
                    if (this.e2 != null)
                    {
                        e2.ToString(sb);
                    }
                }
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            ToString(sb);
            return sb.ToString();
        }

        public int? EvaluateConstExpression()
        {
            int result;
            bool success = TryEvaluateConstExpression(out result);
            if (success)
            {
                return result;
            }
            else
            {
                return null;
            }
        }

        public bool TryEvaluateConstExpression(out int result)
        {
            result = -1;
            if (this.value == null)
            {
                result = this.IntValue;
                return true;
            }
            int intValue;
            if (IntUtil.TryParse(this.value, out intValue))
            {
                result = intValue;
                return true;
            }
            if (Expr.Precedence(this.value) != -1 && this.e1 != null && this.e2 != null)
            {
                int value1;
                int value2;
                if (!(e1.TryEvaluateConstExpression(out value1) && e2.TryEvaluateConstExpression(out value2)))
                {
                    return false;
                }

                switch (this.value)
                {
                    case "*":
                        result = value1 * value2;
                        break;
                    case "/":
                        result = value1 / value2;
                        break;
                    case "%":
                        result = value1 % value2;
                        break;
                    case "+":
                        result = value1 + value2;
                        break;
                    case "-":
                        result = value1 - value2;
                        break;
                    case "!=":
                        result = (value1 != value2) ? 1 : 0;
                        break;
                    case "==":
                        result = (value1 == value2) ? 1 : 0;
                        break;
                    case "<=":
                        result = (value1 <= value2) ? 1 : 0;
                        break;
                    case "<":
                        result = (value1 < value2) ? 1 : 0;
                        break;
                    case ">=":
                        result = (value1 >= value2) ? 1 : 0;
                        break;
                    case ">":
                        result = (value1 > value2) ? 1 : 0;
                        break;
                    case "&":
                        result = value1 & value2;
                        break;
                    case "^":
                        result = value1 ^ value2;
                        break;
                    case "|":
                        result = value1 | value2;
                        break;
                }
                return true;
            }
            return false;
        }
    }
}
