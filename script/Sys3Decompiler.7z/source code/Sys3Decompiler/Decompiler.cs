﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace Sys3Decompiler
{
    public class DecompilerBase : Parser
    {
        public ScoFile Parent;
        public Stream stream;
        public BinaryReader br;
        public long limit;
        public string[] ainMessages;

        public DecompilerBase(ScoFile parent, Stream stream)
        {
            this.Parent = parent;
            LoadFile(stream);
            if (this.Parent != null)
            {
                this.ainMessages = this.Parent.AinMessages;
            }
        }

        public void LoadFile(Stream stream)
        {
            this.stream = stream;
            this.br = new BinaryReader(stream);
            long startPosition = stream.Position;
            string signature = br.ReadStringFixedSize(4);
            if (signature == "S380")
            {
                signature = string.Intern(signature);
            }
            int headerSize = br.ReadInt32();
            int fileSize = br.ReadInt32();
            int unknown1 = br.ReadInt32();
            int filenameLength = br.ReadUInt16();
            string fileName = br.ReadStringFixedSize(filenameLength);
            stream.Position = startPosition + headerSize;

            this.limit = Math.Min(stream.Length, fileSize + startPosition);

            if (this.Parent != null)
            {
                this.Parent.signature = signature;
                this.Parent.fileNumber2 = unknown1;
                this.Parent.FileName = fileName;
                this.Parent.FileSize = (int)(this.limit - startPosition);
            }
        }

        public override void err(string errorMessage)
        {

        }

        Expr GetVar(int c0)
        {
            Expr e2 = null;
            if ((c0 & 0x40) != 0)
            { /* 2byte系 */
                int c1 = stream.ReadByte();
                if (c0 == 0xc0)
                {
                    if (c1 == 0)
                    {
                        err();
                    }
                    else if (c1 == 1)
                    {
                        /* SYSTEM35拡張 */
                        c0 = (stream.ReadByte() << 8) + stream.ReadByte();  /* varbase */
                        e2 = GetCaliValueInternal();                /* offset */
                        var dummy = Parent.Parent.AddVariable(c0);
                        return new Expr("[", new Expr("var", c0), e2);
                    }
                    else if (c1 < 0x40)
                    {
                        err();
                    }
                    else
                    { /* 2byte系 40h - ffh */
                        var dummy = Parent.Parent.AddVariable(c1);
                        return new Expr("var", c1);
                    }
                }
                else
                { /* 2byte系 100h - 3fffh */
                    int v = ((c0 & 0x3f) * 256) + c1;
                    var dummy = Parent.Parent.AddVariable(v);
                    return new Expr("var", v);
                }
            }
            else
            { /* 1byte系 */
                int v = (c0 & 0x3F);
                var dummy = Parent.Parent.AddVariable(v);
                return new Expr("var", v);
            }
            /* 来ないはず */
            err();
            return null;
        }

        public override Expr getCaliValue()
        {
            return GetCaliValueInternal();
        }

        private Expr GetCaliValueInternal()
        {
            Stack<Expr> stack = new Stack<Expr>();

            //int ingVal,edVal,rstVal;
            int c0;
            while ((c0 = stream.ReadByte()) != 0x7F)
            {
                if (stack.Count > 4096)
                {
                    //obviously not real code if it's more than 4096 levels deep
                    err();
                }
                if ((c0 & 0x80) != 0)
                { /* variable */
                    int c1 = stream.PeekByte();
                    if (c0 == 0xc0)
                    {
                        if (c1 == 1 || c1 >= 0x34) goto l_var;
                        c1 = stream.ReadByte();
                        if (c1 == 2)
                        { /* % */
                            stack.BinaryOperation("%");
                            continue;
                        }
                        else if (c1 == 3)
                        { /* <= */
                            stack.BinaryOperation("<=");
                            continue;
                        }
                        else if (c1 == 4)
                        { /* >= */
                            stack.BinaryOperation(">=");
                            continue;
                        }
                        else if (c1 < 0x34)
                        {
                            err();
                        }
                    }
                l_var:
                    {
                        var e = GetVar(c0);
                        //string dummy = e.ToString();
                        if (e == null) continue;
                        stack.Push(e);
                    }
                }
                else
                {
                    switch (c0)
                    {
                        case 0x7e: /* != */
                            stack.BinaryOperation("!=");
                            break;
                        case 0x7d: /* > */
                            stack.BinaryOperation(">");
                            break;
                        case 0x7c: /* < */
                            stack.BinaryOperation("<");
                            break;
                        case 0x7b: /* == */
                            stack.BinaryOperation("==");
                            break;
                        case 0x7a: /* - */
                            stack.BinaryOperation("-");
                            break;
                        case 0x79: /* + */
                            stack.BinaryOperation("+");
                            break;
                        case 0x78: /* / */
                            stack.BinaryOperation("/");
                            break;
                        case 0x77: /* * */
                            stack.BinaryOperation("*");
                            break;
                        case 0x76: /* XOR */
                            stack.BinaryOperation("^");
                            break;
                        case 0x75:  /* OR */
                            stack.BinaryOperation("|");
                            break;
                        case 0x74: /* AND */
                            stack.BinaryOperation("&");
                            break;
                        default:
                            {
                                int c1;
                                if ((c0 & 0x40) == 0)
                                { /* WORD const */
                                    c1 = stream.ReadByte();
                                    if (c0 == 0)
                                    { /* 34h-ffh */
                                        if (c1 <= 0x33)
                                        {
                                            err();
                                        }
                                    }
                                    else
                                    { /* 100h- 3fff */
                                        c1 += ((c0 & 0x3f) * 256);
                                    }
                                }
                                else
                                { /* byte const 0-33h */
                                    c1 = (c0 & 0x3f);
                                }
                                // printf("c1 = %d ",c1);
                                stack.Push(new Expr(c1));
                            }
                            break;
                    }
                }
            }
            if (stack.Count != 1)
            {
                err();
            }
            var value = stack.Pop();
            return value;
        }

        public override Expr getCaliVariable()
        {
            int c0 = stream.ReadByte();
            var expr = GetVar(c0);
            //string dummy = expr.ToString();
            int c1 = stream.ReadByte();
            if (c1 != 0x7F)
            {
                err("7F");
            }
            return expr;
        }

        public override Expr getVariable()
        {
            int c0 = stream.ReadByte();
            var expr = GetVar(c0);
            //string dummy = expr.ToString();
            return expr;
        }

        public override int getAddress()
        {
            return GetDwInternal();
        }

        protected int GetDwInternal()
        {
            return br.ReadInt32();
        }

        public override int getC()
        {
            int c = br.ReadByte();
            //todo: generate code
            return c;
        }
        public override string getString(int terminator)
        {
            List<byte> bytes = new List<byte>();
            int c;
            while (terminator != (c = stream.ReadByte()) && c != -1)
            {
                bytes.Add((byte)c);
            }
            string str = shiftJis.GetString(bytes.ToArray());
            return str;
        }

        public override string getConstString()
        {
            List<byte> bytes = new List<byte>();
            int c;
            int terminator = stream.ReadByte();

            while (terminator != (c = stream.ReadByte()) && c != -1)
            {
                bytes.Add((byte)((c >> 4) | (c << 4)));
            }
            string str = shiftJis.GetString(bytes.ToArray());
            return str;
        }

        public override Expr getValue40()
        {
            int c = stream.PeekByte();
            if (c < 0x40)
            {
                c = getC();
                return new Expr(c);
            }
            return getCaliValue();
        }
        public override int getDw()
        {
            return GetDwInternal();
        }
        public override int getW()
        {
            return GetWInternal();
        }

        protected int GetWInternal()
        {
            return br.ReadUInt16();
        }

        static Dictionary<char, char> FullwidthToHalfwidth = GetMakeHalfWidthTable();
        private static Dictionary<char, char> GetMakeHalfWidthTable()
        {
            string replace1 = " ｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";//ﾞﾟ";
            string replace2 = "　。「」、・をぁぃぅぇぉゃゅょっーあいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわん";//゛゜";

            Dictionary<char, char> dic = new Dictionary<char, char>();
            for (int i = 0; i < replace1.Length; i++)
            {
                char c1 = replace1[i];
                char c2 = replace2[i];
                dic.Add(c2, c1);
            }
            return dic;
        }

        static Dictionary<char, char> HalfwidthToFullwidth = GetMakeFullWidthTable();
        private static Dictionary<char, char> GetMakeFullWidthTable()
        {
            string replace1 = " ｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ";
            string replace2 = "　。「」、・をぁぃぅぇぉゃゅょっーあいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわん゛゜";

            Dictionary<char, char> dic = new Dictionary<char, char>();
            for (int i = 0; i < replace1.Length; i++)
            {
                char c1 = replace1[i];
                char c2 = replace2[i];
                dic.Add(c1, c2);
            }
            return dic;
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public static string ToFullWidth(string halfWidthString)
        {
            var chars = halfWidthString.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (HalfwidthToFullwidth.ContainsKey(c))
                {
                    chars[i] = HalfwidthToFullwidth[c];
                }
            }
            return new string(chars);
        }

        public static string ToHalfWidth(string fullWidthString)
        {
            var chars = fullWidthString.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (FullwidthToHalfwidth.ContainsKey(c))
                {
                    chars[i] = FullwidthToHalfwidth[c];
                }
            }
            return new string(chars);
        }

        //public void Decompile()
        //{
        //    while (stream.Position < limit)
        //    {
        //        try
        //        {
        //            ParseLine();
        //        }
        //        catch
        //        {
        //            EndLine();
        //        }
        //    }
        //}

        public override string getMessage()
        {
            int _encodingMode = this.Parent.Parent.EncodingMode;

            int c = stream.PeekByte();
            if (!(c == ' ' || (c >= 0x80 && c < 0xFF)))
            {
                return null;
            }

            c = stream.ReadByte();
            StringBuilder sb = new StringBuilder();

            while (c == ' ' || c >= 0x80)
            {
                if (c >= 0x80)
                {
                    if (c >= 0xA1 && c <= 0xDF)
                    {
                        if (_encodingMode == 0)
                        {
                            _encodingMode = 1;
                            this.Parent.Parent.EncodingMode = _encodingMode;
                        }
                        string s = shiftJis.GetString(new byte[] { (byte)c });
                        char ch = s[0];
                        if (HalfwidthToFullwidth.ContainsKey(ch))
                        {
                            sb.Append(HalfwidthToFullwidth[ch]);
                        }
                        else
                        {
                            sb.Append(ch);
                        }
                    }
                    else
                    {
                        int c2 = stream.ReadByte();
                        string s = shiftJis.GetString(new byte[] { (byte)c, (byte)c2 });
                        if (_encodingMode == 0 && IsHiraganaWithoutDiacritics(s[0]))
                        {
                            _encodingMode = 2;
                            this.Parent.Parent.EncodingMode = _encodingMode;
                        }

                        //var twoBytes = shiftJis.GetBytes(s);
                        //if (!(twoBytes[0] == c && twoBytes[1] == c2))
                        //{

                        //}

                        sb.Append(s);
                    }
                }
                else
                {
                    sb.Append('　');
                }
                int address = (int)(stream.Position);
                if (Parent.LabelsInverse.ContainsKey(address))
                {
                    c = stream.ReadByte();
                    break;
                }

                c = stream.ReadByte();

            }
            stream.Position--;

            return sb.ToString();
        }

        static HashSet<char> _hiraganaWithoutDiacratics = new HashSet<char>("ぁあぃいぅうぇえぉおかきくけこさしすせそたちっつてとなにぬねのはひふへほまみむめもゃやゅゆょよらりるれろゎわゐゑをん".ToCharArray());

        static private bool IsHiraganaWithoutDiacritics(char c)
        {
            return _hiraganaWithoutDiacratics.Contains(c);
        }

        public override string getAinMessage()
        {
            int messageNumber = GetDwInternal();
            return this.ainMessages.GetOrNull(messageNumber);
        }

        public override int getForLoopStart()
        {
            int c1 = getC();
            int c2 = 0;
            int c3 = 0;
            if (c1 == 0)
            {
                if (Parent.LabelsInverse.ContainsKey((int)stream.Position))
                {
                    throw new OperationCanceledException();
                }
                c2 = getC();
                c3 = getC();
            }
            else if (c1 == 1)
            {

            }
            return c1 + (c2 << 8) + (c3 << 16);
        }

        public override void getVariableArguments(int libNumber, int functionNumber)
        {
            int argumentCount = 0;
            var funcEntry = Parent.Parent.AinFile.libraries.GetLibraryFunction(libNumber, functionNumber);
            if (funcEntry.Arguments == null)
            {

            }

            //var funcEntry2 = Parent.Parent.AinFile.libraryFunctions.GetOrNull(functionNumber);

            //if (funcEntry.FunctionName != null)
            //{
            //    for (int i = 0; i < funcEntry.ArgumentCount; i++)
            //    {
            //        int dataType = funcEntry.Arguments[i];
            //        if (dataType != 1)
            //        {

            //        }
            //        int oldPosition = (int)stream.Position;
            //        try
            //        {
            //            getCaliValue();
            //            argumentCount++;
            //        }
            //        catch
            //        {
            //            stream.Position = oldPosition;
            //            break;
            //        }
            //    }
            //}
            //else
            {
                //auto-detect argument count
                while (true)
                {
                    int oldPosition = (int)stream.Position;
                    try
                    {
                        if (argumentCount >= funcEntry.ArgumentCount)
                        {
                            break;
                        }
                        if (Parent.LabelsInverse.ContainsKey((int)stream.Position))
                        {
                            break;
                        }
                        int dataType = funcEntry.Arguments[argumentCount];
                        if (dataType == 0x12)
                        {
                            string str = getString(0);
                        }
                        else
                        {
                            var val = getCaliValue();
                        }
                        //if (val.IntValue == 9536)
                        //{
                        //    stream.Position = oldPosition;
                        //    break;
                        //}
                        argumentCount++;
                    }
                    catch
                    {
                        stream.Position = oldPosition;
                        break;
                    }
                }
            }
        }
    }

    //public class IntEventArgs : EventArgs
    //{
    //    public int Value
    //    {
    //        get;
    //        set;
    //    }
    //    public IntEventArgs(int value)
    //    {
    //        this.Value = value;
    //    }
    //}

    public class LabelFinderParser : DecompilerBase
    {
        int instructionByte;
        int lastValue;
        int lastAddress;
        int lastChar;

        //        public event EventHandler<IntEventArgs> SawAddress;

        public LabelFinderParser(ScoFile parent, Stream stream)
            : base(parent, stream)
        {

        }

        public override int getW()
        {
            int word = base.getW();
            lastValue = word;
            return word;
        }

        public override int getC()
        {
            int c = base.getC();
            lastChar = c;
            return c;
        }

        public override int getDw()
        {
            int dword = base.getDw();
            lastValue = dword;
            return dword;
        }

        public bool Continue = true;

        public override void StartLine()
        {
            //if (this.stream.Position >= 0x40D && this.Parent.FileName == "キャラクタ戦闘.ADV")
            //{

            //}


            Parent.seenAddresses[(int)stream.Position] = 0;
            instructionByte = stream.PeekByte();
            switch (instructionByte)
            {
                case '&':
                case '@':
                    //case '\\':
                    //this.Continue = false;
                    break;
                case 0:
                    this.Continue = false;
                    Parent.seenAddresses[(int)stream.Position] = 2;
                    break;
                case 127:
                    this.Continue = false;
                    Parent.seenAddresses[(int)stream.Position] = 2;
                    break;
            }

            base.StartLine();
        }

        public override Expr getCaliValue()
        {
            var expr = base.getCaliValue();
            if (instructionByte == '%')
            {
                if (expr.EvaluateConstExpression() == 0)
                {
                    //this.Continue = false;
                }
            }
            else if (instructionByte == '#')
            {
                //if (Parent.FileName == "R5_MOO_D_batl.ADV")
                //{

                //}
                if (!Parent.seenAddresses.ContainsKey(this.lastAddress))
                {
                    Parent.seenAddresses[this.lastAddress] = 2;
                }
                int? value = expr.EvaluateConstExpression();
                if (value != null)
                {
                    int pointerAddress = this.lastAddress + (value.Value - 1) * 4;
                    int lastStreamAddress = (int)stream.Position;
                    stream.Position = pointerAddress;
                    int pointerValue = br.ReadInt32();

                    Parent.seenAddresses[pointerAddress] = 1;
                    Parent.seenAddresses[pointerValue] = 2;
                    Parent.AddLabel(pointerValue);

                    stream.Position = lastStreamAddress;
                }
                else
                {
                    int lastStreamAddress = (int)stream.Position;

                    int pointerBaseAddress = this.lastAddress;
                    //check for possible pointers -
                    //must be greater than own address, and less than any seen address
                    int lowestPointer = int.MaxValue;
                    int lastPointer = -1;
                    int pointerAddress = pointerBaseAddress;
                    while (true)
                    {
                        if (pointerAddress >= lowestPointer)
                        {
                            break;
                        }
                        stream.Position = pointerAddress;
                        int pointer = br.ReadInt32();
                        if (pointer <= pointerAddress || pointer < 0)
                        {
                            break;
                        }
                        else
                        {
                            if (lowestPointer > pointer)
                            {
                                lowestPointer = pointer;
                            }
                            if (lastPointer > pointer)
                            {
                                break;
                            }
                        }
                        //handle the pointer
                        {
                            Parent.seenAddresses[pointerAddress] = 1;
                            Parent.seenAddresses[pointer] = 2;
                            Parent.AddLabel(pointer);
                        }

                        lastPointer = pointer;
                        pointerAddress += 4;
                    }

                    stream.Position = lastStreamAddress;

                }
            }
            else if (instructionByte == '~')
            {
                if (lastValue == 0)
                {
                    //this.Continue = false;
                }
            }
            return expr;
        }

        public override int getAddress()
        {
            int address = base.getAddress();
            SawAddress(address);
            return address;

            //if (SawAddress != null)
            //{
            //    SawAddress(this, new IntEventArgs(address));
            //}
        }

        void SawAddress(int address)
        {
            lastAddress = address;
            switch (instructionByte)
            {
                //case '%':
                //    {
                //        if (lastValue == 0)
                //        {
                //            this.Continue = false;
                //        }
                //        else
                //        {
                //            int fileNumber = lastValue;
                //            var scoFile = Parent.Parent.GetFile(fileNumber);
                //            if (scoFile != null)
                //            {
                //                scoFile.addressQueue.Enqueue(address);
                //            }
                //        }
                //    }
                //    break;
                case '\\':
                    {
                        if (address == 0)
                        {
                            //this.Continue = false;
                        }
                        else
                        {
                            Parent.addressQueue.Enqueue(address);
                            Parent.AddLabel(address);
                        }
                    }
                    break;
                case '@':
                case '{':
                case '$':
                case '<':
                case '>':
                    if (address != 0)
                    {
                        Parent.addressQueue.Enqueue(address);
                        Parent.AddLabel(address);
                    }
                    break;
                case '~':
                case '/':
                    {
                        int fileNumber = lastValue;
                        var scoFile = Parent.Parent.GetFile(fileNumber);
                        if (scoFile != null)
                        {
                            if (lastChar != 0x80)
                            {
                                scoFile.AddLabel(address);
                                scoFile.addressQueue.Enqueue(address);
                            }
                            else
                            {
                                scoFile.AddLabel(address);
                            }
                        }
                    }
                    break;
                case '#':
                    {
                        Parent.AddLabel(address);
                    }
                    break;
                default:
                    {
                        Parent.AddLabel(address);
                    }
                    break;
            }
        }

        public override void getExternalAddress(out int fileNumber, out int address)
        {
            base.getExternalAddress(out fileNumber, out address);
            Parent.Parent.AddExternalLabel(fileNumber, address);
        }

        public override void getExternalAddress2(out int fileNumber, out int address)
        {
            base.getExternalAddress2(out fileNumber, out address);
            if (fileNumber != -1)
            {
                Parent.Parent.AddExternalLabel(fileNumber, address);
            }
        }
    }

    public class Decompiler : DecompilerBase
    {
        public TextWriter tw;
        public StringBuilder sb;
        bool needComma;
        bool needSpace;
        bool reallyNeedSpace;
        bool firstChar;
        string opSymbol;
        int instructionByte;

        public Decompiler(ScoFile parent, Stream stream)
            : base(parent, stream)
        {
            this.sb = new StringBuilder();
            this.tw = new StringWriter(this.sb);
        }

        public override void StartLine()
        {
            needSpace = false;
            reallyNeedSpace = false;
            needComma = false;
            firstChar = true;
            opSymbol = null;
            base.StartLine();
        }

        public override void EndLine()
        {
            if (opSymbol == "!")
            {
                tw.Write(opSymbol);
            }
            else if (needComma)
            {
                tw.Write(':');
            }
            tw.WriteLine();

            if (this.sb.Length > 4194304)
            {

            }

            base.EndLine();
        }

        void outputChar(char c)
        {
            tw.Write(c);
            needSpace = true;
        }

        void outputSpace()
        {
            if (needSpace)
            {
                tw.Write(' ');
                needSpace = false;
            }
        }

        void outputComma()
        {
            if (needComma)
            {
                tw.Write(',');
                needSpace = true;
                needComma = false;
            }
            outputSpace();
        }

        void outputToken(string token)
        {
            if (!needComma && opSymbol != null && opSymbol != "!")
            {
                tw.Write(token);
                tw.Write(opSymbol);
                opSymbol = "!";
            }
            else
            {
                outputComma();
                tw.Write(token);
                needComma = true;
                needSpace = true;
            }
        }

        public override int getAddress()
        {
            var address = base.getAddress();
            if (instructionByte == '\\' && address == 0)
            {
                outputToken("0");
                return address;
            }

            if (Parent != null && Parent.LabelsInverse.ContainsKey(address))
            {
                outputToken(Parent.LabelsInverse[address]);
            }
            else
            {
                outputToken("lbl" + address.ToString("X"));
            }
            return address;
        }

        public override int getC()
        {
            int c = base.getC();
            if (firstChar)
            {
                instructionByte = c;
                switch (c)
                {
                    case 0x10: opSymbol = "+:"; break;
                    case 0x11: opSymbol = "-:"; break;
                    case 0x12: opSymbol = "*:"; break;
                    case 0x13: opSymbol = "/:"; break;
                    case 0x14: opSymbol = "%:"; break;
                    case 0x15: opSymbol = "&:"; break;
                    case 0x16: opSymbol = "|:"; break;
                    case 0x17: opSymbol = "^:"; break;
                    case '!': opSymbol = ":"; break;
                }
            }

            if (firstChar && opSymbol != null)
            {
                tw.Write('!');
            }
            else
            {
                if (reallyNeedSpace)
                {
                    tw.Write(' ');
                    reallyNeedSpace = false;
                }
                if (c < 10)
                {
                    tw.Write((char)(c + '0'));
                    needSpace = true;
                }
                else if (c >= 'A' && c <= 'Z')
                {
                    tw.Write((char)c);
                    needSpace = true;
                }
                else if ("+-*/><=\\&|^~!#$%&@]{".Contains((char)c))
                {
                    tw.Write((char)c);
                    needSpace = true;
                }
                else
                {
                    if (instructionByte == '/')
                    {

                    }

                    outputSpace();
                    tw.Write(c.ToString());
                    needSpace = true;
                    reallyNeedSpace = true;
                }
            }
            firstChar = false;
            return c;
        }

        public override Expr getCaliValue()
        {
            var expr = base.getCaliValue();
            outputToken(expr.ToString());
            return expr;
        }

        public override Expr getCaliVariable()
        {
            var expr = base.getCaliVariable();
            outputToken(expr.ToString());
            return expr;
        }

        public override Expr getVariable()
        {
            var expr = base.getVariable();
            outputToken(expr.ToString());
            return expr;
        }

        public override int getDw()
        {
            int v = base.getDw();
            outputToken(v.ToString());
            return v;
        }

        public override string getMessage()
        {
            string message = base.getMessage();
            if (message == null)
            {
                return message;
            }
            else
            {
                tw.Write('\'');
                tw.Write(EscapeMessage(message));
                tw.Write('\'');

                return message;
            }
        }

        public override string getAinMessage()
        {
            int messageNumber = GetDwInternal();
            string message = this.ainMessages.GetOrNull(messageNumber);

            tw.Write(' ');
            tw.Write(messageNumber.ToString());
            tw.Write(' ');

            //string message = base.getAinMessage();
            if (message == null)
            {
                return message;
            }
            else
            {
                tw.Write('\'');
                tw.Write(EscapeMessage(message));
                tw.Write('\'');
                return message;
            }
        }

        public override string getString(int terminator)
        {
            string str = base.getString(terminator);
            outputToken("\"" + EscapeString(str) + "\"");
            return str;
        }

        public override string getConstString()
        {
            string str = base.getConstString();
            outputToken("\"" + EscapeString(str) + "\"");
            return str;
        }

        private string EscapeString(string str)
        {
            return StringUtil.EscapeString(str, '"');
        }

        private string EscapeMessage(string message)
        {
            return StringUtil.EscapeString(message, '\'');
        }

        //public override Expr getValue40()
        //{
        //    var expr = base.getValue40();
        //    return expr;
        //}

        public override int getW()
        {
            int w = base.getW();
            outputToken(w.ToString());
            return w;
        }

        public override void err(string errorMessage)
        {
            base.err(errorMessage);
        }

        public override void getExternalAddress(out int fileNumber, out int address)
        {
            fileNumber = base.GetWInternal();
            address = base.GetDwInternal();

            var scoFile = Parent.Parent.GetFile(fileNumber);
            if (scoFile != null)
            {
                string labelName = Parent.Parent.AddExternalLabel(fileNumber, address);
                outputToken(labelName);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public override void getExternalAddress2(out int fileNumber, out int address)
        {
            fileNumber = -1;
            address = -1;

            int w = GetWInternal();
            if (w == 0)
            {
                outputToken("0");
                getCaliValue();
                return;
            }
            else if (w == 65535)
            {
                outputToken("65535");
                getCaliVariable();
                return;
            }
            else
            {
                fileNumber = w;
                address = GetDwInternal();
            }

            if (fileNumber != -1)
            {
                var scoFile = Parent.Parent.GetFile(fileNumber);
                if (scoFile != null)
                {
                    string labelName = Parent.Parent.AddExternalLabel(fileNumber, address);
                    outputToken(labelName);
                }
                else
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                throw new ArgumentException();
            }
        }
    }

    public class Relinker : DecompilerBase
    {
        BinaryWriter bw;
        public override int getAddress()
        {
            int codeAddress = (int)stream.Position;
            int address = base.getAddress();
            string labelName = Parent.AddLabel(address);
            this.Parent.Fixups.Add(new ScoFile.Fixup(labelName, codeAddress));

            //stream.Position = codeAddress;
            //bw.Write(0xDEADBEEF);

            return address;
        }

        public override void getExternalAddress(out int fileNumber, out int address)
        {
            int codeAddress = (int)stream.Position;

            fileNumber = base.GetWInternal();
            address = base.GetDwInternal();

            //stream.Position = codeAddress;
            //bw.Write((ushort)0xBAAD);
            //bw.Write(0xDEADBEEF);


            var scoFile = Parent.Parent.GetFile(fileNumber);
            if (scoFile != null)
            {
                string labelName = Parent.Parent.AddExternalLabel(fileNumber, address);
                this.Parent.Fixups.Add(new ScoFile.Fixup(labelName, codeAddress, 0));
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public override void getExternalAddress2(out int fileNumber, out int address)
        {
            int codeAddress = (int)stream.Position;
            fileNumber = -1;
            address = -1;

            int w = GetWInternal();
            if (w == 0)
            {
                getCaliValue();
                return;
            }
            else if (w == 65535)
            {
                getCaliVariable();
                return;
            }
            else
            {
                fileNumber = w;
                address = GetDwInternal();
            }

            if (fileNumber != -1)
            {
                var scoFile = Parent.Parent.GetFile(fileNumber);
                if (scoFile != null)
                {
                    string labelName = Parent.Parent.AddExternalLabel(fileNumber, address);
                    this.Parent.Fixups.Add(new ScoFile.Fixup(labelName, codeAddress, 0));

                    //stream.Position = codeAddress;
                    //bw.Write((ushort)0xBAAD);
                    //bw.Write(0xDEADBEEF);
                }
                else
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public Relinker(ScoFile parent, Stream stream)
            : base(parent, stream)
        {
            this.bw = new BinaryWriter(stream);
        }
    }

    public static partial class Extensions
    {
        public static int PeekByte(this Stream stream)
        {
            int b = stream.ReadByte();
            stream.Position--;
            return b;
        }
        public static void BinaryOperation(this Stack<Expr> stack, string symbol)
        {
            var e2 = stack.Pop();
            var e1 = stack.Pop();
            var e = new Expr(symbol, e1, e2);
            stack.Push(e);
        }
    }
}
