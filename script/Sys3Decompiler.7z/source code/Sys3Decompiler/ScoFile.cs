﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using ALDExplorer;
using System.Globalization;

namespace Sys3Decompiler
{
    public class ScoFiles
    {
        public static ScoFiles DefaultInstance;

        public int EncodingMode = 0;
        public string Signature = "S380";

        public AinFile AinFile;
        public AldFile Parent;
        Dictionary<int, ScoFile> scoFiles = new Dictionary<int, ScoFile>();
        public class ReportProgressEventArgs : EventArgs
        {
            public int Value { get; set; }
            public string Message { get; set; }
            public ReportProgressEventArgs(int value, string message)
            {
                this.Value = value;
                this.Message = message;
            }
        }
        public event EventHandler<ReportProgressEventArgs> ReportProgress;
        public event EventHandler<ErrorEventArgs> Error;

        public void OnReportProgress(int value, string message)
        {
            if (this.ReportProgress != null)
            {
                this.ReportProgress(this, new ReportProgressEventArgs(value, message));
            }
        }

        internal void OnError(ErrorEventArgs errorEventArgs)
        {
            if (this.Error != null)
            {
                this.Error(this, errorEventArgs);
            }
        }

        public ScoFiles()
        {
            DefaultInstance = this;
            this.AinFile = null;
            this.Parent = null;
            this.scoFiles = null;
        }

        public ScoFiles(string aldFileName)
        {
            DefaultInstance = this;
            LoadAldFile(aldFileName);
        }

        public void LoadAldFile(string aldFileName)
        {
            this.Parent = new AldFile();
            this.Parent.ReadFile(aldFileName);
            this.AinFile = new AinFile();
            string ainFileName = Path.Combine(Path.GetDirectoryName(aldFileName), "System39.ain");
            this.AinFile.LoadAinFile(ainFileName);

            if (this.AinFile.variableNames.Length > 0)
            {
                LoadVariableNames();
            }

            if (this.AinFile.ainMessages.Length > 0)
            {
                LoadMessages();
            }

            LoadScoFiles();

            if (this.AinFile.functions.Count > 0)
            {
                LoadFunctions();
            }
        }

        private void LoadFunctions()
        {
            var functions = this.AinFile.functions;
            this.LabelNameToFileNumber.Clear();
            int length = functions.Count;
            for (int i = 0; i < length; i++)
            {
                var funcEntry = functions[i];
                AddExternalLabel(funcEntry.FileNumber, funcEntry.Address, funcEntry.FunctionName);
                var scoFile = this.GetFile(funcEntry.FileNumber);
                if (scoFile != null)
                {
                    scoFile.addressQueue.Enqueue(funcEntry.Address);
                }
            }
        }

        private void LoadMessages()
        {
            var messages = this.AinFile.ainMessages;
            this.MessagesList.Clear();
            this.Messages.Clear();
            int length = messages.Length;
            this.MessagesList.Capacity = length;

            for (int i = 0; i < length; i++)
            {
                string message = messages[i];
                this.Messages[message] = i;
                this.MessagesList.SetOrAdd(i, message);
            }
        }

        private void LoadVariableNames()
        {
            var variableNames = this.AinFile.variableNames;
            this.VariablesList.Clear();
            this.Variables.Clear();
            int length = variableNames.Length;
            this.VariablesList.Capacity = length;

            for (int i = 0; i < length; i++)
            {
                string variableName = variableNames[i];
                this.Variables[variableName] = i;
                this.VariablesList.SetOrAdd(i, variableName);
            }
        }

        private void LoadScoFiles()
        {
            this.scoFiles = this.Parent.FileEntries.Select(e => new ScoFile(this, e)).ToDictionary(s => s.index);
            foreach (var scoFile in this.GetFiles())
            {
                var ms = new MemoryStream(scoFile.bytes);
                var decompilerBase = new DecompilerBase(scoFile, ms);
                this.Signature = scoFile.signature;
                if (scoFile.signature == "S380")
                {
                    scoFile.Parent.EncodingMode = 2;
                }
            }
        }

        public ScoFile GetFile(int fileNumber)
        {
            return this.scoFiles.GetOrNull(fileNumber);
        }

        public void FindLabels()
        {
            var scoFiles = this.scoFiles.Values.ToArray();
            int totalFiles = scoFiles.Length;
            int onFile = 0;
            OnReportProgress(0, "Finding Labels...");
            while (true)
            {
                foreach (var scoFile in scoFiles)
                {
                    onFile++;
                    OnReportProgress(100 * onFile / totalFiles, "Finding Labels...");
                    scoFile.FindLabels();
                }
                int sum = 0;
                foreach (var scoFile in scoFiles)
                {
                    sum += scoFile.addressQueue.Count;
                }
                if (sum == 0)
                {
                    break;
                }
            }
        }

        public ScoFile[] GetFiles()
        {
            return this.scoFiles.Values.OrderBy(v => v.index).ToArray();
        }

        List<string> VariablesList = new List<string>();
        Dictionary<string, int> Variables = new Dictionary<string, int>();

        List<string> MessagesList = new List<string>();
        Dictionary<string, int> Messages = new Dictionary<string, int>();

        public string AddVariable(int variableIndex)
        {
            string variableName = this.VariablesList.GetOrNull(variableIndex);
            if (variableName != null)
            {
                return variableName;
            }

            variableName = "VAR" + variableIndex.ToString("0000");
            this.Variables[variableName] = variableIndex;
            if (variableIndex > 3000)
            {
                return variableName;
            }

            this.VariablesList.SetOrAdd(variableIndex, variableName);
            return variableName;
        }

        public int GetVariable(string variableName)
        {
            if (Variables.ContainsKey(variableName))
            {
                return Variables[variableName];
            }
            if (variableName.StartsWith("VAR"))
            {
                int variableNumber;
                var sr = new StringReader(variableName.Substring(3));
                string variableNumberString = sr.ReadToken();

                if (IntUtil.TryParse(variableNumberString, out variableNumber) && variableNumber < 3000)
                {
                    if (this.VariablesList.GetOrNull(variableNumber) == null)
                    {
                        this.VariablesList.SetOrAdd(variableNumber, variableName);
                        this.Variables[variableName] = variableNumber;
                        return variableNumber;
                    }
                }
            }

            int newIndex = this.VariablesList.Count;
            this.VariablesList.SetOrAdd(newIndex, variableName);
            this.Variables[variableName] = newIndex;
            return newIndex;
        }

        public int AddMessage(string message)
        {
            return AddMessage(message, -1);
        }

        public int AddMessage(string message, int messageNumberHint)
        {
            //if (messageNumberHint == -1)
            //{
            //    if (Messages.ContainsKey(message))
            //    {
            //        return Messages[message];
            //    }
            //}
            if (messageNumberHint >= 0)
            {
                string existingMessage = this.MessagesList.GetOrNull(messageNumberHint);
                if (existingMessage == message)
                {
                    return messageNumberHint;
                }
                if (existingMessage == null)
                {
                    this.MessagesList.SetOrAdd(messageNumberHint, message);
                    this.Messages[message] = messageNumberHint;
                    return messageNumberHint;
                }
            }
            int newIndex = this.MessagesList.Count;
            this.MessagesList.SetOrAdd(newIndex, message);
            this.Messages[message] = newIndex;
            return newIndex;
        }

        Dictionary<string, int> LabelNameToFileNumber = new Dictionary<string, int>();

        public string AddExternalLabel(int fileNumber, int address, string labelName)
        {
            var scoFile = GetFile(fileNumber);
            if (scoFile == null)
            {
                throw new ArgumentException();
            }
            scoFile.Labels[labelName] = address;
            scoFile.LabelsInverse[address] = labelName;
            this.LabelNameToFileNumber[labelName] = fileNumber;
            return labelName;
        }

        public void GetExternalLabel(string labelName, out int fileNumber, out int address)
        {
            if (!LabelNameToFileNumber.ContainsKey(labelName))
            {
                fileNumber = -1;
                address = -1;
                return;
            }
            fileNumber = LabelNameToFileNumber[labelName];
            var scoFile = GetFile(fileNumber);
            if (scoFile == null || !scoFile.Labels.ContainsKey(labelName))
            {
                fileNumber = -1;
                address = -1;
                return;
            }
            address = scoFile.Labels[labelName];
        }

        public string AddExternalLabel(int fileNumber, int address)
        {
            var scoFile = GetFile(fileNumber);
            if (scoFile == null)
            {
                throw new ArgumentException();
            }
            if (scoFile.LabelsInverse.ContainsKey(address))
            {
                string oldLabelName = scoFile.LabelsInverse[address];
                if (oldLabelName.StartsWith("lbl", StringComparison.Ordinal))
                {

                }
                else
                {
                    return oldLabelName;
                }
            }
            string newLabelName = Path.ChangeExtension(scoFile.FileName, null).Replace(" ", "_") + "_" + address.ToString("X");
            return AddExternalLabel(fileNumber, address, newLabelName);
        }


        public string[] Decompile()
        {
            List<string> sourceCode = new List<string>();
            var files = GetFiles();
            foreach (var file in files)
            {
                var sw = new StringWriter();
                file.Decompile(sw);
                string source = sw.ToString();
                sourceCode.Add(source);
            }
            return sourceCode.ToArray();
        }

        public bool Compile(string[] sourceFileNames, string[] sourceCode)
        {
            this.AinFile = new AinFile();
            this.Parent = new AldFile();
            this.scoFiles = new Dictionary<int, ScoFile>();
            bool result = true;

            for (int i = 0; i < sourceFileNames.Length; i++)
            {
                var scoFile = new ScoFile();
                scoFile.FileName = sourceFileNames[i];
                scoFile.fileNumber2 = i;
                scoFile.index = i + 1;
                scoFile.signature = this.Signature ?? "S380";
                scoFile.Parent = this;
                this.scoFiles.Add(i + 1, scoFile);
            }

            for (int i = 0; i < sourceFileNames.Length; i++)
            {
                var scoFile = this.scoFiles[i + 1];
                var stringReader = new StringReader(sourceCode[i]);
                scoFile.Compile(stringReader);
            }

            foreach (var scoFile in this.GetFiles())
            {
                if (!scoFile.ApplyFixups())
                {
                    result = false;
                }
                var newFileEntry = new AldFileEntry();
                newFileEntry.ReplacementFileData = scoFile.bytes;
                newFileEntry.FileName = Path.ChangeExtension(scoFile.FileName, "SCO");
                newFileEntry.FileNumber = scoFile.index;
                newFileEntry.FileLetter = 1;
                newFileEntry.Index = scoFile.fileNumber2 - 1;
                this.Parent.FileEntries.Add(newFileEntry);
            }

            this.AinFile.variableNames = this.VariablesList.ToArray();
            this.AinFile.ainMessages = this.MessagesList.ToArray();
            return result;
        }

        public bool ContainsExternalLabel(string labelName)
        {
            return this.LabelNameToFileNumber.ContainsKey(labelName);
        }

        public bool CompileOver(string[] sourceCode)
        {
            this.AinFile.functions = new AinFile.FunctionCollection();
            this.AinFile.ainMessages = new string[0];
            this.MessagesList.Clear();
            this.Messages.Clear();
            this.LabelNameToFileNumber.Clear();


            var scoFiles = this.GetFiles();

            foreach (var scoFile in scoFiles)
            {
                scoFile.addressQueue.Clear();
                scoFile.bytes = new byte[0];
                scoFile.FileSize = 0;
                scoFile.Fixups.Clear();
                scoFile.Labels.Clear();
                scoFile.LabelsInverse.Clear();
                scoFile.seenAddresses.Clear();
            }

            for (int i = 0; i < scoFiles.Length; i++)
            {
                var scoFile = scoFiles[i];
                string source = sourceCode[i];
                var sr = new StringReader(source);
                scoFile.Compile(sr);
            }

            bool result = true;
            foreach (var scoFile in scoFiles)
            {
                if (!scoFile.ApplyFixups())
                {
                    result = false;
                }
                var fileEntry = scoFile.GetFileEntry();
                fileEntry.ReplacementFileData = scoFile.bytes;
            }

            FinalizeAinFile();
            return result;
        }

        private AinFile.FunctionEntry[] GetFunctions()
        {
            List<AinFile.FunctionEntry> functionsList = new List<AinFile.FunctionEntry>();
            foreach (var pair in this.LabelNameToFileNumber)
            {
                string functionName = pair.Key;
                int fileNumber = pair.Value;
                var scoFile = this.GetFile(fileNumber);
                int address = scoFile.Labels[functionName];
                functionsList.Add(new AinFile.FunctionEntry(functionName, fileNumber, address));
            }
            functionsList.Sort();
            return functionsList.ToArray();
        }

        public void Relink()
        {
            OnReportProgress(0, "Preparing for relinking...");
            var scoFiles = this.GetFiles();
            int onFile = 0;
            int totalFiles = scoFiles.Length;
            foreach (var scoFile in scoFiles)
            {
                onFile++;
                OnReportProgress(100 * onFile / totalFiles, "Preparing for relinking...");
                scoFile.Relink();
            }

            ApplyFixups();
        }

        public bool ApplyFixups()
        {
            var scoFiles = this.GetFiles();
            bool success = true;
            foreach (var scoFile in scoFiles)
            {
                if (!scoFile.ApplyFixups())
                {
                    success = false;
                }

            }
            return success;
        }

        public void FinalizeAinFile()
        {
            this.AinFile.variableNames = this.VariablesList.ToArray();
            this.AinFile.ainMessages = this.MessagesList.ToArray();
            this.AinFile.functions = new AinFile.FunctionCollection();
            this.AinFile.functions.AddRange(this.GetFunctions());
        }

        public void ClearMessages()
        {
            this.Messages.Clear();
            this.MessagesList.Clear();
        }
    }

    public class ScoFile
    {
        public Dictionary<string, int> Labels = new Dictionary<string, int>();
        public Dictionary<int, string> LabelsInverse = new Dictionary<int, string>();

        public string signature;
        public int fileNumber2;

        public struct Fixup
        {
            public int Address;
            public int FileNumber;
            public string LabelName;
            public Fixup(string labelName, int address)
            {
                this.Address = address;
                this.LabelName = labelName;
                this.FileNumber = -1;
            }
            public Fixup(string labelName, int address, int fileNumber)
            {
                this.Address = address;
                this.LabelName = labelName;
                this.FileNumber = fileNumber;
            }
        }

        public List<Fixup> Fixups = new List<Fixup>();

        public int index;
        public string ScoFileName;
        public string FileName;
        public ScoFiles Parent;
        public byte[] bytes;
        public int FileSize;

        public ScoFile()
        {

        }

        public ScoFile(ScoFiles parent, AldFileEntry entry)
        {
            LoadAldFile(parent, entry);
        }

        public void LoadAldFile(ScoFiles parent, AldFileEntry entry)
        {
            this.Parent = parent;
            this.bytes = entry.GetFileData();
            this.index = entry.FileNumber;
            this.ScoFileName = entry.FileName;
        }

        public Dictionary<int, int> seenAddresses = new Dictionary<int, int>();
        public Queue<int> addressQueue = new Queue<int>();

        //int labelIsExternal;
        //int instructionByte = -1;
        //int lastAddress = -1;

        public void Decompile(TextWriter tw_)
        {
            TextWriterWrapper tw = new TextWriterWrapper(tw_);

            var ms = new MemoryStream(bytes);
            var br = new BinaryReader(ms);
            var decompiler = new Decompiler(this, ms);
            decompiler.tw = tw;
            while (true)
            {
                if (ms.Position >= ms.Length)
                {
                    break;
                }
                int address = (int)ms.Position;
                if (address >= 0x4f0)
                {

                }

                if (this.LabelsInverse.ContainsKey(address))
                {
                    string labelName = this.LabelsInverse[address];
                    if (Parent.ContainsExternalLabel(labelName))
                    {
                        tw.WriteLine("**" + labelName + ":");
                    }
                    else
                    {
                        tw.WriteLine("*" + labelName + ":");
                    }
                }

                int lineType = this.seenAddresses.GetOrDefault(address, -1);

                if (lineType == 0)
                {
                    try
                    {
                        decompiler.ParseLine();
                    }
                    catch (OperationCanceledException)
                    {
                        decompiler.EndLine();
                    }
                    catch (Exception ex)
                    {
                        RaiseError("Decompile error", ms.Position, tw.LineNumber + 1, tw.Column + 1, ex);
                        this.seenAddresses[address] = 2;
                        ms.Position = address;
                        tw.WriteLine();
                        continue;
                    }
                }
                else if (lineType == 1)
                {
                    int addr = br.ReadInt32();
                    string labelName;
                    if (LabelsInverse.ContainsKey(addr))
                    {
                        labelName = LabelsInverse[addr];
                    }
                    else
                    {
                        labelName = "lbl" + addr.ToString("X");
                    }
                    tw.WriteLine("_" + labelName + ":");
                }
                else
                {
                    bool hasSeenText = false;
                    //first check for valid null-terminated Shift-JIS string (fullwidth and ASCII charactes only)
                    while (ms.Position < ms.Length && this.seenAddresses.GetOrDefault((int)ms.Position, 2) == 2)
                    {
                        if (ms.Position != address && this.LabelsInverse.ContainsKey((int)ms.Position))
                        {
                            goto DoneWithData;
                        }
                        int v = TextConverter.NumberOfValidBytesAtPosition(br);

                        if (v >= 3 || (v >= 2 && ms.Position != address))
                        {
                            int terminator = this.bytes[(int)ms.Position + v];
                            if (terminator == 0)
                            {
                                hasSeenText = true;
                                string message = br.ReadStringNullTerminated();
                                tw.Write('\'');
                                tw.Write(StringUtil.EscapeString(message, '\''));
                                tw.WriteLine('\'');
                                tw.WriteLine("[00]");
                            }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            if (hasSeenText == true && v == 0 && this.bytes[(int)ms.Position] == 0)
                            {
                                tw.WriteLine("[00]");
                                ms.Position++;
                                //hasSeenText = false;
                                continue;
                            }
                            break;
                        }
                    }
                    //emit data
                    if (!(ms.Position != address && this.LabelsInverse.ContainsKey((int)ms.Position)))
                    {

                        tw.Write("[");
                        while (ms.Position < ms.Length && this.seenAddresses.GetOrDefault((int)ms.Position, 2) == 2)
                        {
                            if (ms.Position != address && this.LabelsInverse.ContainsKey((int)ms.Position))
                            {
                                break;
                            }

                            int b = ms.ReadByte();
                            tw.Write(b.ToString("X2"));
                        }
                        tw.Write("]");
                        tw.WriteLine();
                    }
                }
            DoneWithData: ;
            }


        }

        private void RaiseError(string errorMessage, long address, int lineNumber, int column, Exception ex)
        {
            errorMessage = errorMessage + " (file \"" + Path.GetFileName(this.FileName) + "\", address " + address.ToString("X") + ", line " + lineNumber.ToString() + ", column " + column.ToString() + ")";
            RaiseError(errorMessage, ex);
        }
        private void RaiseError(string errorMessage, long address, Exception ex)
        {
            errorMessage = errorMessage + " (file \"" + Path.GetFileName(this.FileName) + "\", address " + address.ToString("X") + ")";
            RaiseError(errorMessage, ex);
        }

        private void RaiseError(string errorMessage, Exception ex)
        {
            string exMessage = ex.Message;
            string defaultExceptionText = ((Exception)Activator.CreateInstance(ex.GetType())).Message;

            if (exMessage == defaultExceptionText)
            {
                string functionName = ex.TargetSite.Name;
                if (functionName == "err")
                {
                    var stackTraceLines = ex.StackTrace.Split("\r\n");
                    foreach (var line in stackTraceLines)
                    {
                        const string lookFor = "at ";
                        int indexOfAt = line.IndexOf(lookFor);
                        if (indexOfAt == -1)
                        {
                            continue;
                        }
                        int indexAfterAt = indexOfAt + lookFor.Length;

                        int indexOfOpenParen = line.IndexOf('(', indexAfterAt);
                        if (indexOfOpenParen == -1) indexOfOpenParen = line.Length;
                        functionName = line.Substring(indexAfterAt, indexOfOpenParen - indexAfterAt);
                        int lastDot = functionName.LastIndexOf('.');
                        if (lastDot == -1) lastDot = -1;
                        functionName = functionName.Substring(lastDot + 1);
                        if (functionName == "err")
                        {

                        }
                        else
                        {
                            break;
                        }

                    }

                    //ex.StackTrace
                }

                exMessage = "Exception from " + functionName;
            }
            errorMessage = errorMessage + ": " + exMessage;
            OnError(new ErrorEventArgs(new Exception(errorMessage, ex)));
        }

        public event EventHandler<ErrorEventArgs> Error;

        private void OnError(ErrorEventArgs errorEventArgs)
        {
            if (Error != null)
            {
                Error(this, errorEventArgs);
            }
            if (Parent != null)
            {
                Parent.OnError(errorEventArgs);
            }
        }

        public void FindLabels()
        {
            var ms = new MemoryStream(bytes);
            var br = new BinaryReader(ms);
            var labelFinder = new LabelFinderParser(this, ms);
            AddLabel((int)ms.Position);
            addressQueue.Enqueue((int)ms.Position);

            while (addressQueue.Count > 0)
            {
                int address = addressQueue.Dequeue();
                if (seenAddresses.ContainsKey(address))
                {
                    continue;
                }
                if (address <= 0 || address > ms.Length)
                {
                    continue;
                }

                if (address - 5 >= 0 && bytes[address - 5] == '@' && !seenAddresses.ContainsKey(address - 5))
                {
                    ms.Position = address - 4;
                    //if (br.ReadInt32() == address)
                    int jumpAddr = br.ReadInt32();
                    if (jumpAddr >= address && jumpAddr < address + 1024 && jumpAddr < FileSize)
                    {
                        addressQueue.Enqueue(address - 5);
                        //seenAddresses.Add(address - 5, 0);
                    }
                }


                ms.Position = address;
                labelFinder.Continue = true;

                while (labelFinder.Continue)
                {
                    if (seenAddresses.ContainsKey((int)ms.Position))
                    {
                        break;
                    }
                    try
                    {
                        labelFinder.ParseLine();
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch
                    {
                        //this.seenAddresses[(int)ms.Position] = 2;
                        break;
                    }
                }
            }
        }

        public void Compile(TextReader tr_)
        {
            TextReader tr = RemoveComments(tr_);

            bool seenOnce = false;
            var compiler = new Compiler(this, tr);
            while (tr.Peek() != -1)
            {
                if (compiler.Address >= 5216)
                {
                    if (!seenOnce)
                    {
                        seenOnce = true;
                    }
                }
                try
                {
                    compiler.ParseLine();
                }
                catch (OperationCanceledException)
                {

                }
                catch (Exception ex)
                {
                    RaiseError("Compile Error", compiler.Address, compiler.LineNumber + 1, compiler.Column + 1, ex);
                }
            }
            compiler.FinishFile();
            var oldBytes = this.bytes;
            var newBytes = compiler.ToByteArray();
            this.bytes = newBytes;
            ApplyFixups();

            if (oldBytes != null && oldBytes.Length > 0 && !oldBytes.SequenceEqual(newBytes))
            {
                List<int> failures = new List<int>();
                int i;
                int length = Math.Min(oldBytes.Length, newBytes.Length);
                for (i = 0; i < length; i++)
                {
                    if (oldBytes[i] != newBytes[i])
                    {
                        failures.Add(i);
                    }
                }
                if (failures.Count > 0)
                {

                }
                this.bytes = oldBytes;
            }
        }

        TextReader RemoveComments(TextReader tr)
        {
            StringWriter sw = new StringWriter();
            RemoveComments(tr, sw);
            StringReader sr = new StringReader(sw.ToString());
            return sr;
        }

        private void RemoveComments(TextReader tr, TextWriter tw)
        {
            string line;
            while (true)
            {
                line = tr.ReadLine();
                if (line == null)
                {
                    break;
                }
                int position = 0;
                while (true)
                {
                    int indexOfSemicolon = line.IndexOf(';', position);
                    int indexOfApostrophe = line.IndexOf('\'', position);
                    int indexOfDoubleQuote = line.IndexOf('"', position);
                    if (indexOfSemicolon == -1) break;
                    if (indexOfApostrophe == -1) indexOfApostrophe = line.Length;
                    if (indexOfDoubleQuote == -1) indexOfDoubleQuote = line.Length;

                    if (indexOfSemicolon < Math.Min(indexOfApostrophe, indexOfDoubleQuote))
                    {
                        line = line.Substring(0, indexOfSemicolon);
                        break;
                    }

                    if (indexOfApostrophe < indexOfDoubleQuote)
                    {
                        //look for closing apostrophe (not escaped)
                        int i = indexOfApostrophe + 1;
                        while (i < line.Length && line[i] != '\'')
                        {
                            if (line[i] == '\\')
                            {
                                i++;
                            }
                            i++;
                        }
                        position = i + 1;
                    }
                    else if (indexOfDoubleQuote < indexOfApostrophe)
                    {
                        //look for closing quote (not escaped)
                        int i = indexOfDoubleQuote + 1;
                        while (i < line.Length && line[i] != '"')
                        {
                            if (line[i] == '\\')
                            {
                                i++;
                            }
                            i++;
                        }
                        position = i + 1;
                    }
                    else
                    {
                        //no apostrophe or closing quote found
                        break;
                    }
                }
                tw.WriteLine(line);
            }
        }

        public bool ApplyFixups()
        {
            var ms = new MemoryStream(this.bytes);
            var bw = new BinaryWriter(ms);
            bool result = true;
            foreach (var fixup in this.Fixups)
            {
                ms.Position = fixup.Address;
                int fileNumber = -1;
                int labelValue = -1;

                if (fixup.FileNumber == -1 || fixup.FileNumber == index)
                {
                    labelValue = Labels.GetOrDefault(fixup.LabelName, -1);
                }
                else
                {
                    if (fixup.FileNumber == 0)
                    {
                        Parent.GetExternalLabel(fixup.LabelName, out fileNumber, out labelValue);
                    }
                    else
                    {
                        var scoFile = Parent.GetFile(fixup.FileNumber);
                        if (scoFile == null)
                        {
                            throw new ArgumentException();
                        }
                        labelValue = scoFile.Labels.GetOrDefault(fixup.LabelName, -1);
                    }
                }
                if (labelValue != -1)
                {
                    if (fixup.LabelName.StartsWith("lbl", StringComparison.Ordinal))
                    {
                        int labelNameValue = int.Parse(fixup.LabelName.Substring(3), System.Globalization.NumberStyles.HexNumber);
                        if (labelNameValue != labelValue)
                        {

                        }
                    }
                    if (fixup.FileNumber == 0)
                    {
                        bw.Write((UInt16)fileNumber);
                    }

                    bw.Write(labelValue);
                }
                else
                {
                    if (fixup.LabelName.StartsWith("lbl", StringComparison.Ordinal))
                    {
                        int labelNameValue = int.Parse(fixup.LabelName.Substring(3), System.Globalization.NumberStyles.HexNumber);
                        if (fixup.FileNumber == 0)
                        {
                            bw.Write((UInt16)fileNumber);
                        }
                        bw.Write(labelNameValue);
                    }

                    result = false;
                }

            }
            return result;
        }

        private static string[] _dummy = new string[0];

        public string[] AinMessages
        {
            get
            {
                if (Parent != null && Parent.AinFile != null && Parent.AinFile.ainMessages != null)
                {
                    return Parent.AinFile.ainMessages;
                }
                else
                {
                    return _dummy;
                }
            }
        }

        public string[] VariableNames
        {
            get
            {
                if (Parent != null && Parent.AinFile != null && Parent.AinFile.variableNames != null)
                {
                    return Parent.AinFile.variableNames;
                }
                else
                {
                    return _dummy;
                }
            }
        }

        public string AddLabel(int address)
        {
            if (this.LabelsInverse.ContainsKey(address))
            {
                return this.LabelsInverse[address];
            }
            string labelName = "lbl" + address.ToString("X");
            this.Labels[labelName] = address;
            this.LabelsInverse[address] = labelName;
            return labelName;
        }

        public string AddVariable(int variableIndex)
        {
            return Parent.AddVariable(variableIndex);
        }

        public int GetVariable(string variableName)
        {
            return Parent.GetVariable(variableName);
        }

        public int AddMessage(string message)
        {
            return Parent.AddMessage(message);
        }

        public int AddMessage(string message, int messageNumber)
        {
            return Parent.AddMessage(message, messageNumber);
        }

        public AldFileEntry GetFileEntry()
        {
            return Parent.Parent.FileEntries.GetOrNull(this.index - 1);
        }

        public void Relink()
        {
            var ms = new MemoryStream(bytes);
            var br = new BinaryReader(ms);
            var relinker = new Relinker(this, ms);

            while (true)
            {
                if (ms.Position >= ms.Length)
                {
                    break;
                }
                int address = (int)ms.Position;
                int lineType = this.seenAddresses.GetOrDefault(address, -1);

                if (lineType == 0)
                {
                    try
                    {
                        relinker.ParseLine();
                    }
                    catch (OperationCanceledException)
                    {

                    }
                    catch (Exception ex)
                    {
                        RaiseError("Decompile Error", ms.Position, ex);
                        //this.seenAddresses[address] = 2;
                        //ms.Position = address;
                        continue;
                    }
                }
                else if (lineType == 1)
                {
                    int addr = br.ReadInt32();
                }
                else
                {
                    while (ms.Position < ms.Length && this.seenAddresses.GetOrDefault((int)ms.Position, 2) == 2)
                    {
                        if (ms.Position != address && this.LabelsInverse.ContainsKey((int)ms.Position))
                        {
                            break;
                        }

                        int b = ms.ReadByte();
                    }
                }
            }
        }

        public void CompileOver(string sourceCode)
        {
            StringReader sr = new StringReader(sourceCode);

            var oldLabels = this.Labels;
            var oldLabelsInverse = this.LabelsInverse;
            this.Labels = new Dictionary<string, int>();
            this.LabelsInverse = new Dictionary<int, string>();
            this.seenAddresses.Clear();
            this.addressQueue.Clear();

            this.bytes = null;
            this.Fixups.Clear();
            this.Compile(sr);
            var fileEntry = this.GetFileEntry();
            fileEntry.ReplacementFileData = this.bytes;

            MigrateOldLabels(oldLabels, oldLabelsInverse);

        }

        private void MigrateOldLabels(Dictionary<string, int> oldLabels, Dictionary<int, string> oldLabelsInverse)
        {
            //find out what labels were removed
            HashSet<string> removedLabels = new HashSet<string>();

            foreach (var pair in oldLabels)
            {
                //migrate other old labels if necessary
                string labelName = pair.Key;
                if (!Labels.ContainsKey(labelName))
                {
                    int oldAddress = pair.Value;
                    //don't care about "lbl0"
                    if (oldAddress != 0)
                    {
                        string oldLabelName = oldLabelsInverse.GetOrNull(oldAddress) ?? "";
                        int newAddress = Labels.GetOrDefault(oldLabelName, -1);
                        if (newAddress != -1)
                        {
                            //label migrated
                            Labels[labelName] = newAddress;
                        }
                        else
                        {
                            //failed to relocate an old label
                            removedLabels.Add(labelName);
                        }
                    }
                }
            }

            if (removedLabels.Count > 0)
            {
                //if we removed any labels, check if they need to be removed from the AinFile function list.
                var functions = this.Parent.AinFile.functions;
                for (int i = 0; i < functions.Count; i++)
                {
                    var function = functions[i];
                    if (removedLabels.Contains(function.FunctionName))
                    {
                        functions.RemoveAt(i);
                        i--;
                    }
                }
            }
        }
    }

    public class TextWriterWrapper : TextWriter
    {
        public int LineNumber { get; set; }
        public int Column { get; set; }

        public TextWriterWrapper(TextWriter tw)
        {
            this.tw = tw;
        }

        TextWriter tw;

        #region inherited members

        public override Encoding Encoding
        {
            get
            {
                return tw.Encoding;
            }
        }

        public override void Close()
        {
            tw.Close();
        }

        public override void Flush()
        {
            tw.Flush();
        }

        public override System.Runtime.Remoting.ObjRef CreateObjRef(Type requestedType)
        {
            return tw.CreateObjRef(requestedType);
        }

        public override IFormatProvider FormatProvider
        {
            get
            {
                return tw.FormatProvider;
            }
        }

        public override object InitializeLifetimeService()
        {
            return tw.InitializeLifetimeService();
        }

        public override string ToString()
        {
            return tw.ToString();
        }

        #endregion

        public override void Write(char value)
        {
            if (value == '\n')
            {
                LineNumber++;
                Column = 0;
            }
            else
            {
                Column++;
            }
            tw.Write(value);
        }

        public override void Write(char[] buffer, int index, int count)
        {
            AdvancePosition(buffer, index, count);
            tw.Write(buffer, index, count);
        }

        public override void Write(string value)
        {
            AdvancePosition(value);
            tw.Write(value);
        }

        private void AdvancePosition(string value)
        {
            int limit = value.Length;
            int indexOfNewLine = 0;
            while (true)
            {
                int nextIndexOfNewLine = value.IndexOf('\n', indexOfNewLine, limit - indexOfNewLine);
                if (nextIndexOfNewLine == -1 || nextIndexOfNewLine >= limit)
                {
                    int displacement = limit - indexOfNewLine;
                    Column += displacement;
                    break;
                }
                else
                {
                    LineNumber++;
                    Column = 0;
                }
                indexOfNewLine = nextIndexOfNewLine + 1;
            }
        }

        private void AdvancePosition(char[] buffer, int index, int count)
        {
            int limit = index + count;
            int indexOfNewLine = index;
            while (true)
            {
                int nextIndexOfNewLine = Array.IndexOf<char>(buffer, '\n', indexOfNewLine, limit - indexOfNewLine);
                if (nextIndexOfNewLine == -1 || nextIndexOfNewLine >= limit)
                {
                    int displacement = limit - indexOfNewLine;
                    Column += displacement;
                    break;
                }
                else
                {
                    LineNumber++;
                    Column = 0;
                }
                indexOfNewLine = nextIndexOfNewLine + 1;
            }
        }


    }
}
