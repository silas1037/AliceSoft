﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Windows.Forms;
using ALDExplorer;

namespace Sys3Decompiler
{
    public partial class DecompilerForm : Form
    {
        ScoFiles scoFiles;
        string filenameToLoad;

        public DecompilerForm(string filenameToLoad)
            : this()
        {
            this.filenameToLoad = filenameToLoad;
        }

        public DecompilerForm()
        {
            InitializeComponent();
        }

        private void DecompilerForm_Load(object sender, EventArgs e)
        {
            Application.Idle += new EventHandler(Application_Idle);
        }

        void Application_Idle(object sender, EventArgs e)
        {
            Application.Idle -= new EventHandler(Application_Idle);
            if (!String.IsNullOrEmpty(filenameToLoad))
            {
                LoadFile(filenameToLoad);
            }
        }

        void TestRelinker()
        {
            var scoFiles = this.scoFiles.GetFiles();
            var eachBytes = scoFiles.Select(s => (byte[])s.bytes.Clone()).ToArray();


            foreach (var scoFile in scoFiles)
            {
                scoFile.Relink();
            }
            foreach (var scoFile in scoFiles)
            {
                scoFile.ApplyFixups();
            }
            var eachBytes2 = scoFiles.Select(s => (byte[])s.bytes).ToArray();

            for (int i = 0; i < eachBytes.Length; i++)
            {
                if (!eachBytes[i].SequenceEqual(eachBytes2[i]))
                {

                }

            }

        }

        private void TestCompiler()
        {
            var oldDefInstance = ScoFiles.DefaultInstance;

            var sourceFiles = scoFiles.Decompile();
            var fileNames = scoFiles.GetFiles().Select(f => f.FileName).ToArray();
            var newScoFiles = new ScoFiles();
            if (!newScoFiles.Compile(fileNames, sourceFiles))
            {

            }
            //newScoFiles.Parent.SaveFileAndCommit(@"C:\temp\temp2\games\AliceSoft\panyon\ぱにょ_out_sa.ald");

            ScoFiles.DefaultInstance = oldDefInstance;
        }

        private void LoadListView()
        {
            listView1.BeginUpdate();
            listView1.Items.Clear();
            foreach (var entry in this.scoFiles.GetFiles())
            {
                var item = new ListViewItem(entry.FileName);
                item.Tag = entry;
                //item.SubItems.Add(entry.FileName);
                listView1.Items.Add(item);
            }
            listView1.EndUpdate();
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
        }


        private void LoadFile(string aldFileName)
        {
            if (this.scoFiles != null)
            {
                this.scoFiles.Error -= new EventHandler<ErrorEventArgs>(scoFiles_Error);
            }

            this.scoFiles = new ScoFiles();
            try
            {
                StartProgressForm();
                scoFiles.OnReportProgress(0, "Reading ALD file...");

                this.scoFiles.LoadAldFile(aldFileName);

                //string directory = Path.GetDirectoryName(aldFileName);
                //string ainFileName = Path.Combine(directory, "System39.ain");
                //this.loadedAldFile = new AldFile();
                //this.loadedAldFile.ReadFile(aldFileName);
                //this.loadedAinFile = new AinFile();
                //this.loadedAinFile.LoadAinFile(ainFileName);
                this.scoFiles.Error += new EventHandler<ErrorEventArgs>(scoFiles_Error);

                this.scoFiles.FindLabels();
                this.scoFiles.Relink();
                //UpdateErrorWindow();
                LoadListView();
            }
            finally
            {
                CloseProgressForm();
            }
        }

        private void StartProgressForm()
        {
            this.scoFiles.ReportProgress += new EventHandler<ScoFiles.ReportProgressEventArgs>(scoFiles_ReportProgress);
        }

        private void CloseProgressForm()
        {
            this.scoFiles.ReportProgress -= scoFiles_ReportProgress;
            if (this.Enabled == false)
            {
                this.Enabled = true;
                if (this.progressForm != null && !this.progressForm.IsDisposed)
                {
                    this.progressForm.Dispose();
                    this.progressForm = null;
                }
            }
        }

        ErrorListForm errorListForm = null;

        void UpdateErrorWindow()
        {
            scoFiles_Error(this, new ErrorEventArgs(new Exception("")));
        }

        void scoFiles_Error(object sender, ErrorEventArgs e)
        {
            string errorMessage = e.GetException().Message;
            if (errorListForm == null && !String.IsNullOrEmpty(errorMessage))
            {
                this.errorListForm = new ErrorListForm();
                this.errorListForm.Disposed += new EventHandler(errorListForm_Disposed);
                this.errorListForm.Show();
            }
            if (errorListForm != null)
            {
                this.errorListForm.DisplayMessage(errorMessage);
            }
        }

        void errorListForm_Disposed(object sender, EventArgs e)
        {
            this.errorListForm.Disposed -= errorListForm_Disposed;
            this.errorListForm = null;
        }

        ProgressForm progressForm = null;

        void scoFiles_ReportProgress(object sender, ScoFiles.ReportProgressEventArgs e)
        {
            if (this.progressForm == null)
            {
                if (this.Enabled == true)
                {
                    this.Enabled = false;
                }
                this.progressForm = new ProgressForm();
                this.progressForm.StartPosition = FormStartPosition.CenterParent;
                this.progressForm.Show();
            }
            this.progressForm.Text = "Progress";
            this.progressForm.label1.Text = e.Message;
            if (e.Value <= 100)
            {
                this.progressForm.progressBar1.Value = e.Value;
            }
            else
            {
                this.progressForm.progressBar1.Value = 100;
            }
            Application.DoEvents();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectListItem();
        }

        ScoFile GetSelectedEntry()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                return listView1.SelectedItems[0].Tag as ScoFile;
            }
            else if (listView1.FocusedItem != null)
            {
                //return listView1.FocusedItem.Tag as ScoFile;
            }
            return null;
        }

        private void SelectListItem()
        {
            ScoFile scoFile = GetSelectedEntry();
            if (scoFile == null)
            {
                return;
            }

            if (scoFile.seenAddresses.Count == 0)
            {
                scoFile.FindLabels();
                scoFile.Relink();
            }

            var stringWriter = new StringWriter();
            scoFile.Decompile(stringWriter);
            var stringReader = new StringReader(stringWriter.ToString());
            scoFile.Compile(stringReader);

            textBox1.Text = stringWriter.ToString();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void OpenFile()
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "ALD Files (*.ald)|*s?.ald";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    LoadFile(openFileDialog.FileName);
                }
            }
        }

        private void DecompilerForm_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files.Length > 0)
                {
                    LoadFile(files[0]);
                }
            }

        }

        private void DecompilerForm_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void exportADVFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportAdvFiles();
        }

        private void testCompilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TestCompiler();
        }

        private void importADVFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImportAdvFiles();
        }

        private void ExportAdvFiles()
        {
            if (this.scoFiles == null)
            {
                return;
            }
            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "ADV Files (*.adv)|*.adv|All Files (*.*)|*.*";
                saveFileDialog.FileName = "PICK A DIRECTORY TO EXPORT FILES TO";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string directoryName = Path.GetDirectoryName(saveFileDialog.FileName);
                    ExportAdvFiles(directoryName);
                }
            }
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        private void ExportAdvFiles(string directoryName)
        {
            try
            {
                StartProgressForm();
                int fileNumber = 0;
                var files = scoFiles.GetFiles();
                int totalFiles = files.Length;
                foreach (var file in files)
                {
                    scoFiles.OnReportProgress(100 * fileNumber / totalFiles, "Exporting ADV files...");
                    string fileName = Path.Combine(directoryName, file.FileName);
                    using (var fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
                    {
                        using (var sw = new StreamWriter(fs, shiftJis))
                        {
                            file.Decompile(sw);
                            sw.Flush();
                            fs.Flush();
                            sw.Close();
                            fs.Close();
                        }
                    }
                    fileNumber++;
                }
            }
            finally
            {
                CloseProgressForm();
            }
            //UpdateErrorWindow();
        }

        private void ImportAdvFiles()
        {
            if (this.scoFiles == null)
            {
                return;
            }
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "ADV Files (*.adv)|*.adv|All Files (*.*)|*.*";
                openFileDialog.CheckFileExists = false;
                openFileDialog.CheckPathExists = true;
                openFileDialog.FileName = "PICK A DIRECTORY TO IMPORT FILES FROM";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string directoryName = Path.GetDirectoryName(openFileDialog.FileName);
                    ImportAdvFiles(directoryName);
                }
            }
        }

        private void ImportAdvFiles(string directoryName)
        {
            StartProgressForm();
            try
            {
                var files = scoFiles.GetFiles();
                List<string> replacementFileContentList = new List<string>();

                bool anyFilesMissing = false;
                foreach (var file in files)
                {
                    string fileName = Path.Combine(directoryName, file.FileName);
                    if (!File.Exists(fileName))
                    {
                        anyFilesMissing = true;
                    }
                }

                //if any files are missing, it's not safe to clear messages
                if (!anyFilesMissing)
                {
                    scoFiles.ClearMessages();
                }

                int fileNumber = 0;
                int totalFiles = files.Length;
                foreach (var file in files)
                {
                    scoFiles.OnReportProgress(100 * fileNumber / totalFiles, "Compiling ADV files...");
                    string fileName = Path.Combine(directoryName, file.FileName);
                    if (File.Exists(fileName))
                    {
                        Encoding encoding = EncodingDetector.DetectEncoding(fileName);
                        string source = File.ReadAllText(fileName, encoding);
                        file.CompileOver(source);
                    }
                    else
                    {
                        MessageBox.Show("Missing file " + Path.GetFileName(fileName), "Error - Missing file", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    fileNumber++;
                }
                scoFiles.ApplyFixups();
                scoFiles.FinalizeAinFile();
                //UpdateErrorWindow();

                //scoFiles.CompileOver(replacementFileContentList.ToArray());
                //scoFiles.Parent.SaveFileAndCommit();
                //scoFiles.AinFile.SaveAinFile(scoFiles.AinFile.FileName);
            }
            finally
            {
                CloseProgressForm();
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void SaveFile()
        {
            if (this.scoFiles == null)
            {
                return;
            }
            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "ALD Files (*.ald)|*.ald";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    SaveFile(saveFileDialog.FileName);
                }
            }
        }

        private void SaveFile(string fileName)
        {
            scoFiles.Parent.SaveFileAndCommit(fileName);
            string ainFileName = Path.Combine(Path.GetDirectoryName(fileName), "System39.ain");
            scoFiles.AinFile.FileName = ainFileName;

            scoFiles.AinFile.SaveAinFile(ainFileName);
        }

        private void fileToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            if (this.scoFiles == null)
            {
                this.saveAsToolStripMenuItem.Enabled = false;
                this.importADVFilesToolStripMenuItem.Enabled = false;
                this.exportADVFilesToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.saveAsToolStripMenuItem.Enabled = true;
                this.importADVFilesToolStripMenuItem.Enabled = true;
                this.exportADVFilesToolStripMenuItem.Enabled = true;
            }
        }
    }

}
