﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections.ObjectModel;
using System.Drawing;
using Sys3Decompiler;

namespace ALDExplorer
{
    public class AldFileCollection
    {
        public string AldFileName
        {
            get
            {
                string firstFileName = knownFileName;
                var firstAldFile = this.AldFiles.FirstOrDefault();
                if (firstAldFile != null)
                {
                    firstFileName = firstAldFile.AldFileName;
                }
                return firstFileName;
            }
        }
        string knownFileName = "";
        public List<AldFile> AldFiles = new List<AldFile>();
        public List<AldFileEntry> FileEntries = new List<AldFileEntry>();
        public Dictionary<int, AldFileEntry> FileEntriesByNumber = new Dictionary<int, AldFileEntry>();

        public void Refresh()
        {
            this.FileEntries.Clear();
            foreach (var aldFile in this.AldFiles.ToArray())
            {
                int fileLetter = aldFile.FileLetter;
                for (int i = 0; i < aldFile.FileEntries.Count; i++)
                {
                    var entry = aldFile.FileEntries[i];
                    if (entry.FileLetter != fileLetter)
                    {
                        aldFile.FileEntries.RemoveAt(i);
                        i--;
                        var destAldFile = GetAldFileByLetter(entry.FileLetter);
                        destAldFile.FileEntries.Add(entry);
                    }
                }
            }

            UpdateIndexes();
            foreach (var aldFile in this.AldFiles)
            {
                this.FileEntries.AddRange(aldFile.FileEntries);
            }
        }

        public void UpdateIndexes()
        {
            this.FileEntriesByNumber.Clear();
            foreach (var aldFile in this.AldFiles)
            {
                for (int i = 0; i < aldFile.FileEntries.Count; i++)
                {
                    var entry = aldFile.FileEntries[i];
                    entry.Index = i;
                    FileEntriesByNumber[entry.FileNumber] = entry;
                }
            }
        }

        public void ReadFile(string firstAldFile)
        {
            this.knownFileName = firstAldFile;
            string extension = Path.GetExtension(firstAldFile).ToLowerInvariant();
            if (extension == ".ald")
            {
                string[] allFiles = AldFile.AldUtil.GetAldOtherFiles(firstAldFile).ToArray();
                foreach (var fileName in allFiles)
                {
                    var aldFile = new AldFile();
                    aldFile.ReadFile(fileName);
                    AldFiles.Add(aldFile);
                    //this.FileEntries.AddRange(aldFile.FileEntries);
                }
            }
            else if (extension == ".dat")
            {
                string[] allFiles = AldFile.AldUtil.GetDatOtherFiles(firstAldFile).ToArray();
                foreach (var fileName in allFiles)
                {
                    var aldFile = new AldFile();
                    aldFile.ReadFile(fileName);
                    AldFiles.Add(aldFile);
                    //this.FileEntries.AddRange(aldFile.FileEntries);
                }
            }
            else
            {
                var aldFile = new AldFile();
                aldFile.ReadFile(firstAldFile);
                AldFiles.Add(aldFile);
                //this.FileEntries.AddRange(aldFile.FileEntries);
            }
            Refresh();
        }

        public AldFile GetAldFileByLetter(int fileLetter)
        {
            string firstFileName = this.AldFileName;
            if (String.IsNullOrEmpty(firstFileName))
            {
                //throw new InvalidOperationException();
            }

            var aldFile = this.AldFiles.Where(f => f.FileLetter == fileLetter).FirstOrDefault();
            if (aldFile == null)
            {
                aldFile = new AldFile();
                aldFile.FileLetter = fileLetter;
                aldFile.AldFileName = AldFile.AldUtil.GetAldFileName(firstFileName, fileLetter);
                this.AldFiles.Add(aldFile);
                this.AldFiles.Sort((f1, f2) => f1.FileLetter - f2.FileLetter);
            }
            return aldFile;
        }

        public void SaveFile(string fileName)
        {
            //foreach (var aldFile in this.AldFiles)
            //{
            //    //aldFile.AldFileName = AldFile.AldUtil.GetFileName(fileName, aldFile.FileLetter);
            //}

            var aFile = GetAldFileByLetter(1);
            foreach (var aldFile in this.AldFiles)
            {
                aldFile.UpdateInformation();
            }
            aFile.BuildIndexBlock(GetEntries());
            bool isDatFile = aFile.IsDatFile;
            string[] newFileNames;
            string[] tempFileNames;
            GetOutputAndTempFilenames(fileName, isDatFile, out newFileNames, out tempFileNames);

            for (int i = 0; i < this.AldFiles.Count; i++)
            {
                var aldFile = this.AldFiles[i];
                string newFileName = newFileNames[i];
                string tempFile = tempFileNames[i];
                if (aldFile.IsDatFile)
                {
                    aldFile.BuildIndexBlock(GetEntries());
                }
                aldFile.SaveToFile(tempFile);
            }

            for (int i = 0; i < this.AldFiles.Count; i++)
            {
                var aldFile = this.AldFiles[i];
                string newFileName = newFileNames[i];
                string tempFile = tempFileNames[i];
                aldFile.CommitTempFile(newFileName, tempFile);
            }

            //else
            //{
            //    var atFile = GetOrAddNew(0);
            //    var patchFile = GetOrAddNew(25); //Y
            //    SetPatchFileEntries(patchFile);
            //    patchFile.UpdateInformation();
            //    patchFile.SaveFileAndCommit();
            //    this.FileEntries = GetEntries().ToList();
            //    atFile.BuildIndexBlock(FileEntries);
            //}
        }

        private void GetOutputAndTempFilenames(string fileName, bool isDatFile, out string[] newFileNames, out string[] tempFileNames)
        {
            if (!isDatFile)
            {
                newFileNames = AldFiles.Select(f => AldFile.AldUtil.GetAldFileName(fileName, f.FileLetter)).ToArray();
            }
            else
            {
                newFileNames = AldFiles.Select(f => AldFile.AldUtil.GetDatFileName(fileName, f.FileLetter)).ToArray();
            }
            tempFileNames = newFileNames.Select(f => AldFile.GetTempFileName(f)).ToArray();
        }

        private IEnumerable<AldFileEntry> GetEntries()
        {
            foreach (var aldFile in this.AldFiles)
            {
                foreach (var entry in aldFile.FileEntries)
                {
                    yield return entry;
                }
            }
        }

        private void SetPatchFileEntries(AldFile patchFile)
        {
            Dictionary<int, AldFileEntry> knownFileEntries = new Dictionary<int, AldFileEntry>();
            foreach (var entry in patchFile.FileEntries)
            {
                knownFileEntries[entry.FileNumber] = entry;
            }
            foreach (var entry in this.FileEntries)
            {
                if (!String.IsNullOrEmpty(entry.ReplacementFileName))
                {
                    int fileNumber = entry.FileNumber;
                    var entry2 = entry.Clone();
                    entry2.FileLetter = patchFile.FileLetter;
                    knownFileEntries[fileNumber] = entry2;
                }
            }
            SetFileEntries(patchFile, knownFileEntries);
        }

        private static void SetFileEntries(AldFile patchFile, Dictionary<int, AldFileEntry> knownFileEntries)
        {
            var newPatchEntries = knownFileEntries.Select(p => p.Value).OrderBy(v => v.FileNumber);
            patchFile.FileEntries.Clear();
            patchFile.FileEntries.AddRange(newPatchEntries);
        }
    }

    public class AldFile
    {
        public bool IsDatFile = false;
        public string AldFileName;
        public byte[] Footer;
        public byte[] IndexBlock;
        public AldFileEntryCollection FileEntries = new AldFileEntryCollection();
        public int FileLetter;

        public void ReadFile(string fileName)
        {
            var fileType = AldUtil.CheckFileType(fileName);
            this.AldFileName = fileName;

            int[] fileAddresses;
            byte[][] fileHeaders;
            string[] fileNames;
            int[] fileLengths;
            int[] fileNumbers;

            if (fileType == AldUtil.AldFileType.AldFile)
            {
                this.IsDatFile = false;
                int fileLetter = AldUtil.GetAldFileLetter(fileName);
                this.FileLetter = fileLetter;

                using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    fileAddresses = AldUtil.GetAldFileAddresses(fs);
                    fileHeaders = AldUtil.GetAldFileHeaders(fs, fileAddresses);
                    fileNames = AldUtil.GetAldFileNames(fileHeaders);
                    fileLengths = AldUtil.GetAldFileLengths(fileHeaders);
                    fileNumbers = AldUtil.GetAldFileNumbers(fs, AldUtil.GetAldFileLetter(fileName));
                }
                this.Footer = null;

                this.FileEntries.Clear();

                for (int i = 0; i < fileAddresses.Length; i++)
                {
                    //ALD files generated by arc_conv are invalid and do not have the footer
                    if (i == fileAddresses.Length - 1 && fileHeaders[i].Length == 16)
                    {
                        this.Footer = fileHeaders[i];
                    }
                    else
                    {
                        var fileEntry = new AldFileEntry();
                        fileEntry.Parent = this;
                        fileEntry.FileAddress = fileAddresses[i] + fileHeaders[i].Length;
                        fileEntry.FileHeader = fileHeaders[i];
                        fileEntry.FileName = fileNames[i];
                        fileEntry.FileNumber = fileNumbers.GetOrDefault(i, 0);
                        fileEntry.FileSize = fileLengths[i];
                        fileEntry.FileLetter = fileLetter;
                        fileEntry.HeaderAddress = fileAddresses[i];
                        fileEntry.Index = i;
                        FileEntries.Add(fileEntry);
                    }
                }
            }
            else if (fileType == AldUtil.AldFileType.DatFile)
            {
                this.IsDatFile = true;

                int fileLetter = AldUtil.GetDatFileLetter(fileName);
                this.FileLetter = fileLetter;

                int fileSize;
                using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    fileSize = (int)fs.Length;
                    fileAddresses = AldUtil.GetDatFileAddresses(fs);
                    fileNumbers = AldUtil.GetDatFileNumbers(fs, AldUtil.GetDatFileLetter(fileName));
                }
                this.Footer = null;

                this.FileEntries.Clear();

                string filenameBase = Path.GetFileNameWithoutExtension(fileName).ToLowerInvariant();
                string filenameExtension = ".vsp";
                if (filenameBase.Length >= 2)
                {
                    filenameBase = filenameBase.Substring(1);
                }
                if (filenameBase.Length < 3)
                {
                    filenameBase = filenameBase.PadRight(3, '_');
                }
                else
                {
                    filenameBase = filenameBase.Substring(0, 3);
                }
                if (filenameBase == "dis")
                {
                    filenameExtension = ".sco";
                }
                else if (filenameBase == "mus")
                {
                    filenameExtension = ".mus";
                }
                else if (filenameBase == "map")
                {
                    filenameExtension = ".map";
                }



                for (int i = 0; i < fileAddresses.Length - 1; i++)
                {
                    var fileEntry = new AldFileEntry();
                    fileEntry.Parent = this;
                    fileEntry.FileAddress = fileAddresses[i];
                    fileEntry.FileHeader = null;
                    fileEntry.FileNumber = fileNumbers.GetOrDefault(i, 0);
                    //FIXME - find out actual file type



                    fileEntry.FileName = filenameBase + fileEntry.FileNumber.ToString("0000") + filenameExtension;
                    int nextFileAddress;

                    if (i + 1 < fileAddresses.Length)
                    {
                        nextFileAddress = fileAddresses[i + 1];
                    }
                    else
                    {
                        nextFileAddress = fileSize;
                    }
                    fileEntry.FileSize = nextFileAddress - fileAddresses[i];
                    fileEntry.FileLetter = fileLetter;
                    fileEntry.HeaderAddress = fileAddresses[i];
                    fileEntry.Index = i;
                    FileEntries.Add(fileEntry);
                }
            }
            else
            {
                throw new InvalidDataException("ALD file is invalid");
            }
        }

        internal static class AldUtil
        {
            public static int[] GetAldFileAddresses(Stream fs)
            {
                long oldPosition = fs.Position;
                try
                {
                    long fsLength = fs.Length;
                    if (fsLength > int.MaxValue || fsLength < 512)
                    {
                        //file size is wrong - over 2GB or under 512 bytes
                        return null;
                    }
                    int fileLength = (int)fsLength;

                    var br = new BinaryReader(fs);

                    var first3Bytes = br.ReadBytes(3);
                    fs.Position = 0;
                    int headerSize = (first3Bytes[0] << 8) | (first3Bytes[1] << 16) | (first3Bytes[2] << 24);
                    if (headerSize > 196611)
                    {
                        //limit of 65536 files, too many files, invalid ALD file.
                        return null;
                    }
                    if (headerSize > fileLength)
                    {
                        //invalid ALD file - header length is out of bounds
                        return null;
                    }
                    var header = br.ReadBytes(headerSize);
                    fs.Position = 0;

                    int filesLimit = headerSize / 3;
                    List<int> FileAddresses = new List<int>(filesLimit);
                    int lastAddress = 0;
                    bool sawZero = false;
                    for (int i = 1; i < filesLimit; i++)
                    {
                        int address = (header[i * 3 + 0] << 8) | (header[i * 3 + 1] << 16) | (header[i * 3 + 2] << 24);
                        if (address == 0)
                        {
                            sawZero = true;
                            continue;
                        }
                        if (address < lastAddress)
                        {
                            //invalid ALD file - file addresses are not strictly increasing
                            return null;
                        }
                        if (sawZero)
                        {
                            //invalid ALD file - contains nonzero values after a zero
                            return null;
                        }
                        if (address > fileLength)
                        {
                            //invalid ALD file - file address is out of bounds
                            return null;
                        }
                        lastAddress = address;
                        FileAddresses.Add(address);
                    }

                    if (FileAddresses.Count < 1)
                    {
                        //invalid ALD file - no files found inside
                        return null;
                    }
                    if (FileAddresses[0] - headerSize > 196611)
                    {
                        //invalid ALD file - file index table is too big
                        return null;
                    }

                    return FileAddresses.ToArray();
                }
                finally
                {
                    fs.Position = oldPosition;
                }
            }

            public static int[][] GetAldFileNumbers(string fileName)
            {
                List<int[]> fileNumbersList = new List<int[]>();
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(0, baseName.Length - 1);
                    for (int i = 0; i < 27; i++)
                    {
                        char c = (i == 0) ? '@' : ((char)('A' + i - i));
                        string aldFileName = Path.Combine(path, baseName + c + ".ald");
                        if (File.Exists(aldFileName))
                        {
                            using (var fs = File.OpenRead(aldFileName))
                            {
                                fileNumbersList.Add(GetAldFileNumbers(fs, i));
                            }
                        }
                        else
                        {
                            fileNumbersList.Add(new int[0]);
                        }
                    }
                }
                return fileNumbersList.ToArray();
            }

            public static int[] GetAldFileNumbers(Stream fs, int fileLetter)
            {
                long oldPosition = fs.Position;
                var br = new BinaryReader(fs);
                var first3Bytes = br.ReadBytes(3);
                var firstFileAddress3Bytes = br.ReadBytes(3);
                int tableAddress = (first3Bytes[0] << 8) | (first3Bytes[1] << 16) | (first3Bytes[2] << 24);
                int firstFileAddress = (firstFileAddress3Bytes[0] << 8) | (firstFileAddress3Bytes[1] << 16) | (firstFileAddress3Bytes[2] << 24);
                int tableSize = firstFileAddress - tableAddress;
                fs.Position = tableAddress;

                List<int> fileNumbersList = new List<int>();

                var tableData = br.ReadBytes(tableSize);
                int maxFileIndex = tableAddress / 3 - 1;
                int maxFileNumber = tableSize / 3;

                for (int fileNumberIndex = 0; fileNumberIndex < maxFileNumber; fileNumberIndex++)
                {
                    int fileNumber = fileNumberIndex + 1;
                    int entryFileLetter = tableData[fileNumberIndex * 3 + 0];
                    int fileIndex = tableData[fileNumberIndex * 3 + 1] + tableData[fileNumberIndex * 3 + 2] * 256;
                    if (fileIndex != 0)
                    {
                        if (fileIndex < maxFileIndex && entryFileLetter == fileLetter)
                        {
                            fileNumbersList.SetOrAdd(fileIndex - 1, fileNumber);
                        }
                    }
                }

                fs.Position = oldPosition;
                return fileNumbersList.ToArray();
            }

            public static byte[][] GetAldFileHeaders(Stream fs, int[] fileAddresses)
            {
                long oldPosition = fs.Position;
                var br = new BinaryReader(fs);
                List<byte[]> headers = new List<byte[]>(fileAddresses.Length);
                for (int i = 0; i < fileAddresses.Length; i++)
                {
                    int address = fileAddresses[i];
                    fs.Position = address;
                    int headerLength = br.ReadInt32();
                    if (headerLength != 0x20)
                    {
                        int remainingBytes = (int)fs.Length - address;
                        if (headerLength > remainingBytes)
                        {
                            headerLength = remainingBytes;
                        }
                    }
                    fs.Position = address;
                    var header = br.ReadBytes(headerLength);
                    headers.Add(header);
                }
                fs.Position = oldPosition;
                return headers.ToArray();
            }

            static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

            public static string[] GetAldFileNames(byte[][] fileHeaders)
            {
                List<string> fileNames = new List<string>(fileHeaders.Length);
                for (int i = 0; i < fileHeaders.Length; i++)
                {
                    byte[] header = fileHeaders[i];
                    string fileName;
                    if (header.Length < 32)
                    {
                        fileName = "";
                    }
                    else
                    {
                        int nameLength = 0;
                        int maxNameLength = header.Length - 16;
                        for (nameLength = 0; nameLength < maxNameLength; nameLength++)
                        {
                            if (header[16 + nameLength] == 0)
                            {
                                break;
                            }
                        }

                        fileName = shiftJis.GetString(header, 16, nameLength);
                    }
                    fileNames.Add(fileName);
                }
                return fileNames.ToArray();
            }

            public static int[] GetAldFileLengths(byte[][] fileHeaders)
            {
                List<int> fileLengths = new List<int>(fileHeaders.Length);
                for (int i = 0; i < fileHeaders.Length; i++)
                {
                    byte[] header = fileHeaders[i];
                    int length = BitConverter.ToInt32(header, 4);
                    fileLengths.Add(length);
                }
                return fileLengths.ToArray();
            }

            public static int GetDatFileLetter(string fileName)
            {
                if (fileName == null)
                {
                    return 1;
                }
                string baseName = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
                if (baseName.Length > 1)
                {
                    char c = baseName[0];
                    if (c == '@') return 0;
                    if (c >= 'A' && c <= 'Z') return (c - 'A' + 1);
                    return 1;
                }
                else
                {
                    return 1;
                }
            }

            public static bool DatFileHasLetter(string fileName)
            {
                if (fileName == null)
                {
                    return false;
                }
                string baseName = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
                if (baseName.Length > 1)
                {
                    char c = baseName[0];
                    if (c == '@') return true;
                    if (c >= 'A' && c <= 'Z') return true;
                    return false;
                }
                else
                {
                    return false;
                }
            }

            public static int GetAldFileLetter(string fileName)
            {
                if (fileName == null)
                {
                    return 1;
                }
                string baseName = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
                if (baseName.Length > 2)
                {
                    baseName = baseName.Substring(baseName.Length - 2);
                    char c = baseName[1];
                    if (c == '@') return 0;
                    if (c >= 'A' && c <= 'Z') return (c - 'A' + 1);
                    return 1;
                }
                else
                {
                    return 1;
                }
            }

            public static bool AldFileHasLetter(string fileName)
            {
                if (fileName == null)
                {
                    return false;
                }
                string baseName = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
                if (baseName.Length > 2)
                {
                    baseName = baseName.Substring(baseName.Length - 2);
                    char c = baseName[1];
                    if (c == '@') return true;
                    if (c >= 'A' && c <= 'Z') return true;
                    return false;
                }
                else
                {
                    return false;
                }
            }

            public static string GetAldFileName(string fileName, int fileLetter)
            {
                if (String.IsNullOrEmpty(fileName))
                {
                    char c = (fileLetter == 0) ? '@' : ((char)('A' + fileLetter - 1));
                    return c + ".ald";
                }
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(0, baseName.Length - 1);
                    char c = (fileLetter == 0) ? '@' : ((char)('A' + fileLetter - 1));
                    return Path.Combine(path, baseName + c + ".ald");
                }
                return fileName;
            }

            public static string GetDatFileName(string fileName, int fileLetter)
            {
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(1);
                    char c = (fileLetter == 0) ? '@' : ((char)('A' + fileLetter - 1));
                    return Path.Combine(path, c + baseName + ".dat");
                }
                return fileName;
            }

            public static IEnumerable<string> GetAldOtherFiles(string fileName)
            {
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(0, baseName.Length - 1);
                    for (int i = 0; i < 27; i++)
                    {
                        char c = (i == 0) ? '@' : ((char)('A' + i - 1));
                        string aldFileName = Path.Combine(path, baseName + c + ".ald");
                        if (File.Exists(aldFileName))
                        {
                            yield return aldFileName;
                        }
                    }
                }
            }

            internal enum AldFileType
            {
                AldFile = 0,
                DatFile = 1,
                Invalid = -1,
            }

            public static AldFileType CheckFileType(string fileName)
            {
                using (var fs = File.OpenRead(fileName))
                {
                    var aldFileAddresses = AldUtil.GetAldFileAddresses(fs);
                    if (aldFileAddresses != null)
                    {
                        return AldFileType.AldFile;
                    }

                    var datFileAddresses = AldUtil.GetDatFileAddresses(fs);
                    if (datFileAddresses != null)
                    {
                        return AldFileType.DatFile;
                    }
                }
                return AldFileType.Invalid;
            }

            public static int[] GetDatFileAddresses(Stream fs)
            {
                long oldPosition = fs.Position;
                try
                {
                    long fsLength = fs.Length;
                    if (fsLength > 16 * 1024 * 1024 || fsLength < 512)
                    {
                        //file is a bad size - over 16MB or under 512 bytes
                        return null;
                    }
                    int fileLength = (int)fsLength;

                    var br = new BinaryReader(fs);

                    int headerSize = (br.ReadUInt16() - 1) * 256;
                    if (headerSize > 512)
                    {
                        //limit of 255 files, too many files, invalid DAT file.
                        return null;
                    }
                    if (headerSize > fileLength)
                    {
                        //invalid DAT file - header size is too big for the container file size
                        return null;
                    }
                    fs.Position = 0;
                    var header = br.ReadBytes(headerSize);

                    int filesLimit = headerSize / 2;
                    List<int> FileAddresses = new List<int>(filesLimit);
                    int lastAddress = 0;
                    bool sawZero = false;
                    for (int i = 1; i < filesLimit; i++)
                    {
                        int address = BitConverter.ToUInt16(header, i * 2);
                        if (address == 0)
                        {
                            sawZero = true;
                            continue;
                        }
                        address = (address - 1) * 256;
                        if (address < lastAddress)
                        {
                            //invalid DAT file - addresses are not strictly increasing
                            return null;
                        }
                        if (sawZero)
                        {
                            //invalid DAT file - nonzero number present after zero
                            return null;
                        }
                        if (address > fileLength)
                        {
                            //invalid DAT file - file address is too big for the container file size
                            return null;
                        }
                        lastAddress = address;
                        FileAddresses.Add(address);
                    }

                    if (FileAddresses.Count < 1)
                    {
                        //invalid DAT file - no files inside
                        return null;
                    }

                    return FileAddresses.ToArray();
                }
                finally
                {
                    fs.Position = oldPosition;
                }
            }

            public static int[][] GetDatFileNumbers(string fileName)
            {
                List<int[]> fileNumbersList = new List<int[]>();
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(1);
                    for (int i = 0; i < 27; i++)
                    {
                        char c = (i == 0) ? '@' : ((char)('A' + i - i));
                        string aldFileName = Path.Combine(path, c + baseName + ".dat");
                        if (File.Exists(aldFileName))
                        {
                            using (var fs = File.OpenRead(aldFileName))
                            {
                                fileNumbersList.Add(GetDatFileNumbers(fs, i));
                            }
                        }
                        else
                        {
                            fileNumbersList.Add(new int[0]);
                        }
                    }
                }
                return fileNumbersList.ToArray();
            }

            public static int[] GetDatFileNumbers(Stream fs, int fileLetter)
            {
                long oldPosition = fs.Position;
                fs.Position = 0;
                var br = new BinaryReader(fs);
                int tableAddress = (br.ReadUInt16() - 1) * 256;
                int firstFileAddress = (br.ReadUInt16() - 1) * 256;
                int tableSize = firstFileAddress - tableAddress;
                fs.Position = tableAddress;

                List<int> fileNumbersList = new List<int>();

                var tableData = br.ReadBytes(tableSize);
                int maxFileIndex = tableAddress / 2;
                int maxFileNumber = tableSize / 2;

                for (int fileNumberIndex = 0; fileNumberIndex < maxFileNumber; fileNumberIndex++)
                {
                    int fileNumber = fileNumberIndex + 1;
                    int entryFileLetter = tableData[fileNumberIndex * 2 + 0];
                    int fileIndex = tableData[fileNumberIndex * 2 + 1];
                    if (fileIndex != 0)
                    {
                        if (fileIndex < maxFileIndex && entryFileLetter == fileLetter)
                        {
                            fileNumbersList.SetOrAdd(fileIndex - 1, fileNumber);
                        }
                    }
                }

                fs.Position = oldPosition;
                return fileNumbersList.ToArray();
            }


            public static IEnumerable<string> GetDatOtherFiles(string fileName)
            {
                string path = Path.GetDirectoryName(fileName);
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                if (baseName.Length >= 2)
                {
                    baseName = baseName.Substring(1);
                    for (int i = 0; i < 27; i++)
                    {
                        char c = (i == 0) ? '@' : ((char)('A' + i - 1));
                        string aldFileName = Path.Combine(path, c + baseName + ".dat");
                        if (File.Exists(aldFileName))
                        {
                            yield return aldFileName;
                        }
                    }
                }
            }
        }

        public static int PadToLength(int value, int padSize)
        {
            return (value + (padSize - 1)) & ~(padSize - 1);
        }

        byte[] CreateAldIndexBlock(int fileLetter)
        {
            int highestFileNumber = 1;
            if (this.FileEntries.Count > 0)
            {
                highestFileNumber = this.FileEntries.Max(e => e.FileNumber);
            }
            int size = PadToLength((highestFileNumber - 1) * 3, 256);

            byte[] indexBlock = new byte[size];
            for (int i = 0; i < this.FileEntries.Count; i++)
            {
                var entry = this.FileEntries[i];
                int fileNumberIndex = entry.FileNumber - 1;

                if (fileNumberIndex >= 0)
                {
                    indexBlock[fileNumberIndex * 3 + 0] = (byte)(fileLetter);
                    indexBlock[fileNumberIndex * 3 + 1] = (byte)((i + 1) & 0xFF);
                    indexBlock[fileNumberIndex * 3 + 2] = (byte)(((i + 1) >> 8) & 0xFF);
                }
            }

            return indexBlock;
        }

        //not used
        byte[] CreateDatIndexBlock(int fileLetter)
        {
            int highestFileNumber = 1;
            if (this.FileEntries.Count > 0)
            {
                highestFileNumber = this.FileEntries.Max(e => e.FileNumber);
            }
            int size = PadToLength((highestFileNumber - 1) * 2, 256);

            byte[] indexBlock = new byte[size];
            for (int i = 0; i < this.FileEntries.Count; i++)
            {
                var entry = this.FileEntries[i];
                int fileNumberIndex = entry.FileNumber - 1;

                if (fileNumberIndex >= 0)
                {
                    indexBlock[fileNumberIndex * 2 + 0] = (byte)(fileLetter);
                    indexBlock[fileNumberIndex * 2 + 1] = (byte)((i + 1) & 0xFF);
                }
            }

            return indexBlock;
        }

        static void SetStreamLength(Stream stream, int newSize)
        {
            stream.Position = stream.Length;
            if (newSize < stream.Length)
            {
                stream.SetLength(newSize);
            }
            else
            {
                if (stream.Length < newSize)
                {
                    stream.WriteZeroes(newSize - (int)stream.Length);
                }
            }
        }

        public void SaveFileAndCommit()
        {
            SaveFileAndCommit(this.AldFileName);
        }

        public void SaveFileAndCommit(string newFileName)
        {
            string tempFile = GetTempFileName(newFileName);
            SaveToFile(tempFile);
            CommitTempFile(newFileName, tempFile);
        }

        public static string GetTempFileName(string newFileName)
        {
            string tempFile = Path.ChangeExtension(newFileName, ".$$$");
            return tempFile;
        }

        public void CommitTempFile()
        {
            CommitTempFile(this.AldFileName, GetTempFileName(this.AldFileName));
        }

        public void CommitTempFile(string newFileName, string tempFile)
        {
            this.AldFileName = newFileName;
            if (File.Exists(newFileName))
            {
                File.Delete(newFileName);
            }
            File.Move(tempFile, newFileName);
        }

        public void SaveTempFile()
        {
            SaveToFile(GetTempFileName(this.AldFileName));
        }

        public void SaveToFile(string outputFileName)
        {
            byte[] indexBlock;
            if (this.IndexBlock == null)
            {
                if (!this.IsDatFile)
                {
                    indexBlock = CreateAldIndexBlock(AldUtil.GetAldFileLetter(this.AldFileName));
                }
                else
                {
                    indexBlock = CreateDatIndexBlock(AldUtil.GetDatFileLetter(this.AldFileName));
                }
            }
            else
            {
                indexBlock = this.IndexBlock;
            }
            int numberOfFiles = this.FileEntries.Count;
            int sizeOfFilesBlock;
            if (!this.IsDatFile)
            {
                sizeOfFilesBlock = PadToLength((numberOfFiles + 2) * 3, 256);
            }
            else
            {
                sizeOfFilesBlock = PadToLength((numberOfFiles + 1) * 2, 256);
            }

            List<int> fileAddresses = new List<int>();

            using (var fs = new FileStream(outputFileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
            {
                var bw = new BinaryWriter(fs);
                SetStreamLength(fs, sizeOfFilesBlock);
                fileAddresses.Add((int)fs.Position);
                bw.Write(indexBlock);

                for (int i = 0; i < this.FileEntries.Count; i++)
                {
                    var entry = this.FileEntries[i];
                    entry.Parent = this;
                    entry.Index = i;
                    long headerPosition = fs.Position;

                    if (!this.IsDatFile)
                    {
                        entry.UpdateFileHeader();
                        fs.WriteZeroes(entry.FileHeader.Length);
                    }

                    long filePosition = fs.Position;
                    entry.WriteDataToStream(fs);
                    long afterFile = fs.Position;
                    entry.FileSize = (int)(afterFile - filePosition);

                    if (!this.IsDatFile)
                    {
                        fs.Position = headerPosition;
                        entry.UpdateFileHeader();
                        bw.Write(entry.FileHeader);
                    }
                    entry.FileAddress = (int)filePosition;
                    entry.HeaderAddress = (int)headerPosition;

                    fileAddresses.Add((int)headerPosition);

                    int newPosition = PadToLength((int)afterFile, 256);
                    SetStreamLength(fs, newPosition);
                }
                fileAddresses.Add((int)fs.Position);
                if (!this.IsDatFile)
                {
                    UpdateFooter();
                    bw.Write(Footer);
                }

                fs.Position = 0;
                if (!this.IsDatFile)
                {
                    for (int i = 0; i < fileAddresses.Count; i++)
                    {
                        int address = fileAddresses[i];
                        bw.Write((byte)((address >> 8) & 0xFF));
                        bw.Write((byte)((address >> 16) & 0xFF));
                        bw.Write((byte)((address >> 24) & 0xFF));
                    }
                }
                else
                {
                    for (int i = 0; i < fileAddresses.Count; i++)
                    {
                        int address = fileAddresses[i];
                        bw.Write((ushort)((address + 256) >> 8));
                    }
                }

                fs.Flush();
                fs.Close();
                fs.Dispose();
            }
        }

        private void UpdateFooter()
        {
            if (this.Footer == null)
            {
                this.Footer = new byte[16];
                var ms = new MemoryStream(this.Footer);
                var bw = new BinaryWriter(ms);

                bw.Write((byte)'N');
                bw.Write((byte)'L');
                bw.Write((byte)0x01);
                bw.Write((byte)0x00);
                bw.Write((int)0x10);
            }
            {
                var ms = new MemoryStream(this.Footer);
                var bw = new BinaryWriter(ms);
                ms.Position = 8;
                bw.Write((byte)0x01);
                bw.Write((short)this.FileEntries.Count);
            }
        }

        public void UpdateInformation()
        {
            for (int i = 0; i < this.FileEntries.Count; i++)
            {
                var entry = this.FileEntries[i];
                entry.UpdateFileHeader();
                entry.Index = i;
            }
        }

        public void BuildIndexBlock(IEnumerable<AldFileEntry> fileEntries)
        {
            if (!this.IsDatFile)
            {
                this.IndexBlock = CreateAldIndexBlock(fileEntries);
            }
            else
            {
                this.IndexBlock = CreateDatIndexBlock(fileEntries);
            }
        }

        private static byte[] CreateDatIndexBlock(IEnumerable<AldFileEntry> fileEntries)
        {
            int highestFileNumber = 1;
            if (fileEntries.FirstOrDefault() != null)
            {
                highestFileNumber = fileEntries.Max(e => e.FileNumber);
            }
            int size = PadToLength((highestFileNumber - 1) * 2, 256);

            byte[] indexBlock = new byte[size];
            foreach (var entry in fileEntries)
            {
                int fileLetter = entry.FileLetter;
                int fileNumberIndex = entry.FileNumber - 1;
                int i = entry.Index;

                if (fileNumberIndex >= 0)
                {
                    indexBlock[fileNumberIndex * 2 + 0] = (byte)(fileLetter);
                    indexBlock[fileNumberIndex * 2 + 1] = (byte)((i + 1) & 0xFF);
                }
            }
            return indexBlock;
        }

        private static byte[] CreateAldIndexBlock(IEnumerable<AldFileEntry> fileEntries)
        {
            int highestFileNumber = 1;
            if (fileEntries.FirstOrDefault() != null)
            {
                highestFileNumber = fileEntries.Max(e => e.FileNumber);
            }
            int size = PadToLength((highestFileNumber - 1) * 3, 256);

            byte[] indexBlock = new byte[size];
            foreach (var entry in fileEntries)
            {
                int fileLetter = entry.FileLetter;
                int fileNumberIndex = entry.FileNumber - 1;
                int i = entry.Index;

                if (fileNumberIndex >= 0)
                {
                    indexBlock[fileNumberIndex * 3 + 0] = (byte)(fileLetter);
                    indexBlock[fileNumberIndex * 3 + 1] = (byte)((i + 1) & 0xFF);
                    indexBlock[fileNumberIndex * 3 + 2] = (byte)(((i + 1) >> 8) & 0xFF);
                }
            }

            return indexBlock;
        }
    }


    public class AldFileEntryCollection : Collection<AldFileEntry>
    {

    }


    //public enum FileType
    //{
    //    Scenario = 0,
    //    Cg = 1,
    //    Wave = 2,
    //    Midi = 3,
    //    Data = 4,
    //    Resource = 5,
    //    Bgm = 6,
    //}

    public class AldFileEntry
    {
        public AldFileEntry Clone()
        {
            var clone = (AldFileEntry)MemberwiseClone();
            if (clone.FileHeader != null)
            {
                clone.FileHeader = (byte[])clone.FileHeader.Clone();
            }
            return clone;
        }
        public AldFileEntry()
        {

        }
        public AldFile Parent
        {
            get;
            set;
        }
        public string FileName
        {
            get;
            set;
        }
        public int FileLetter
        {
            get;
            set;
        }
        //public FileType FileType
        //{
        //    get;
        //    set;
        //}
        public int Index
        {
            get;
            set;
        }
        public int FileNumber
        {
            get;
            set;
        }
        public int FileSize
        {
            get;
            set;
        }
        public int FileAddress
        {
            get;
            set;
        }
        public int HeaderAddress
        {
            get;
            set;
        }
        public byte[] FileHeader
        {
            get;
            set;
        }
        public byte[] GetFileData()
        {
            var ms = new MemoryStream();
            WriteDataToStream(ms);
            return ms.ToArray();
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public void UpdateFileHeader()
        {
            if (Parent != null && Parent.IsDatFile)
            {
                return;
            }

            if (FileHeader == null)
            {
                var fileNameBytes = shiftJis.GetBytes(this.FileName ?? " ");
                int headerSize = AldFile.PadToLength(16 + fileNameBytes.Length + 1, 16);
                if (headerSize == 16) headerSize = 32;

                FileHeader = new byte[headerSize];
                var ms = new MemoryStream(FileHeader);
                var bw = new BinaryWriter(ms);
                bw.Write((int)headerSize);
                bw.Write((int)0);
                bw.Write((uint)0x8E5C4430);
                bw.Write((int)0x01C9F639);
                bw.Write((int)0);
                bw.Write((int)0);
                bw.Write((int)0);
                bw.Write((int)0);
            }

            {
                var ms = new MemoryStream(FileHeader);
                var bw = new BinaryWriter(ms);

                byte[] fileNameBytes = shiftJis.GetBytes(this.FileName);
                ms.Position = 4;
                bw.Write((int)this.FileSize);
                ms.Position = 16;
                int maxFileNameLength = FileHeader.Length - 16;

                if (fileNameBytes.Length < maxFileNameLength)
                {
                    fileNameBytes = fileNameBytes.Concat(Enumerable.Repeat((byte)0, maxFileNameLength - fileNameBytes.Length)).ToArray();
                }
                else if (fileNameBytes.Length > maxFileNameLength)
                {
                    fileNameBytes = fileNameBytes.Take(maxFileNameLength).ToArray();
                }
                bw.Write(fileNameBytes);
            }
        }


        public void WriteDataToStream(Stream stream)
        {
            long streamStartPosition = stream.Position;
            if (GetReplacementFileData != null)
            {

            }
            else if (ReplacementFileData != null)
            {
                stream.Write(ReplacementFileData, 0, ReplacementFileData.Length);
            }
            else if (!String.IsNullOrEmpty(ReplacementFileName))
            {
                using (var fs = new FileStream(ReplacementFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    fs.WriteToStream(stream);
                }
            }
            else
            {
                using (var fs = new FileStream(Parent.AldFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    var br = new BinaryReader(fs);
                    fs.Position = this.FileAddress;
                    fs.WriteToStream(stream, FileSize);
                }
            }
            long streamEndPosition = stream.Position;
            //this.FileSize = (int)(streamEndPosition - streamStartPosition);
        }

        //private void WriteReplacementFile(Stream stream)
        //{
        //    string extension = Path.GetExtension(this.FileName).ToLowerInvariant();
        //    string replacementFileExtension = Path.GetExtension(ReplacementFileName).ToLowerInvariant();

        //    bool converted = false;

        //    if (replacementFileExtension != extension)
        //    {
        //        if (extension == ".vsp")
        //        {
        //            using (FreeImageBitmap referenceImage = GetOriginalImageVSP())
        //            {
        //                using (FreeImageBitmap imagefile = new FreeImageBitmap(this.ReplacementFileName))
        //                {
        //                    if (referenceImage != null)
        //                    {
        //                        var vspHeader = new VspHeader();
        //                        vspHeader.ParseComment(referenceImage.Comment);
        //                        bool is8Bit = vspHeader.is8Bit == 1;

        //                        bool paletteMatches = false;
        //                        if (imagefile.ColorDepth == 4 && ImageConverter.PaletteMatches(imagefile.Palette, referenceImage.Palette, 0, 16))
        //                        {
        //                            paletteMatches = true;
        //                        }
        //                        if (imagefile.ColorDepth == 8 && ImageConverter.PaletteMatches(imagefile.Palette, referenceImage.Palette, 0, 256))
        //                        {
        //                            paletteMatches = true;
        //                        }
        //                        if (!paletteMatches)
        //                        {
        //                            if (!is8Bit)
        //                            {
        //                                ImageConverter.RemapPalette(imagefile, referenceImage, 16);
        //                            }
        //                            else
        //                            {
        //                                ImageConverter.RemapPalette(imagefile, referenceImage, 256);
        //                            }
        //                            //convert image file to 4-bit
        //                            //imagefile.Quantize(FREE_IMAGE_QUANTIZE.FIQ_NNQUANT, 16, 16, referenceImage.Palette);
        //                        }

        //                        imagefile.Comment = referenceImage.Comment;
        //                    }
        //                    else
        //                    {
        //                        var vspHeader = new VspHeader();

        //                        if (!String.IsNullOrEmpty(imagefile.Comment))
        //                        {
        //                            vspHeader.ParseComment(referenceImage.Comment);
        //                            bool is8Bit = vspHeader.is8Bit == 1;
        //                            imagefile.Comment = vspHeader.GetComment();
        //                        }
        //                    }
        //                    ImageConverter.SaveVsp(stream, imagefile);
        //                }
        //            }

        //            converted = true;
        //        }
        //        if (extension == ".pms")
        //        {
        //            using (FreeImageBitmap referenceImage = GetOriginalImagePMS())
        //            {
        //                using (FreeImageBitmap imageFile = new FreeImageBitmap(this.ReplacementFileName))
        //                {
        //                    if (referenceImage != null)
        //                    {
        //                        bool paletteMatches = false;
        //                        if (imageFile.ColorDepth == 8 && ImageConverter.PaletteMatches(imageFile.Palette, referenceImage.Palette, 0, 256))
        //                        {
        //                            paletteMatches = true;
        //                        }
        //                        if (!paletteMatches)
        //                        {
        //                            ImageConverter.RemapPalette(imageFile, referenceImage, 256);
        //                        }
        //                        //var pmsHeader = referenceImage.Tag as PmsHeader;
        //                        //if (pmsHeader != null) imageFile.Tag = pmsHeader.Clone();
        //                        imageFile.Comment = referenceImage.Comment;
        //                        referenceImage.Dispose();
        //                    }
        //                    ImageConverter.SavePms(stream, imageFile);
        //                    converted = true;
        //                }
        //            }
        //        }
        //        if (extension == ".qnt")
        //        {
        //            var qntHeader = GetOriginalImageHeaderQNT();
        //            using (FreeImageBitmap imageFile = new FreeImageBitmap(this.ReplacementFileName))
        //            {
        //                if (qntHeader != null)
        //                {
        //                    imageFile.Comment = qntHeader.GetComment();
        //                }
        //                ImageConverter.SaveQnt(stream, imageFile);
        //                converted = true;
        //            }
        //        }
        //        if (extension == ".ajp")
        //        {
        //            var ajpHeader = GetOriginalImageHeaderAJP();
        //            if (Path.GetExtension(this.ReplacementFileName).ToLowerInvariant() == ".jpg")
        //            {
        //                string alphaFileDirectory = Path.Combine(Path.GetDirectoryName(this.ReplacementFileName), "SP");
        //                string alphaImageName = Path.GetFileNameWithoutExtension(this.ReplacementFileName) + ".bmp";
        //                string alphaFileName = Path.Combine(alphaFileDirectory, alphaImageName);
        //                bool alphaFileExists = false;
        //                alphaFileExists = File.Exists(alphaFileName);
        //                if (!alphaFileExists)
        //                {
        //                    alphaImageName = Path.ChangeExtension(alphaImageName, ".png");
        //                    alphaFileName = Path.Combine(alphaFileDirectory, alphaImageName);
        //                    alphaFileExists = File.Exists(alphaFileName);
        //                }

        //                if (ajpHeader == null)
        //                {
        //                    if (alphaFileExists)
        //                    {
        //                        FreeImageBitmap alphaImage = new FreeImageBitmap(alphaFileName);
        //                        alphaImage.ConvertColorDepth(FREE_IMAGE_COLOR_DEPTH.FICD_08_BPP | FREE_IMAGE_COLOR_DEPTH.FICD_FORCE_GREYSCALE | FREE_IMAGE_COLOR_DEPTH.FICD_REORDER_PALETTE);
        //                        var jpegFile = File.ReadAllBytes(this.ReplacementFileName);
        //                        ImageConverter.SaveAjp(stream, jpegFile, alphaImage, ajpHeader);
        //                    }
        //                    else
        //                    {
        //                        var jpegFile = File.ReadAllBytes(this.ReplacementFileName);
        //                        ImageConverter.SaveAjp(stream, jpegFile, null, ajpHeader);
        //                    }
        //                    converted = true;
        //                    goto after;
        //                }
        //                else
        //                {
        //                    if (ajpHeader.HasAlpha && alphaFileExists)
        //                    {
        //                        FreeImageBitmap alphaImage = new FreeImageBitmap(alphaFileName);
        //                        alphaImage.ConvertColorDepth(FREE_IMAGE_COLOR_DEPTH.FICD_08_BPP | FREE_IMAGE_COLOR_DEPTH.FICD_FORCE_GREYSCALE | FREE_IMAGE_COLOR_DEPTH.FICD_REORDER_PALETTE);
        //                        var jpegFile = File.ReadAllBytes(this.ReplacementFileName);
        //                        ImageConverter.SaveAjp(stream, jpegFile, alphaImage, ajpHeader);
        //                        converted = true;
        //                        goto after;
        //                    }
        //                    else if (!ajpHeader.HasAlpha)
        //                    {
        //                        var jpegFile = File.ReadAllBytes(this.ReplacementFileName);
        //                        ImageConverter.SaveAjp(stream, jpegFile, null, ajpHeader);
        //                        converted = true;
        //                        goto after;
        //                    }
        //                }
        //            }
        //            using (FreeImageBitmap imageFile = new FreeImageBitmap(this.ReplacementFileName))
        //            {
        //                if (ajpHeader != null)
        //                {
        //                    imageFile.Comment = ajpHeader.GetComment();
        //                }
        //                ImageConverter.SaveAjp(stream, imageFile);
        //            }
        //        after:
        //            ;
        //        }
        //    }

        //    if (!converted)
        //    {
        //        //no conversion?
        //        using (var fs = new FileStream(ReplacementFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        //        {
        //            fs.WriteToStream(stream);
        //        }
        //    }
        //}

        //private QntHeader GetOriginalImageHeaderQNT()
        //{
        //    return CallFunctionOnFile((fs) => ImageConverter.LoadQntHeader(fs));
        //}

        //private AjpHeader GetOriginalImageHeaderAJP()
        //{
        //    return CallFunctionOnFile((fs) => ImageConverter.LoadAjpHeader(fs));
        //}

        //private FreeImageBitmap GetOriginalImageQNT()
        //{
        //    byte[] originalBytes = GetOriginalBytes();
        //    FreeImageBitmap referenceImage = null;
        //    if (originalBytes != null)
        //    {
        //        referenceImage = ImageConverter.LoadQnt(originalBytes);
        //    }
        //    return referenceImage;
        //}

        //private FreeImageBitmap GetOriginalImageAJP()
        //{
        //    byte[] originalBytes = GetOriginalBytes();
        //    FreeImageBitmap referenceImage = null;
        //    if (originalBytes != null)
        //    {
        //        referenceImage = ImageConverter.LoadAjp(originalBytes);
        //    }
        //    return referenceImage;
        //}

        //private FreeImageBitmap GetOriginalImageVSP()
        //{
        //    byte[] originalBytes = GetOriginalBytes();
        //    FreeImageBitmap referenceImage = null;
        //    if (originalBytes != null)
        //    {
        //        referenceImage = ImageConverter.LoadVsp(originalBytes);
        //    }
        //    return referenceImage;
        //}

        //private FreeImageBitmap GetOriginalImagePMS()
        //{
        //    byte[] originalBytes = GetOriginalBytes();
        //    FreeImageBitmap referenceImage = null;
        //    if (originalBytes != null)
        //    {
        //        referenceImage = ImageConverter.LoadPms(originalBytes);
        //    }
        //    return referenceImage;
        //}

        private byte[] GetOriginalBytes()
        {
            return CallFunctionOnFile((fs) =>
            {
                var br = new BinaryReader(fs);
                return br.ReadBytes(this.FileSize);
            });
        }

        private T CallFunctionOnFile<T>(Func<Stream, T> actionToTake)
        {
            if (this.FileSize > 0 && this.FileAddress > 0)
            {
                using (var fs = new FileStream(Parent.AldFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    fs.Position = this.FileAddress;
                    return actionToTake(fs);
                }
            }
            else
            {
                return default(T);
            }
        }

        public event EventHandler GetReplacementFileData;
        public byte[] ReplacementFileData
        {
            get;
            set;
        }

        public string ReplacementFileName
        {
            get;
            set;
        }
    }

    public static partial class Extensions
    {
        static readonly byte[] zeroes = new byte[4096];
        public static void WriteZeroes(this Stream stream, int count)
        {
            while (count > 0)
            {
                int numberToWrite = count;
                if (numberToWrite > zeroes.Length)
                {
                    numberToWrite = zeroes.Length;
                }
                stream.Write(zeroes, 0, numberToWrite);

                count -= numberToWrite;
            }
        }
    }
}
