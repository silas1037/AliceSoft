﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace Sys3Decompiler
{
    public abstract class Parser
    {
        public abstract Expr getCaliValue();
        public abstract Expr getCaliVariable();
        public abstract Expr getVariable();
        public abstract int getDw();
        public abstract int getW();
        public abstract int getAddress();
        public abstract int getC();
        public abstract Expr getValue40();
        public abstract string getString(int terminator);
        public abstract string getMessage();
        public abstract string getConstString();
        public abstract string getAinMessage();
        public abstract void getVariableArguments(int libNumber, int functionNumber);
        public abstract int getForLoopStart();
        public virtual void getExternalAddress(out int fileNumber, out int address)
        {
            fileNumber = getW();
            address = getAddress();
        }

        private void getExternalAddress()
        {
            int fileNumber, address;
            getExternalAddress(out fileNumber, out address);
        }

        public virtual void getExternalAddress2(out int fileNumber, out int address)
        {
            fileNumber = -1;
            address = -1;

            int w = getW();
            if (w == 0)
            {
                getCaliValue();
            }
            else if (w == 65535)
            {
                getCaliVariable();
            }
            else
            {
                fileNumber = w;
                address = getAddress();
            }
        }

        private void getExternalAddress2()
        {
            int fileNumber, address;
            getExternalAddress2(out fileNumber, out address);
        }

        public virtual void StartLine()
        {

        }

        public virtual void EndLine()
        {

        }

        public bool insideMenuElement = false;

        public void ParseLine()
        {
            StartLine();
            int c;

            string msg = getMessage();
            if (msg == null)
            {
                c = getC();
                switch (c)
                {
                    case 0x10:
                    case 0x11:
                    case 0x12:
                    case 0x13:
                    case 0x14:
                    case 0x15:
                    case 0x16:
                    case 0x17:
                    case '!':
                        {
                            var variable = getVariable();
                            var value = getCaliValue();
                        }
                        break;
                    case '#': //getDataTableAdr
                        getAddress();
                        getCaliValue();
                        break;
                    case '$': //addRetValue or fixElement  (for menus)
                        if (insideMenuElement)
                        {
                            insideMenuElement = false;
                        }
                        else
                        {
                            insideMenuElement = true;
                            getAddress();
                        }
                        break;
                    case '%': //callFar or retFar
                        getCaliValue();
                        break;
                    case '&': //jumpFar
                        getCaliValue();
                        break;
                    case '@': //jumpNear
                        getAddress();
                        break;
                    case '<': //forLoop
                        getForLoopStart();
                        getAddress();
                        getCaliVariable();
                        getCaliValue();
                        getCaliValue();
                        getCaliValue();
                        break;
                    case '>': //forLoopEnd
                        getAddress();
                        break;
                    case '/': //small letter commnand
                        c = getC();
                        switch (c)
                        {
                            case 0x00: break;
                            case 0x01: break;
                            case 0x02: getCaliValue(); break;
                            case 0x03: getCaliValue(); break;
                            case 0x04: break;
                            case 0x05: break;
                            case 0x06: getCaliVariable(); break;
                            case 0x07: getCaliVariable(); break;
                            case 0x08: getCaliValue(); break;
                            case 0x09: getCaliVariable(); break;
                            case 0x0a: getCaliValue(); getCaliValue(); break;
                            case 0x0b: getCaliValue(); getCaliValue(); break;
                            case 0x0c: getCaliValue(); break;
                            case 0x0d: getCaliValue(); break;
                            case 0x0e: getCaliValue(); getCaliVariable(); break;
                            case 0x0f: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x10: getCaliValue(); getCaliVariable(); break;
                            case 0x11: getCaliValue(); break;
                            case 0x12: getString(0); break;
                            case 0x13: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x14: break;
                            case 0x15: getCaliValue(); getCaliVariable(); getCaliVariable(); getCaliVariable(); break;
                            case 0x16: getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x17: getCaliVariable(); getCaliVariable(); getCaliVariable(); break;
                            case 0x18: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x19: getCaliValue(); getCaliVariable(); break;
                            case 0x1a: getCaliValue(); break;
                            case 0x1b: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x1c: getCaliVariable(); break;
                            case 0x1d: break;
                            case 0x1e: getCaliValue(); getCaliValue(); break;
                            case 0x1f: break;
                            case 0x20: getCaliValue(); break;
                            case 0x21: getString(0); break;
                            case 0x22: getC(); getCaliValue(); break;
                            case 0x23: getCaliValue(); getCaliValue(); break;
                            case 0x24:
                                c = getC();
                                getString(0);
                                switch (c)
                                {
                                    case 0: getCaliVariable(); getCaliValue(); break;
                                    case 1: getCaliValue(); getCaliValue(); break;
                                    default: err("01"); break;
                                }
                                break;
                            case 0x25: getCaliValue(); getString(0); getString(0); break;
                            case 0x26: getCaliValue(); getCaliValue(); getString(0); break;
                            case 0x27: getCaliValue(); getString(0); break;
                            case 0x28: getString(0); break;
                            case 0x29: getString(0); break;
                            case 0x2a:
                                c = getC();
                                getString(0);
                                switch (c)
                                {
                                    case 0: getCaliVariable(); getCaliValue(); break;
                                    case 1: getCaliValue(); getCaliValue(); break;
                                    default: err("01"); break;
                                }
                                break;
                            case 0x2b: getC(); getString(0); getString(0); break;
                            case 0x2c:
                                c = getC();
                                switch (c)
                                {
                                    case 1: getCaliValue(); getCaliValue(); break;
                                    case 2: getCaliVariable(); getCaliValue(); break;
                                    case 3: getCaliVariable(); getCaliValue(); break;
                                    case 4: getCaliVariable(); getCaliValue(); break;
                                    case 5: getCaliVariable(); getCaliValue(); break;
                                    case 6: getCaliVariable(); getCaliValue(); break;
                                    case 7: getCaliValue(); getCaliValue(); break;
                                    case 8: getCaliValue(); getCaliValue(); break;
                                    case 9: getCaliValue(); getCaliValue(); break;
                                    case 10: getCaliValue(); getCaliValue(); break;
                                    case 11: getCaliValue(); getCaliValue(); break;
                                    default: err("1-11"); break;
                                }
                                break;
                            case 0x2d: getCaliValue(); getCaliValue(); break;
                            case 0x2e: getCaliValue(); getCaliVariable(); break;
                            case 0x2f: getCaliValue(); break;
                            case 0x30: getCaliValue(); getCaliVariable(); break;
                            case 0x31: getExternalAddress(); break;
                            case 0x32: getExternalAddress(); break;
                            case 0x33: break;
                            case 0x34: break;
                            case 0x35: getCaliValue(); getCaliValue(); break;
                            case 0x36: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x37: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x38: break;
                            case 0x39: getCaliVariable(); getCaliVariable(); break;
                            case 0x3a: getCaliVariable(); break;
                            case 0x3b: getCaliVariable(); break;
                            case 0x3c: getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x3d: getCaliValue(); getCaliVariable(); break;
                            case 0x3e: break;
                            case 0x3f: break;
                            case 0x40: getCaliVariable(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x41: getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x42: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x43: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x44: getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x45: getExternalAddress(); break;
                            case 0x46: break;
                            case 0x47: break;
                            case 0x48: getString(0); break;
                            case 0x49: getString(0); getString(0); break;
                            case 0x4a: getCaliValue(); break;
                            case 0x4b: getCaliVariable(); break;
                            case 0x4c: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x4d: getCaliValue(); getString(0); break;
                            case 0x4e: getCaliValue(); getCaliValue(); break;
                            case 0x4f: getCaliValue(); getCaliValue(); break;
                            case 0x50: getCaliValue(); getC(); getCaliValue(); break;
                            case 0x51: getCaliValue(); getC(); getCaliValue(); break;
                            case 0x52: getCaliValue(); break;
                            case 0x53: getCaliValue(); break;
                            case 0x54: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x55: getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliVariable(); break;
                            case 0x56: getCaliValue(); getString(0); getString(0); break;
                            case 0x57: getString(0); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x58: getCaliValue(); getCaliVariable(); break;
                            case 0x59: getCaliValue(); getCaliVariable(); break;
                            case 0x5a: getString(0); break;
                            case 0x5b: getCaliValue(); break;
                            case 0x5c: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x5d: getCaliValue(); getCaliValue(); break;
                            case 0x5e: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x5f: getCaliValue(); break;
                            case 0x60:
                                int libNumber = getDw();
                                int functionNumber = getDw();
                                getVariableArguments(libNumber, functionNumber); break;
                            case 0x61: getCaliValue(); getCaliValue(); break;
                            case 0x62: break;
                            case 0x63: getCaliVariable(); break;
                            case 0x64: getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x65: getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x66: getCaliValue(); getExternalAddress(); break;
                            case 0x67: getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x68: getCaliValue(); break;
                            case 0x69: getCaliValue(); break;
                            case 0x6a: getCaliValue(); break;
                            case 0x6b: getCaliVariable(); break;
                            case 0x6c: getCaliValue(); break;
                            case 0x6d: getCaliValue(); getCaliVariable(); break;
                            case 0x6e: getCaliValue(); break;
                            case 0x6f: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 0x70: getCaliValue(); break;
                            case 0x71: getCaliValue(); break;
                            case 0x72: getCaliVariable(); break;
                            case 0x73: getCaliVariable(); break;
                            case 0x74: getString(0); getCaliVariable(); break;
                            case 0x75: getCaliValue(); break;
                            case 0x76: getCaliVariable(); break;
                            case 0x77: getCaliValue(); getCaliValue(); break;
                            case 0x78: getCaliValue(); getCaliValue(); break;
                            case 0x79: getCaliValue(); getCaliValue(); break;
                            case 0x7A: break;
                            case 0x7B: break;
                            case 0x7C: getAinMessage(); break;
                            case 0x7D: getAinMessage(); getC(); getCaliValue(); break;
                            case 0x7E: getAinMessage(); getC(); getCaliValue(); break;
                            case 0x7F: getAinMessage(); getCaliValue(); break;
                            case 0x80: getExternalAddress(); break;
                            case 0x81: getCaliVariable(); getCaliValue(); break;
                            case 0x82: getCaliValue(); getCaliValue(); break;
                            case 0x83: getCaliValue(); break;
                            case 0x84: getCaliValue(); break;
                            case 0x85: getCaliVariable(); break;
                            case 0x86: getCaliValue(); break;
                            case 0x87: getCaliValue(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x88: getCaliValue(); getCaliVariable(); break;
                            case 0x89: getCaliValue(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 0x8A: getConstString(); getConstString(); break;
                            case 0x8B: getConstString(); getCaliValue(); getCaliValue(); getConstString(); getCaliVariable(); break;
                            case 0x8C: break;
                            default: err("00-8C"); break;
                        }
                        break;
                    case 'A':// hitAnyKey:
                        break;
                    case 'B':
                        c = getC();
                        switch (c)
                        {
                            case 0: getCaliValue(); break;
                            case 1: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 2: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 3: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 4: getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 10: getCaliVariable(); getCaliVariable(); break;
                            case 11: getCaliVariable(); getCaliVariable(); break;
                            case 12: getCaliVariable(); break;
                            case 13: getCaliVariable(); break;
                            case 14: getCaliVariable(); break;
                            case 21: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 22: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 23: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 24: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 31: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 32: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 33: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 34: getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            default: err("0-4, 10-14, 21-24, 31-34"); break;
                        }
                        break;
                    case 'C':
                        c = getC();
                        switch (c)
                        {
                            case 'B': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'C': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'D': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'E': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'F': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'K': getC(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'L': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'M': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'P': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'S': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'T': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'U': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'V': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'X': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'Y': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'Z': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            default: err("BCDEFKLMPSTUVWXYZ"); break;
                        }
                        break;
                    case 'D':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'I': getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                            case 'S': getCaliVariable(); getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'R': getCaliVariable(); break;
                            case 'F': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            default: err("CISRF"); break;
                        }
                        break;
                    case 'E':
                        c = getC();
                        switch (c)
                        {
                            case 'S': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'C': getCaliValue(); break;
                            case 'G': getCaliValue(); getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliVariable(); break;
                            case 'M': getCaliValue(); getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'N': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            default: err("SCGMN"); break;
                        }
                        break;
                    case 'F':
                        c = getC();
                        switch (c)
                        {
                            case 1: getCaliValue(); getCaliValue(); break;
                            case 2: getCaliVariable(); getCaliValue(); break;
                            case 3: getCaliVariable(); getCaliValue(); break;
                            case 4: getCaliVariable(); getCaliValue(); break;
                            case 5: getCaliVariable(); getCaliValue(); break;
                            case 6: getCaliVariable(); getCaliValue(); break;
                            case 7: getCaliValue(); getCaliValue(); break;
                            case 8: getCaliValue(); getCaliValue(); break;
                            case 9: getCaliValue(); getCaliValue(); break;
                            case 10: getCaliValue(); getCaliValue(); break;
                            case 11: getCaliValue(); getCaliValue(); break;
                            default: err("1-11"); break;
                        }
                        break;
                    case 'G':
                        c = getC();
                        switch (c)
                        {
                            case 0: getCaliValue(); break;
                            case 1: getCaliValue(); getCaliValue(); break;
                            case 'S': getCaliValue(); getCaliVariable(); break;
                            case 'X': getCaliValue(); getCaliVariable(); break;
                            default: err("01SX"); break;
                        }
                        break;
                    case 'H':
                        getC();
                        getCaliValue();
                        break;
                    case 'I':
                        c = getC();
                        switch (c)
                        {
                            case 'K': getC(); break;
                            case 'M': getCaliVariable(); getCaliVariable(); break;
                            case 'C': getCaliValue(); getCaliVariable(); break;
                            case 'Z': getCaliValue(); getCaliValue(); break;
                            case 'X': getCaliVariable(); break;
                            case 'Y': getCaliValue(); break;
                            case 'G': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'E': getCaliValue(); getCaliValue(); break;
                            default: err("KMCZXYGE"); break;
                        }
                        break;
                    case 'J':
                        c = getC();
                        switch (c)
                        {
                            case 0: getCaliValue(); getCaliValue(); break;
                            case 1: getCaliValue(); getCaliValue(); break;
                            case 2: getCaliValue(); getCaliValue(); break;
                            case 3: getCaliValue(); getCaliValue(); break;
                            case 4: break;
                            default: err("0-4"); break;
                        }
                        break;
                    case 'K':
                        c = getC();
                        switch (c)
                        {
                            case 'I': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'K': getCaliValue(); break;
                            case 'N': getCaliVariable(); break;
                            case 'P': getCaliVariable(); break;
                            case 'Q': getCaliVariable(); getCaliValue(); break;
                            case 'R': getCaliVariable(); break;
                            case 'W': getCaliVariable(); getCaliValue(); break;
                            default: err("IKNPQRW"); break;
                        }
                        break;
                    case 'L':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); getCaliValue(); break;
                            case 'D': getCaliValue(); break;
                            case 'P': getCaliValue(); getCaliVariable(); getCaliValue(); break;
                            case 'T': getCaliValue(); getCaliVariable(); break;
                            case 'E':
                                c = getC();
                                getString(':');
                                switch (c)
                                {

                                    case 0:
                                        getCaliVariable(); getCaliValue(); break;
                                    case 1:
                                        getCaliValue(); getCaliValue(); break;
                                }
                                break;
                            case 'L':
                                c = getC();
                                getCaliValue();
                                switch (c)
                                {

                                    case 0:
                                        getCaliVariable();
                                        getCaliValue();
                                        break;
                                    case 1:
                                        getCaliValue(); getCaliValue();
                                        break;
                                }
                                break;
                            case 'H':
                                c = getC();
                                switch (c)
                                {
                                    case 'D': getC(); getCaliValue(); break;
                                    case 'G': getC(); getCaliValue(); break;
                                    case 'M': getC(); getCaliValue(); break;
                                    case 'S': getC(); getCaliValue(); break;
                                    case 'W': getC(); getCaliValue(); break;
                                    default: err("DGMSW"); break;
                                }
                                break;
                            case 'X':
                                c = getC();
                                switch (c)
                                {
                                    case 'G': getCaliValue(); getString(':'); getString(':'); break;
                                    case 'O': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 'C': getCaliValue(); break;
                                    case 'L': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 'S': getCaliValue(); getCaliVariable(); getCaliVariable(); break;
                                    case 'P': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 'R': getCaliValue(); getCaliVariable(); getCaliValue(); break;
                                    case 'W': getCaliValue(); getCaliVariable(); getCaliValue(); break;
                                    default: err("GOCLSPRW"); break;
                                }
                                break;
                            default: err("CDPTELHX"); break;
                        }
                        break;
                    case 'M':
                        c = getC();
                        switch (c)
                        {
                            case 'A': getCaliValue(); getCaliValue(); break;
                            case 'C': getCaliValue(); getCaliValue(); break;
                            case 'D': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'E': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'F': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'G':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliValue(); break;
                                    case 1: getCaliValue(); break;
                                    case 2: getCaliValue(); break;
                                    case 3: getCaliValue(); break;
                                    case 4: getCaliValue(); break;
                                    case 5: getCaliVariable(); break;
                                    case 6: getCaliValue(); break;
                                    case 7: getCaliVariable(); break;
                                    case 100: getCaliValue(); break;
                                    default: getCaliValue(); break;
                                }
                                break;
                            case 'H': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'I': getCaliValue(); getCaliValue(); getString(':'); break;
                            case 'J': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'L': getCaliVariable(); getCaliValue(); break;
                            case 'M': getCaliValue(); getCaliValue(); break;
                            case 'N': getC(); getCaliValue(); getCaliVariable(); break;
                            case 'P': getCaliValue(); getCaliValue(); break;
                            case 'S': getCaliValue(); getString(':'); break;
                            case 'T': getString(':'); break;
                            case 'V': getCaliValue(); break;
                            case 'Z':
                                c = getC();
                                if (c == 0)
                                {
                                    getCaliValue(); getCaliValue(); getCaliValue();
                                }
                                break;
                            default: err("ACDEFGHIJLMNPSTVZ"); break;
                        }
                        break;
                    case 'N':
                        c = getC();
                        switch (c)
                        {
                            case '+': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case '-': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case '*': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case '/': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case '>': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case '<': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case '=': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case '\\': getCaliVariable(); getCaliValue(); break;
                            case '&': getCaliVariable(); getCaliValue(); getCaliVariable(); break;
                            case '|': getCaliVariable(); getCaliValue(); getCaliVariable(); break;
                            case '^': getCaliVariable(); getCaliValue(); getCaliVariable(); break;
                            case '~': getCaliVariable(); getCaliValue(); break;
                            case 'B': getCaliVariable(); getCaliVariable(); getCaliValue(); break;
                            case 'C': getCaliVariable(); getCaliValue(); break;
                            case 'I': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'P': getCaliVariable(); getCaliVariable(); getCaliValue(); getCaliVariable(); break;
                            case 'R': getCaliValue(); getCaliVariable(); break;
                            case 'O': getC(); getCaliVariable(); getCaliVariable(); getCaliValue(); break;
                            case 'T': getString(':'); break;
                            case 'D':
                                c = getC();
                                switch (c)
                                {
                                    case 'C': getCaliValue(); getCaliValue(); break;
                                    case 'D': getCaliVariable(); getCaliValue(); break;
                                    case 'M': getCaliValue(); getCaliValue(); break;
                                    case 'A': getCaliValue(); getCaliValue(); break;
                                    case 'H': getCaliValue(); getCaliValue(); break;
                                    case '+': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case '-': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case '*': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case '/': getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    default: err("CDMAH+-*/"); break;
                                }
                                break;
                            default: err("+-/><=\\&|^~BCIPROTD"); break;
                        }
                        break;
                    case 'O': //nop?
                        break;
                    case 'P':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); break;
                            case 'D': getCaliValue(); break;
                            case 'F': getC(); getCaliValue(); break;
                            case 'G': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'N': getCaliValue(); break;
                            case 'P': getCaliVariable(); getCaliValue(); getCaliValue(); break;
                            case 'S': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'W': getC(); getCaliValue(); break;
                            case 'T':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliVariable(); getCaliValue(); getCaliValue(); break;
                                    case 1: getCaliVariable(); getCaliVariable(); getCaliVariable(); getCaliValue(); getCaliValue(); break;
                                    case 2: getCaliVariable(); getCaliVariable(); getCaliValue(); getCaliValue(); break;
                                    default: err("0-2"); break;
                                }
                                break;
                            default: err("CDFGNPSWT"); break;
                        }

                        break;
                    case 'Q':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); getCaliValue(); break;
                            case 'D': getCaliValue(); break;
                            case 'E':
                                c = getC();
                                getString(':');
                                switch (c)
                                {
                                    case 0:
                                        getCaliVariable();
                                        getCaliValue();
                                        break;
                                    case 1:
                                        getCaliValue();
                                        getCaliValue();
                                        break;
                                    default:
                                        err("01");
                                        break;
                                }
                                break;
                            case 'P': getCaliValue(); getCaliVariable(); getCaliValue(); break;
                            default: err("CDEP"); break;
                        }
                        break;
                    case 'R': //messageNewLine
                        break;
                    case 'S':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliVariable(); break;
                            case 'G':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliValue(); break;
                                    case 1: getCaliValue(); break;
                                    case 2: getCaliVariable(); break;
                                    case 3: getCaliValue(); break;
                                    case 4: getCaliValue(); break;
                                    case 5: getCaliValue(); getCaliValue(); break;
                                    case 6: getCaliValue(); getCaliValue(); break;
                                    case 7: getCaliValue(); getCaliVariable(); break;
                                    case 8: getCaliValue(); getCaliVariable(); break;
                                    default: err("0-8"); break;
                                }
                                break;

                            case 'L': getCaliValue(); break;
                            case 'M': getCaliValue(); break;
                            case 'O': getCaliVariable(); break;
                            case 'P': getCaliValue(); getCaliValue(); break;
                            case 'Q': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'R': getValue40(); getCaliVariable(); break;
                            case 'S': getCaliValue(); break;
                            case 'T': getCaliValue(); break;
                            case 'U': getCaliVariable(); getCaliVariable(); break;
                            case 'W': getCaliVariable(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'X': getC();
                                c = getC();
                                switch (c)
                                {
                                    case 1: getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 2: getCaliVariable(); break;
                                    case 3: break;
                                    case 4: getCaliVariable(); break;
                                    default: err("0-3"); break;
                                }
                                break;
                            case 'I': getC(); getCaliVariable(); break;
                            default: err("CGLMOPQRSTUWXI"); break;
                        }
                        break;
                    case 'T': //setMessageLocation
                        getCaliValue();
                        getCaliValue();
                        break;
                    case 'U':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getC(); getCaliValue(); break;
                            case 'D': getCaliValue(); break;
                            case 'R': getCaliVariable(); break;
                            case 'S': getCaliVariable(); getCaliValue(); break;
                            case 'G': getCaliVariable(); getCaliValue(); break;
                            case 'P': getCaliValue(); getCaliValue();
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliValue(); getCaliValue(); break;
                                    case 1: getString(':'); getCaliValue(); break;
                                    case 2: getString(':'); getString(':'); break;
                                    case 3: getString(':'); getString(':'); break;
                                    default: err("0-3"); break;
                                }
                                break;
                            default: err("CDRSGP"); break;
                        }
                        break;
                    case 'V':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'P': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'S': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'G': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'H': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'F': break;
                            case 'V': getCaliValue(); getCaliValue(); break;
                            case 'R': getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 'W': getCaliValue(); getCaliValue(); getCaliVariable(); break;
                            case 'E': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'Z': getC(); getCaliValue(); getCaliValue(); break;
                            case 'X': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'T': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'B': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'I':
                                c = getC();
                                switch (c)
                                {
                                    case 'C': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 'P': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    default: err("CP"); break;
                                }
                                break;
                            case 'A':
                                c = getC();
                                getCaliValue();
                                if (c < 10)
                                {
                                    getCaliValue(); getCaliValue(); break;
                                }
                                else
                                {
                                    getCaliVariable(); getCaliVariable();
                                }
                                break;
                            case 'J': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            default: err("CPSGHFVRWEZXTVIAJ"); break;
                        }
                        break;
                    case 'W':
                        c = getC();
                        switch (c)
                        {
                            case 'W': getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'V': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'X': getCaliValue(); getCaliValue(); getCaliValue(); getCaliValue(); break;
                            case 'Z': getC(); getCaliValue(); break;
                            default: err("WVXZ"); break;
                        }
                        break;
                    case 'X':
                        getCaliValue();
                        break;
                    case 'Y':
                        getCaliValue();
                        getCaliValue();
                        break;
                    case 'Z':
                        c = getC();
                        switch (c)
                        {
                            case 'C': getCaliValue(); getCaliValue(); break;
                            case 'M': getCaliValue(); break;
                            case 'S': getCaliValue(); break;
                            case 'B': getCaliValue(); break;
                            case 'H': getCaliValue(); break;
                            case 'W': getCaliValue(); break;
                            case 'L': getCaliValue(); break;
                            case 'E': getCaliValue(); break;
                            case 'F': getCaliValue(); break;
                            case 'D':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliValue(); break;
                                    case 1: getCaliValue(); break;
                                    case 2: getCaliValue(); break;
                                    case 3: getCaliValue(); break;
                                    case 4: getCaliVariable(); break;
                                    default: err("0-4"); break;
                                }
                                break;
                            case 'T':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliVariable(); break;
                                    case 1: getCaliValue(); break;
                                    case 2: getCaliVariable(); break;
                                    case 3: getCaliVariable(); break;
                                    case 4: getCaliVariable(); break;
                                    case 5: getCaliVariable(); break;
                                    case 10: getCaliValue(); getCaliValue(); getCaliValue(); break;
                                    case 11: getCaliValue(); getCaliVariable(); break;
                                    case 20: getCaliValue(); break;
                                    case 21: getCaliValue(); break;
                                    default: err("0-5,10,11,20,21"); break;
                                }
                                break;
                            case 'Z':
                                c = getC();
                                switch (c)
                                {
                                    case 0: getCaliValue(); break;
                                    case 1: getCaliVariable(); break;
                                    case 2: getCaliValue(); break;
                                    case 3: getCaliVariable(); break;
                                    case 4: getCaliVariable(); break;
                                    case 5: getCaliVariable(); break;
                                    case 7: getCaliVariable(); break;
                                    case 8: getCaliVariable(); break;
                                    case 9: getCaliVariable(); break;
                                    case 10: getCaliVariable(); break;
                                    case 13: getCaliValue(); break;
                                    case 14: getCaliValue(); break;
                                    default: err("0-5,7-10,13,14"); break;
                                }
                                break;
                            case 'G': getCaliVariable(); break;
                            case 'I': getCaliValue(); getCaliValue(); break;
                            case 'A': getC(); getCaliValue(); break;
                            case 'K': getCaliValue(); getCaliValue(); break;
                            case 'R': getCaliValue(); getCaliVariable(); break;
                            default: err("CMSBHWLEFDTZGIAKR"); break;
                        }
                        break;
                    case '\\': //callNear/Return
                        getAddress();
                        break;
                    case ']': //menuSelection
                        break;
                    case '{': //conditional
                        getCaliValue();
                        getAddress();
                        break;
                    case '~': //farCall
                        getExternalAddress2();
                        //int w = getW();
                        //if (w == 0)
                        //{
                        //    getCaliValue();
                        //}
                        //else if (w == 65535)
                        //{
                        //    getCaliVariable();
                        //}
                        //else
                        //{
                        //    getAddress();
                        //}
                        break;
                    default:
                        throw new ArgumentException("Unknown command " + (char)c);
                }
            }
            EndLine();
        }

        public void err()
        {
            throw new ArgumentException();
        }

        public virtual void err(string errorMessage)
        {
            throw new ArgumentException("Expected one of " + errorMessage + " but got something else");
        }

    }
}
