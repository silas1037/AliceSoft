﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace Sys3Decompiler
{
    public static class StringUtil
    {
        public static string EscapeString(string stringToEscape, char quotationCharacter)
        {
            StringBuilder sb = new StringBuilder(stringToEscape.Length);
            foreach (var c in stringToEscape)
            {
                if (c == '\r')
                {
                    sb.Append("\\r");
                }
                else if (c == '\n')
                {
                    sb.Append("\\n");
                }
                else if (c == '\t')
                {
                    sb.Append("\\t");
                }
                else if (c == quotationCharacter)
                {
                    sb.Append("\\" + quotationCharacter);
                }
                else if (c == '\\')
                {
                    sb.Append(@"\\");
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static string UnescapeString(string stringToUnescape)
        {
            StringBuilder sb = new StringBuilder(16);
            StringReader sr = new StringReader(stringToUnescape);

            while (true)
            {
                int charInt = sr.Read();
                if (charInt == -1)
                {
                    break;
                }
                char c = (char)charInt;

                if (c == '\\')
                {
                    charInt = sr.Read();
                    if (charInt == -1)
                    {
                        break;
                    }
                    c = (char)charInt;
                    if (c == 'r')
                    {
                        c = '\r';
                    }
                    else if (c == 'n')
                    {
                        c = '\n';
                    }
                    else if (c == 't')
                    {
                        c = '\t';
                    }
                    else if (c == '\r')
                    {
                        charInt = sr.Peek();
                        if (charInt == '\n')
                        {
                            sr.Read();
                            continue;
                        }
                        continue;
                    }
                    else if (c == '\n')
                    {
                        continue;
                    }
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

    }
}
