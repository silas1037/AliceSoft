﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Globalization;

namespace Sys3Decompiler
{
    public static class TextConverter
    {
        //static readonly Encoding shiftJisWithThrow = Encoding.GetEncoding("shift-jis", EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
        static readonly Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        static char invalidChar = shiftJis.GetString(new byte[] { 0xFF, 0xFF })[0];
        static byte[] validCharacters = GetValidCharacters();

        private static byte[] GetValidCharacters()
        {
            byte[] validCharacters = new byte[65536];

            for (int i = 0; i < 65536; i++)
            {
                byte result = 0;
                int b = i & 0xFF;
                int b2 = i >> 8;

                if (b >= ' ' && b <= '~')
                {
                    result = 1;
                }
                //is valid two-byte Shift-Jis sequence
                if ((b >= 0x81 && b <= 0x84) || (b >= 0x87 && b <= 0x9F) || (b >= 0xE0 && b <= 0xEA) || (b >= 0xED && b <= 0xEE) || (b >= 0xFA) && b <= 0xFC)
                {
                    if (b2 >= 0x40 && b2 <= 0xFC && b2 != 0x7F)
                    {
                        //try
                        //{
                        var bytes2 = new byte[] { (byte)b, (byte)b2 };
                        string decoded = shiftJis.GetString(bytes2);
                        if (decoded[0] == invalidChar)
                        {
                            result = 0;
                        }
                        else
                        {
                            result = 2;
                        }
                        //}
                        //catch (DecoderFallbackException)
                        //{
                        //    result = 0;
                        //}
                    }
                }
                validCharacters[i] = result;
            }
            return validCharacters;
        }

        public static int IsValidCharacter(byte[] bytes, int i)
        {
            if (i >= bytes.Length)
            {
                return 0;
            }
            int b1 = bytes[i];
            int b2 = 0;
            if (i + 1 < bytes.Length)
            {
                b2 = bytes[i + 1];
            }
            return validCharacters[b1 + (b2 << 8)];
        }

        public static int IsValidCharacter(byte b1, byte b2)
        {
            return validCharacters[b1 + (b2 << 8)];
        }

        public static int NumberOfValidBytesAtPosition(byte[] bytes, int startPosition)
        {
            int count = 0;
            int i = 0;

            while (true)
            {
                int validCount = IsValidCharacter(bytes, i + startPosition);
                if (validCount == 0)
                {
                    break;
                }
                i += validCount;
                count += validCount;
            }
            return count;
        }

        public static int NumberOfValidBytesAtPosition(BinaryReader br)
        {
            long startPosition = br.BaseStream.Position;

            int count = 0;
            long length = br.BaseStream.Length;
            byte b1 = br.ReadByte();
            byte b2 = 0;
            if (br.BaseStream.Position < length) b2 = br.ReadByte();
            while (br.BaseStream.Position < length)
            {
                int v = IsValidCharacter(b1, b2);
                if (v == 0)
                {
                    break;
                }
                else if (v == 1)
                {
                    b1 = b2;
                    b2 = br.ReadByte();
                    count++;
                }
                else if (v == 2)
                {
                    b1 = br.ReadByte();
                    b2 = br.ReadByte();
                    count += 2;
                }
            }
            br.BaseStream.Position = startPosition;
            return count;
        }
    }
}
