﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections.ObjectModel;

namespace Sys3Decompiler
{
    public class AinFile
    {
        //public static AinFile DefaultInstance = new AinFile();
        //public byte[] bytesUntilFunc = new byte[0];
        public string[] ainMessages = new string[0];
        public string[] variableNames = new string[0];

        public string FileName;

        public struct FunctionEntry : IComparable<FunctionEntry>
        {
            public int FileNumber;
            public int Address;
            public string FunctionName;
            public static FunctionEntry Read(BinaryReader br)
            {
                return new FunctionEntry(br.ReadStringNullTerminated(), br.ReadUInt16(), br.ReadInt32());
            }
            public void Write(BinaryWriter bw)
            {
                bw.WriteStringNullTerminated(this.FunctionName);
                bw.Write((UInt16)this.FileNumber);
                bw.Write(this.Address);
            }
            public FunctionEntry(string functionName, int fileNumber, int address)
            {
                this.FunctionName = functionName;
                this.FileNumber = fileNumber;
                this.Address = address;
            }

            public override string ToString()
            {
                return FunctionName + " " + FileNumber.ToString() + " " + Address.ToString("X");
            }

            #region IComparable<FunctionEntry> Members

            static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

            int Compare(byte[] arr, byte[] arr2)
            {
                int l = Math.Min(arr.Length, arr2.Length);
                for (int i = 0; i < l; i++)
                {
                    int a = arr[i];
                    int b = arr2[i];
                    int d = a - b;
                    if (d != 0)
                    {
                        return d;
                    }
                }
                if (arr.Length < arr2.Length)
                {
                    return -1;
                }
                if (arr.Length == arr2.Length)
                {
                    return 0;
                }
                return 1;

            }

            public int CompareTo(FunctionEntry other)
            {
                var bytes1 = shiftJis.GetBytes(this.FunctionName);
                var bytes2 = shiftJis.GetBytes(other.FunctionName);
                return Compare(bytes1, bytes2);

                //return String.Compare(this.FunctionName, other.FunctionName, false, japanCulture);
            }

            #endregion
        }

        public class FunctionCollection : Collection<FunctionEntry>
        {
            public FunctionCollection()
            {

            }
            private FunctionCollection(int initialCapacity)
                : base(new List<FunctionEntry>(initialCapacity))
            {

            }

            public static FunctionCollection Read(BinaryReader br)
            {
                int count = br.ReadInt32();
                var collection = new FunctionCollection(count);
                for (int i = 0; i < count; i++)
                {
                    var entry = FunctionEntry.Read(br);
                    collection.Add(entry);
                }
                return collection;
            }
            public void Write(BinaryWriter bw)
            {
                bw.Write(this.Count);
                foreach (var entry in this)
                {
                    entry.Write(bw);
                }
            }
        }

        public struct LibraryEntry
        {
            public string FunctionName;
            public int ArgumentCount;
            public int[] Arguments;

            public static LibraryEntry Read(BinaryReader br)
            {
                var ent = new LibraryEntry();
                ent.FunctionName = br.ReadStringNullTerminated();
                ent.ArgumentCount = br.ReadInt32();
                ent.Arguments = Enumerable.Repeat(0, ent.ArgumentCount).Select(x => br.ReadInt32()).ToArray();
                return ent;
            }
            public void Write(BinaryWriter bw)
            {
                bw.WriteStringNullTerminated(this.FunctionName);
                bw.Write(this.ArgumentCount);
                this.Arguments.ForEach(e => bw.Write(e));
            }
            public override string ToString()
            {
                return FunctionName + " " + this.ArgumentCount.ToString();
            }
        }
        public class LibraryEntryCollection : Collection<LibraryEntry>
        {
            public LibraryEntryCollection()
            {

            }
            private LibraryEntryCollection(int initialCapacity)
                : base(new List<LibraryEntry>(initialCapacity))
            {

            }

            public string Name;
            public static LibraryEntryCollection Read(BinaryReader br)
            {
                string name = br.ReadStringNullTerminated();
                int count = br.ReadInt32();
                var collection = new LibraryEntryCollection(count);
                collection.Name = name;
                for (int i = 0; i < count; i++)
                {
                    var entry = LibraryEntry.Read(br);
                    collection.Add(entry);
                }
                return collection;
            }
            public void Write(BinaryWriter bw)
            {
                bw.WriteStringNullTerminated(this.Name);
                bw.Write(this.Count);
                foreach (var entry in this)
                {
                    entry.Write(bw);
                }
            }
        }

        public class Libraries : Collection<LibraryEntryCollection>
        {
            public Libraries()
            {

            }
            private Libraries(int initialCapacity)
                : base(new List<LibraryEntryCollection>(initialCapacity))
            {

            }

            public LibraryEntry GetLibraryFunction(int libraryIndex, int functionIndex)
            {
                if (libraryIndex >= 0 && libraryIndex < this.Count)
                {
                    var collection = this[libraryIndex];
                    if (functionIndex >= 0 && functionIndex < collection.Count)
                    {
                        return collection[functionIndex];
                    }
                }
                return default(LibraryEntry);
            }

            public static Libraries Read(BinaryReader br)
            {
                int libraryCount = br.ReadInt32();
                var libs = new Libraries(libraryCount);
                for (int i = 0; i < libraryCount; i++)
                {
                    var collection = LibraryEntryCollection.Read(br);
                    libs.Add(collection);
                }
                return libs;
            }
            public void Write(BinaryWriter bw)
            {
                bw.Write(this.Count);
                foreach (var collection in this)
                {
                    collection.Write(bw);
                }
            }
        }

        public FunctionCollection functions = new FunctionCollection();
        public Libraries libraries = new Libraries();

        public void LoadAinFile(string ainFileName)
        {
            this.FileName = ainFileName;
            this.ainMessages = new string[0];
            this.variableNames = new string[0];
            this.functions.Clear();
            this.libraries.Clear();

            try
            {
                ReadAinFile(ainFileName);
            }
            catch
            {

            }
            //DefaultInstance = this;
        }

        private void ReadAinFile(string ainFileName)
        {
            if (!File.Exists(ainFileName))
            {
                return;
            }
            var bytes = File.ReadAllBytes(ainFileName);
            for (int i = 4; i < bytes.Length; i++)
            {
                int b = bytes[i];
                bytes[i] = (byte)((b >> 6) | b << 2);
            }

            File.WriteAllBytes(ainFileName + "_decrypted", bytes);

            var ms = new MemoryStream(bytes);
            var br = new BinaryReader(ms);
            ms.Position = 4;
            int number4 = br.ReadInt32();
            string hel0 = br.ReadStringFixedSize(4);
            if (hel0 != "HEL0")
            {
                return;
            }
            int zeroValue = br.ReadInt32();

            this.libraries = Libraries.Read(br);

            //int addressOfSact = bytes.IndexOf("SACT\0", (int)ms.Position);

            //int addressOfFunc = bytes.IndexOf("FUNC\0\0\0\0", (int)ms.Position);
            //if (addressOfFunc == -1) return;

            //this.bytesUntilFunc = bytes.Take(addressOfFunc).ToArray();

            //int addressOfVari = bytes.IndexOf("VARI\0\0\0\0", addressOfFunc + 8);
            //if (addressOfVari == -1) return;
            //int addressOfMsgi = bytes.IndexOf("MSGI\0\0\0\0", addressOfVari + 8);
            //if (addressOfMsgi == -1) return;

            while (ms.Position < ms.Length)
            {
                string tagName = br.ReadStringFixedSize(4);
                zeroValue = br.ReadInt32();
                if (tagName == "FUNC" && zeroValue == 0)
                {
                    this.functions = FunctionCollection.Read(br);
                }
                if (tagName == "VARI" && zeroValue == 0)
                {
                    int numberOfVariables = br.ReadInt32();
                    List<string> varlist = new List<string>(numberOfVariables);
                    for (int i = 0; i < numberOfVariables; i++)
                    {
                        string str = br.ReadStringNullTerminated();
                        varlist.Add(str);
                    }
                    this.variableNames = varlist.ToArray();
                }
                if (tagName == "MSGI" && zeroValue == 0)
                {
                    int numberOfStrings = br.ReadInt32();
                    List<string> list = new List<string>(numberOfStrings);
                    for (int i = 0; i < numberOfStrings; i++)
                    {
                        string str = br.ReadStringNullTerminated();
                        list.Add(str);
                    }
                    this.ainMessages = list.ToArray();
                }
            }
        }

        public void SaveAinFile(string ainFileName)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);

            bw.WriteStringFixedSize("AINI", 4);
            bw.Write((int)4);
            bw.WriteStringFixedSize("HEL0", 4);
            bw.Write((int)0);

            this.libraries.Write(bw);

            bw.WriteStringFixedSize("FUNC", 8);
            this.functions.Write(bw);

            bw.WriteStringFixedSize("VARI", 8);
            bw.Write(this.variableNames.Length);
            foreach (var vari in this.variableNames)
            {
                bw.WriteStringNullTerminated(vari);
            }

            bw.WriteStringFixedSize("MSGI", 8);
            bw.Write(this.ainMessages.Length);
            foreach (var msg in this.ainMessages)
            {
                bw.WriteStringNullTerminated(msg);
            }

            var bytes = ms.ToArray();

            using (var fs = new FileStream(ainFileName + "_decrypted", FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
            {
                fs.Write(bytes, 0, bytes.Length);
                fs.Flush();
                fs.Close();
            }

            for (int i = 4; i < bytes.Length; i++)
            {
                int b = bytes[i];
                bytes[i] = (byte)((b >> 2) | b << 6);
            }

            using (var fs = new FileStream(ainFileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
            {
                var bw2 = new BinaryWriter(fs);
                bw2.Write(bytes);
                bw2.Flush();
                fs.Flush();
                fs.Close();
            }
        }
    }
}
