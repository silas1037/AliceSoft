﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace Sys3Decompiler
{
    class Compiler : Parser
    {
        public int LineNumber
        {
            get
            {
                return tr.LineNumber;
            }
        }

        public int Column
        {
            get
            {
                return tr.Column;
            }
        }
        
        MyTextReader tr;
        MemoryStream stream;
        BinaryWriter bw;
        ScoFile parent;

        public Compiler(ScoFile parent, TextReader tr)
        {
            this.stream = new MemoryStream();
            this.bw = new BinaryWriter(stream);
            this.parent = parent;
            this.tr = new MyTextReader(tr);

            var fileNameBytes = shiftJis.GetBytes(parent.FileName);

            int headerSize = fileNameBytes.Length + 18;
            headerSize = ((headerSize - 1) | 15) + 1;

            bw.WriteStringFixedSize(parent.signature, 4);
            bw.Write(headerSize);
            bw.Write(0); //fileSize - fix later
            bw.Write(parent.fileNumber2);
            bw.Write((UInt16)fileNameBytes.Length);
            bw.Write(fileNameBytes);
            while (stream.Length < headerSize)
            {
                stream.WriteByte(0);
            }
        }

        bool firstChar;
        bool sawOperator;
        int operatorPosition;
        int instructionByte;
        int lastValue;

        public override void StartLine()
        {
            firstChar = true;
            sawOperator = false;
            bool tryAgain;
            do
            {
                tryAgain = false;

                base.StartLine();
                tr.EatWhiteSpace();
                int c = tr.Peek();
                if (c == -1)
                {
                    return;
                }
                if (c == '\'')
                {
                    //message
                }
                else if (c == '_')
                {
                    //literal label
                    c = tr.Read();
                    string labelName = tr.ReadToken();
                    string colon = tr.ReadToken();
                    if (colon != ":")
                    {
                        throw new ArgumentException();
                    }
                    int address = (int)stream.Position;
                    bw.Write((int)0);
                    parent.Fixups.Add(new ScoFile.Fixup(labelName, address));
                    tryAgain = true;
                }
                else if (c == '*')
                {
                    //label definition
                    c = tr.Read();
                    c = tr.Peek();
                    bool isGlobal = false;
                    if (c == '*')
                    {
                        isGlobal = true;
                        c = tr.Read();
                    }

                    string labelName = tr.ReadToken();
                    string colon = tr.ReadToken();
                    if (colon != ":")
                    {
                        throw new ArgumentException();
                    }
                    int address = (int)stream.Position;
                    parent.Labels[labelName] = address;
                    parent.LabelsInverse[address] = labelName;
                    if (isGlobal)
                    {
                        parent.Parent.AddExternalLabel(this.parent.index, address, labelName);
                    }

                    tryAgain = true;
                }
                else if (c == '[')
                {
                    //data block
                    c = tr.Read();

                    while (c != ']')
                    {
                        c = tr.Read();
                        if (c == ']')
                        {
                            break;
                        }
                        int c2 = tr.Read();
                        byte byteValue = GetHexValue(c, c2);
                        bw.Write(byteValue);
                    }

                    tryAgain = true;
                }
                else
                {
                    //normal statement
                }
            } while (tryAgain);

        }

        private static byte GetHexValue(int c, int c2)
        {
            return (byte)((GetHexValue(c) << 4) + GetHexValue(c2));
        }

        public static int GetHexValue(int c)
        {
            if (c >= '0' && c <= '9')
            {
                return c - '0';
            }
            else if (c >= 'A' && c <= 'F')
            {
                return c - 'A' + 0x0A;
            }
            else if (c >= 'a' && c <= 'f')
            {
                return c - 'a' + 0x0A;
            }
            throw new ArgumentException("Invalid hex character");
        }

        public override void EndLine()
        {
            base.EndLine();
            if (this.sawOperator)
            {
                string token = tr.ReadToken();
                if (token != "!")
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                if (tr.HasPeekToken())
                {
                    string colon = tr.PeekToken();
                    if (colon == ":")
                    {
                        colon = tr.ReadToken();
                    }
                    else
                    {

                    }
                }
                else
                {
                    int c = tr.Peek();
                    if (c == ':')
                    {
                        c = tr.Read();
                    }
                }
            }

            StartLine();
            //tr.EatWhiteSpace();
        }

        private static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public override string getMessage()
        {
            int c = tr.Peek();
            if (c == '\'')
            {
                string message = tr.ReadToken();
                //encode the message
                string messageNarrow;
                if (parent.signature == "S380" || parent.Parent.EncodingMode != 1)
                {
                    messageNarrow = message;
                }
                else
                {
                    messageNarrow = Decompiler.ToHalfWidth(message);
                }

                if (MessageContainsAscii(messageNarrow))
                {
                    string nextToken = tr.PeekToken();
                    if (nextToken.StartsWith("["))
                    {
                        bw.Write(shiftJis.GetBytes(messageNarrow));
                    }
                    else
                    {
                        bw.Write((byte)'/');
                        bw.Write((byte)'|');
                        writeAinMessage2(messageNarrow, -1);
                    }
                }
                else
                {
                    bw.Write(shiftJis.GetBytes(messageNarrow));
                }
                return messageNarrow;
            }
            return null;
        }

        private bool MessageContainsAscii(string messageNarrow)
        {
            foreach (var c in messageNarrow)
            {
                if (c < 128 && c != ' ')
                {
                    return true;
                }
            }
            return false;
        }

        public override Expr getCaliValue()
        {
            string comma = tr.PeekToken();
            if (comma == ",")
            {
                tr.ReadToken();
            }

            var expr = ReadExpression();
            OutputExpression(expr);
            bw.Write((byte)0x7F);
            return expr;
        }

        private void OutputExpression(Expr expr)
        {
            if (expr == null)
            {
                throw new ArgumentNullException("expr");
            }
            int precedence = expr.Precedence();
            char c = expr.value[0];
            if (precedence != -1)
            {
                OutputExpression(expr.e1);
                OutputExpression(expr.e2);
                //ouput the expression
                switch (expr.value)
                {
                    case "&":
                        bw.Write((byte)0x74);
                        break;
                    case "|":
                        bw.Write((byte)0x75);
                        break;
                    case "^":
                        bw.Write((byte)0x76);
                        break;
                    case "*":
                        bw.Write((byte)0x77);
                        break;
                    case "/":
                        bw.Write((byte)0x78);
                        break;
                    case "+":
                        bw.Write((byte)0x79);
                        break;
                    case "-":
                        bw.Write((byte)0x7A);
                        break;
                    case "==":
                        bw.Write((byte)0x7B);
                        break;
                    case "<":
                        bw.Write((byte)0x7C);
                        break;
                    case ">":
                        bw.Write((byte)0x7D);
                        break;
                    case "!=":
                        bw.Write((byte)0x7E);
                        break;
                    case "%":
                        bw.Write((byte)0xC0);
                        bw.Write((byte)0x02);
                        break;
                    case "<=":
                        bw.Write((byte)0xC0);
                        bw.Write((byte)0x03);
                        break;
                    case ">=":
                        bw.Write((byte)0xC0);
                        bw.Write((byte)0x04);
                        break;
                }
            }
            else if (expr.value == "[")
            {
                bw.Write((byte)0xC0);
                bw.Write((byte)0x01);

                //left side must be a variable
                int variableIndex = parent.GetVariable(expr.e1.value);
                bw.Write((byte)(variableIndex >> 8));
                bw.Write((byte)(variableIndex));
                OutputExpression(expr.e2);
                bw.Write((byte)0x7F);
            }
            else if (c >= '0' && c <= '9')
            {
                int intValue = IntUtil.Parse(expr.value);
                if (intValue <= 0x33)
                {
                    bw.Write((byte)(intValue + 0x40));
                }
                else
                {
                    int c1 = (intValue & 0x3F00) >> 8;
                    int c2 = (intValue & 0xFF);
                    bw.Write((byte)c1);
                    bw.Write((byte)c2);
                }
            }
            else if (c.IsSymbolChar())
            {
                int variaibleIndex = parent.GetVariable(expr.value);
                if (variaibleIndex < 0x40)
                {
                    bw.Write((byte)(variaibleIndex + 0x80));
                }
                else
                {
                    int c1 = (variaibleIndex & 0x3F00) >> 8;
                    int c2 = (variaibleIndex & 0xFF);
                    bw.Write((byte)(c1 + 0xC0));
                    bw.Write((byte)(c2));
                }
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public override Expr getCaliVariable()
        {
            var comma = tr.PeekToken();
            if (comma == ",")
            {
                comma = tr.ReadToken();
            }
            var expr = ReadExpression();
            char c = expr.value[0];
            if (!c.IsSymbolChar() && expr.value != "[")
            {
                throw new ArgumentException();
            }
            OutputExpression(expr);
            bw.Write((byte)0x7F);
            return expr;
        }

        public override Expr getVariable()
        {
            var expr = ReadExpression();
            char c = expr.value[0];
            if (!c.IsSymbolChar() && expr.value != "[")
            {
                throw new ArgumentException();
            }
            OutputExpression(expr);
            string opToken = tr.ReadToken();

            if (!this.sawOperator)
            {
                throw new ArgumentException();
            }

            int position = (int)this.stream.Position;
            this.stream.Position = this.operatorPosition;

            switch (opToken)
            {
                case "+:":
                case "+=":
                    bw.Write((byte)0x10);
                    break;
                case "-:":
                case "-=":
                    bw.Write((byte)0x11);
                    break;
                case "*:":
                case "*=":
                    bw.Write((byte)0x12);
                    break;
                case "/:":
                case "/=":
                    bw.Write((byte)0x13);
                    break;
                case "%:":
                case "%=":
                    bw.Write((byte)0x14);
                    break;
                case "&:":
                case "&=":
                    bw.Write((byte)0x15);
                    break;
                case "|:":
                case "|=":
                    bw.Write((byte)0x16);
                    break;
                case "^:":
                case "^=":
                    bw.Write((byte)0x17);
                    break;
                case ":":
                case "=":
                    bw.Write((byte)'!');
                    break;
                default:
                    throw new ArgumentException();
            }

            this.stream.Position = position;
            return expr;
        }

        private Expr GetCaliValueInternal()
        {
            return ReadExpression();
        }

        private Expr ReadExpression()
        {
            return ReadExpression(0);
        }

        private Expr ReadExpression(int minimumPrecedence)
        {
            string token = tr.PeekToken();
            if (token == null) return null;

            int currentOperatorPrecedence = -1;

            Expr expression = null;

            if (token == "(")
            {
                var parenthesisToken = tr.ReadToken();
                expression = ReadExpression();
                if (expression == null) return null;
                var closedParenthesisToken = tr.ReadToken();
                if (closedParenthesisToken != ")") return null;

                token = tr.PeekToken();
            }
            else
            {
                int c = token[0];
                //check for a symbol or literal
                if (((char)c).IsSymbolChar() || ((char)c).IsDigit())
                {
                    token = tr.ReadToken();
                    expression = new Expr(token);
                }
                else
                {
                    return null;
                }

                token = tr.PeekToken();
            }

            //allow end of input
            if (token == null)
            {
                return expression;
            }
        continueParsing:
            currentOperatorPrecedence = -1;
            if (token == "[")
            {
                var bracketToken = tr.ReadToken();
                var innerExpression = ReadExpression();
                var closedBracketToken = tr.ReadToken();
                if (closedBracketToken != "]") return null;

                expression = new Expr("[", expression, innerExpression);

                token = tr.PeekToken();
                if (token == null) return expression;
            }

            int tokenOperatorPrecedence = Expr.Precedence(token);

            if (tokenOperatorPrecedence != -1)
            {
                currentOperatorPrecedence = tokenOperatorPrecedence;
                if (currentOperatorPrecedence >= minimumPrecedence)
                {
                    token = tr.ReadToken();
                    var nextExpression = ReadExpression(currentOperatorPrecedence + 1);
                    if (nextExpression == null) return null;
                    expression = new Expr(token, expression, nextExpression);

                    token = tr.PeekToken();
                    if (token == null) return expression;
                }
            }

            if (currentOperatorPrecedence == -1)
            {
                return expression;
            }

            if (currentOperatorPrecedence >= minimumPrecedence)
            {
                int nextOperatorPrecedence = Expr.Precedence(token);
                if (nextOperatorPrecedence != -1)
                {
                    goto continueParsing;
                }
            }
            return expression;
        }


        public override int getDw()
        {
            string token = tr.ReadToken();
            if (token == ",") token = tr.ReadToken();
            int intValue = IntUtil.Parse(token);
            bw.Write(intValue);
            lastValue = intValue;
            return intValue;
        }

        public override int getW()
        {
            string token = tr.ReadToken();
            if (token == ",") token = tr.ReadToken();
            int intValue = IntUtil.Parse(token);
            bw.Write((UInt16)intValue);
            lastValue = intValue;
            return intValue;
        }

        public override int getAddress()
        {
            int address = (int)stream.Position;
            bw.Write(0);
            string token = tr.ReadToken();
            if (token == ",") token = tr.ReadToken();

            if (token != "0")
            {
                if ("%&/~".Contains((char)instructionByte))
                {
                    int fileNumber = lastValue;
                    var scoFile = parent.Parent.GetFile(fileNumber);
                    if (scoFile != null)
                    {
                        parent.Fixups.Add(new ScoFile.Fixup(token, address, fileNumber));
                    }
                    else
                    {
                        throw new ArgumentException();
                    }
                }
                else
                {
                    parent.Fixups.Add(new ScoFile.Fixup(token, address));
                }
            }

            return 0;
        }

        public override int getC()
        {
            bool isFirstChar = firstChar;
            int c = ReadC();
            bw.Write((byte)c);
            if (isFirstChar)
            {
                instructionByte = c;
            }
            return c;
        }

        private int ReadC()
        {
            bool isFirstChar = firstChar;
            firstChar = false;
            bool sawWhiteSpace = false;
            while (true)
            {
                int c = tr.Read();
                if (c == -1)
                {
                    throw new ArgumentException();
                }
                if (char.IsWhiteSpace((char)c))
                {
                    sawWhiteSpace = true;
                    tr.EatWhiteSpace();
                    continue;
                }
                if (c >= '0' && c <= '9')
                {
                    if (sawWhiteSpace)
                    {
                        int value = 0;
                        while (true)
                        {
                            value *= 10;
                            value += (c - '0');
                            c = tr.Peek();
                            if (c >= '0' && c <= '9')
                            {
                                c = tr.Read();
                            }
                            else
                            {
                                break;
                            }
                        }
                        if (value > 255)
                        {
                            throw new ArgumentException();
                        }
                        return value;
                    }
                    else
                    {
                        return c - '0';
                    }
                }
                else if (c >= 'A' && c <= 'Z')
                {
                    return c;
                }
                else if (c == '!')
                {
                    if (isFirstChar)
                    {
                        sawOperator = true;
                        operatorPosition = (int)stream.Position;
                    }
                    else
                    {
                        throw new ArgumentException();
                    }
                    return '!';
                }
                else if ("+-*/><=\\&|^~!#$%&@]{".Contains((char)c))
                {
                    return c;
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }

        public override Expr getValue40()
        {
            int c = tr.Peek();
            if (c >= '0' && c <= '9')
            {
                c = getC();
                return new Expr(c);
            }
            else
            {
                return getCaliValue();
            }
        }

        public override string getString(int terminator)
        {
            tr.EatWhiteSpace();
            if (tr.Peek() == ',') tr.Read();

            string token = tr.ReadToken();

            //string halfWidth = Decompiler.ToHalfWidth(token);
            bw.Write(shiftJis.GetBytes(token));
            bw.Write((byte)terminator);

            return token;
        }

        public override string getConstString()
        {
            tr.EatWhiteSpace();
            if (tr.Peek() == ',') tr.Read();

            string token = tr.ReadToken();

            int terminator = 0;
            bw.Write((byte)terminator);
            var bytes = shiftJis.GetBytes(token);
            foreach (var b in bytes)
            {
                byte b2 = (byte)((b << 4) | (b >> 4));
                bw.Write(b2);
            }
            bw.Write((byte)terminator);
            return token;
        }

        public override string getAinMessage()
        {
            tr.EatWhiteSpace();
            char c = (char)tr.Peek();
            if (c == ',')
            {
                tr.Read();
                tr.EatWhiteSpace();
                c = (char)tr.Peek();
            }

            int messageNumberHint = -1;
            if (c.IsDigit())
            {
                string messageNumberString = tr.ReadToken();
                if (!IntUtil.TryParse(messageNumberString, out messageNumberHint))
                {
                    messageNumberHint = -1;
                }

                tr.EatWhiteSpace();
                c = (char)tr.Peek();
            }

            if (c == ',')
            {
                tr.Read();
                tr.EatWhiteSpace();
                c = (char)tr.Peek();
            }

            string message = tr.ReadToken();
            //encode the message
            writeAinMessage2(message, messageNumberHint);
            return message;
        }

        void writeAinMessage2(string message, int messageNumberHint)
        {
            int messageNumber = parent.AddMessage(message, messageNumberHint);
            bw.Write(messageNumber);
        }

        public override int getForLoopStart()
        {
            int c1 = getC();
            int c2 = 0;
            int c3 = 0;
            if (c1 == 0)
            {
                if (tr.Peek() == '\r' || tr.Peek() == '\n')
                {
                    throw new OperationCanceledException();
                }

                c2 = getC();
                c3 = getC();
            }
            else if (c1 == 1)
            {

            }
            return c1 + (c2 << 8) + (c3 << 16);
        }

        public void FinishFile()
        {
            int fileSize = (int)stream.Length;
            int lastPosition = (int)stream.Position;
            stream.Position = 8;
            bw.Write(fileSize);
            stream.Position = lastPosition;
        }

        public byte[] ToByteArray()
        {
            return this.stream.ToArray();
        }

        public int Address
        {
            get
            {
                return (int)this.stream.Position;
            }
        }

        public override void getVariableArguments(int libNumber, int functionNumber)
        {
            //int arg = 0;
            //var funcEntry = parent.Parent.AinFile.libraries.GetLibraryFunction(libNumber, functionNumber);
            //var args = funcEntry.Arguments;
            while (true)
            {
                string token = tr.PeekToken();
                if (token == ",")
                {
                    token = tr.ReadToken();
                    token = tr.PeekToken();
                }
                if (token == ":")
                {
                    break;
                }
                if (tr.TokenIsString)
                {
                    getString(0);
                }
                else
                {
                    getCaliValue();
                }
            }
        }

        public override void getExternalAddress(out int fileNumber, out int address)
        {
            fileNumber = -1;
            address = -1;

            string comma = tr.PeekToken();
            if (comma == ",") tr.Read();
            string labelName = tr.ReadToken();

            int outputAddress = (int)stream.Position;
            bw.Write((ushort)0);
            bw.Write((int)0);
            if (!labelName.StartsWith("0", StringComparison.Ordinal))
            {
                parent.Fixups.Add(new ScoFile.Fixup(labelName, outputAddress, 0));
            }
            else
            {

            }
        }

        public override void getExternalAddress2(out int fileNumber, out int address)
        {
            fileNumber = -1;
            address = -1;

            string comma = tr.PeekToken();
            if (comma == ",") tr.Read();
            string labelName = tr.ReadToken();
            if (labelName == "0")
            {
                bw.Write((ushort)0);
                getCaliValue();
                return;
            }
            else if (labelName == "65535")
            {
                bw.Write((ushort)65535);
                getCaliVariable();
                return;
            }

            int outputAddress = (int)stream.Position;
            bw.Write((ushort)0);
            bw.Write((int)0);
            parent.Fixups.Add(new ScoFile.Fixup(labelName, outputAddress, 0));
        }
    }

    public class MyTextReader
    {
        public int LineNumber = 0;
        public int Column = 0;
        char _quoteCharacter;
        public bool TokenIsString
        {
            get
            {
                return _quoteCharacter != 0;
            }
        }

        public MyTextReader(TextReader tr)
        {
            this.tr = tr;
        }

        TextReader tr;
        Stack<char> peeks = new Stack<char>();
        Stack<string> peekTokens = new Stack<string>();

        public int Read()
        {
            if (peekTokens.Count > 0)
            {
                var firstToken = peekTokens.Peek();
                if (firstToken.Length == 1)
                {
                    firstToken = peekTokens.Pop();
                    return firstToken[0];
                }
                else
                {

                }
            }

            int c = tr.Read();
            Column++;
            if (c == '\n')
            {
                LineNumber++;
                Column = 0;
            }
            return c;
        }

        public int Peek()
        {
            if (peekTokens.Count > 0)
            {
                var firstToken = peekTokens.Peek();
                if (firstToken.Length == 1)
                {
                    return firstToken[0];
                }
                else
                {

                }
            }
            return tr.Peek();
        }

        public void EatWhiteSpace()
        {
            int c = Peek();
            if (c == -1)
            {
                return;
            }
            while (char.IsWhiteSpace((char)c))
            {
                c = Read();
                c = Peek();
            }
        }

        public bool HasPeekToken()
        {
            return this.peekTokens.Count > 0;
        }


        public string PeekToken()
        {
            if (this.peekTokens.Count > 0)
            {
                return this.peekTokens.Peek();
            }
            else
            {
                var token = ReadToken();
                this.peekTokens.Push(token);
                return token;
            }
        }

        public string ReadToken()
        {
            if (this.peekTokens.Count > 0)
            {
                return this.peekTokens.Pop();
            }
            return ReadTokenInternal();
        }

        private string ReadTokenInternal()
        {
            _quoteCharacter = (char)0;
            EatWhiteSpace();
            int cInt = Peek();
            if (cInt == -1) return null;
            char c = (char)cInt;

            if (c.IsDigit())
            {
                bool isHex = false;
                //number?
                c = (char)Read();
                int c2 = Peek();
                if (c2 == 'x' || c2 == 'X')
                {
                    isHex = true;
                    c = (char)Read();
                    c = (char)Read();
                }
                StringBuilder sb = new StringBuilder();
                if (!isHex)
                {
                    while (true)
                    {
                        sb.Append((char)c);
                        c = (char)Peek();
                        if (c.IsDigit())
                        {
                            c = (char)Read();
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else
                {
                    while (true)
                    {
                        sb.Append((char)c);
                        c = (char)Peek();
                        if (c.IsHexDigit())
                        {
                            c = (char)Read();
                        }
                        else
                        {
                            break;
                        }
                    }
                    string hexString = sb.ToString();
                    sb.Length = 0;
                    int hexValue = 0;
                    foreach (char hexChar in hexString)
                    {
                        hexValue <<= 4;
                        hexValue += Compiler.GetHexValue(hexChar);
                    }
                    return hexValue.ToString();
                }
                return sb.ToString();
            }
            else if (c.IsSymbolChar())
            {
                //symbol?
                StringBuilder sb = new StringBuilder();
                c = (char)Read();
                while (true)
                {
                    sb.Append((char)c);
                    c = (char)Peek();
                    if (c.IsSymbolChar() || c.IsDigit())
                    {
                        c = (char)Read();
                    }
                    else
                    {
                        break;
                    }
                }
                return sb.ToString();
            }
            else if (c == '"' || c == '\'')
            {
                StringBuilder sb = new StringBuilder();
                char quoteCharacter = (char)c;
                this._quoteCharacter = quoteCharacter;
                c = (char)Read();
                while (true)
                {
                    cInt = Read();
                    c = (char)cInt;
                    if (c == quoteCharacter)
                    {
                        break;
                    }
                    if (c == '\r' || c == '\n' || cInt == -1)
                    {
                        throw new ArgumentException();
                    }
                    if (c == '\\')
                    {
                        sb.Append((char)c);
                        cInt = Read();
                        c = (char)cInt;
                    }
                    sb.Append((char)c);
                }
                return StringUtil.UnescapeString(sb.ToString());
            }
            else if ("*/%+-!=<>&^|()[]:".Contains((char)c))
            {
                //operator
                c = (char)Read();
                int c2 = Peek();
                if (c2 == '=' || c2 == ':')
                {
                    bool c2accepted = false;
                    switch (c)
                    {
                        case '!':
                        case '=':
                        case '<':
                        case '>':
                        case '+':
                        case '-':
                        case '/':
                        case '%':
                        case '*':
                        case '|':
                        case '^':
                        case '&':
                            c2accepted = true;
                            break;
                    }
                    if (c2accepted)
                    {
                        c2 = Read();
                        return string.Intern(((char)c).ToString() + (char)c2);
                    }
                }
                return string.Intern(((char)c).ToString());
            }
            else
            {
                c = (char)Read();
                return string.Intern(((char)c).ToString());
            }
        }

    }


    public static partial class Extensions
    {
        public static void EatWhiteSpace(this TextReader tr)
        {
            int c = tr.Peek();
            if (c == -1)
            {
                return;
            }
            while (char.IsWhiteSpace((char)c))
            {
                c = tr.Read();
                c = tr.Peek();
            }
        }

        public static bool IsSymbolChar(this char c)
        {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c == '_') || (c == '.') || (c >= 0x80 && !char.IsWhiteSpace(c));
        }

        public static bool IsDigit(this char c)
        {
            return (c >= '0' && c <= '9');
        }

        public static bool IsHexDigit(this char c)
        {
            return c.IsDigit() || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }

        //public static string ReadUntil(this TextReader tr, char terminator)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    while (true)
        //    {
        //        int c = tr.Read();
        //        if (c == -1 || c == '\r' || c == '\n')
        //        {
        //            throw new ArgumentException();
        //        }
        //        if (c == terminator)
        //        {
        //            break;
        //        }
        //        sb.Append((char)c);
        //    }
        //    return sb.ToString();
        //}

        public static string ReadToken(this TextReader tr)
        {
            tr.EatWhiteSpace();
            int cInt = tr.Peek();
            if (cInt == -1) return null;
            char c = (char)cInt;

            if (c.IsDigit())
            {
                bool isHex = false;
                //number?
                c = (char)tr.Read();
                int c2 = tr.Peek();
                if (c2 == 'x' || c2 == 'X')
                {
                    isHex = true;
                    c = (char)tr.Read();
                    c = (char)tr.Read();
                }
                StringBuilder sb = new StringBuilder();
                if (!isHex)
                {
                    while (true)
                    {
                        sb.Append((char)c);
                        c = (char)tr.Peek();
                        if (c.IsDigit())
                        {
                            c = (char)tr.Read();
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else
                {
                    while (true)
                    {
                        sb.Append((char)c);
                        c = (char)tr.Peek();
                        if (c.IsHexDigit())
                        {
                            c = (char)tr.Read();
                        }
                        else
                        {
                            break;
                        }
                    }
                    string hexString = sb.ToString();
                    sb.Length = 0;
                    int hexValue = 0;
                    foreach (char hexChar in hexString)
                    {
                        hexValue <<= 4;
                        hexValue += Compiler.GetHexValue(hexChar);
                    }
                    return hexValue.ToString();
                }
                return sb.ToString();
            }
            else if (c.IsSymbolChar())
            {
                //symbol?
                StringBuilder sb = new StringBuilder();
                c = (char)tr.Read();
                while (true)
                {
                    sb.Append((char)c);
                    c = (char)tr.Peek();
                    if (c.IsSymbolChar() || c.IsDigit())
                    {
                        c = (char)tr.Read();
                    }
                    else
                    {
                        break;
                    }
                }
                return sb.ToString();
            }
            else if (c == '"' || c == '\'')
            {
                StringBuilder sb = new StringBuilder();
                char quoteCharacter = (char)c;
                while (true)
                {
                    sb.Append((char)c);
                    cInt = tr.Read();
                    c = (char)cInt;
                    if (c == quoteCharacter)
                    {
                        break;
                    }
                    if (c == '\r' || c == '\n' || cInt == -1)
                    {
                        throw new ArgumentException();
                    }
                    if (c == '\\')
                    {
                        sb.Append((char)c);
                        cInt = tr.Read();
                        c = (char)cInt;
                    }
                }
                return StringUtil.UnescapeString(sb.ToString());
            }
            else if ("*/%+-!=<>&^|()[]:".Contains((char)c))
            {
                //operator
                c = (char)tr.Read();
                int c2 = tr.Peek();
                if (c2 == '=' || c2 == ':')
                {
                    bool c2accepted = false;
                    switch (c)
                    {
                        case '!':
                        case '=':
                        case '<':
                        case '>':
                        case '+':
                        case '-':
                        case '/':
                        case '%':
                        case '*':
                        case '|':
                        case '^':
                        case '&':
                            c2accepted = true;
                            break;
                    }
                    if (c2accepted)
                    {
                        c2 = tr.Read();
                        return ((char)c).ToString() + (char)c2;
                    }
                }
                return ((char)c).ToString();
            }
            else
            {
                return ((char)c).ToString();
            }
        }
    }
}
