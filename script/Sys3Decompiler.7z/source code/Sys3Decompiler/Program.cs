﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Sys3Decompiler
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DecompilerForm decompilerForm = null;

            var args = Environment.GetCommandLineArgs();
            if (args.Length >= 2)
            {
                decompilerForm = new DecompilerForm(args[1]);
            }
            else
            {
                decompilerForm = new DecompilerForm();
            }
            Application.Run(decompilerForm);
        }
    }
}
