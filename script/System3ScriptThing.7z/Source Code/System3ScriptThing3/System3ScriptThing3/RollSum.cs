﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace System3ScriptThing3
{
    public class RollSum
    {
        public static int GetHashCode(string str)
        {
            return GetHashCode(str, 0, str.Length);
        }

        public static int GetHashCode(string str, int startIndex, int length)
        {
            RollSum sum = new RollSum();
            for (int i = startIndex; i < startIndex + length; i++)
            {
                sum.RollIn(str[i]);
            }
            return sum.Digest();
        }

        uint count;
        uint s1;
        uint s2;

        const uint CharOffset = 31;

        public RollSum()
        {
            count = 0;
            s1 = 0;
            s2 = 0;
        }

        public int Digest()
        {
            return (int)((s2 << 16) | (s1 & 0xFFFF));
        }

        public void RollIn(char c)
        {
            this.s1 += c + CharOffset;
            this.s2 += this.s1;
            this.count++;
        }

        public void Rotate(char cOut, char cIn)
        {
            this.s1 += (uint)(cIn - cOut);
            this.s2 += (uint)(this.s1 - this.count * (cOut + CharOffset));
        }

        public void RollOut(char c)
        {
            this.s1 -= c + CharOffset;
            this.s2 -= this.count * (c + CharOffset);
            this.count--;
        }

        public RollSum Clone()
        {
            RollSum clone = (RollSum)MemberwiseClone();
            return clone;
        }

        public void AssignFrom(RollSum other)
        {
            this.count = other.count;
            this.s1 = other.s1;
            this.s2 = other.s2;
        }
    }
}
