﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace System3ScriptThing3
{
    public static partial class Extensions
    {
        public static void Set<T>(this HashSet<T> set, T value)
        {
            if (set.Contains(value))
            {

            }
            else
            {
                set.Add(value);
            }
        }

        public static TValue GetOrAddNew<TKey, TValue>(this IDictionary<TKey, TValue> dic, TKey key) where TValue : new()
        {
            if (dic.ContainsKey(key))
            {
                return dic[key];
            }
            else
            {
                var newItem = new TValue();
                dic.Add(key, newItem);
                return newItem;
            }
        }

        public static int IndexOfArray(this byte[] bytes, byte[] lookFor)
        {
            return IndexOfArray(bytes, lookFor, 0, bytes.Length);
        }

        public static int IndexOfArray(this byte[] bytes, byte[] lookFor, int startIndex)
        {
            return IndexOfArray(bytes, lookFor, startIndex, bytes.Length);
        }

        public static int IndexOfArray(this byte[] bytes, byte[] lookFor, int startIndex, int maxIndex)
        {
            if (startIndex == -1)
            {
                startIndex = 0;
            }
            if (lookFor.Length == 0)
            {
                return startIndex;
            }

            int limit = maxIndex - lookFor.Length;
            byte b0 = lookFor[0];
            for (int i = startIndex; i < limit; i++)
            {
                byte b = bytes[i];
                if (b == b0)
                {
                    int i2;
                    for (i2 = 1; i2 < lookFor.Length; i2++)
                    {
                        b = bytes[i + i2];
                        byte b2 = lookFor[i2];
                        if (b != b2)
                        {
                            break;
                        }
                    }
                    if (i2 >= lookFor.Length)
                    {
                        return i;
                    }
                }
            }
            return -1;
        }

        public static T GetOrNull<T>(this IList<T> list, int index)
        {
            if (index >= list.Count)
            {
                return default(T);
            }
            else
            {
                var value = list[index];
                return value;
            }
        }

        public static T GetOrDefault<T>(this IList<T> list, int index, T defaultValue)
        {
            if (index >= 0 && index < list.Count)
            {
                return list[index];
            }
            else
            {
                return defaultValue;
            }
        }


    }
}
