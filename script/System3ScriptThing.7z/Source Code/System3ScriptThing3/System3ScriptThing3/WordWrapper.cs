﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace System3ScriptThing3
{
    class WordWrapper
    {
        public int maxCharactersPerLine = 33;
        //int currentTextLine;
        bool MaintainIndentation = true;

        /// <summary>
        /// When it sees one of these characters, it indents one more fullwidth space.
        /// </summary>
        static HashSet<char> indentCharacters = new HashSet<char>("　‘“（〔［｛〈《「『【".ToCharArray());

        /// <summary>
        /// When it sees one of these characters, it treats them like ASCII characters for the purpose of wrapping lines.
        /// </summary>
        static HashSet<char> terminatingCharacters = new HashSet<char>("”’゛）〕］｝〉》」』】。、，．：？！".ToCharArray());

        /// <summary>
        /// Count the number of fullwidth spaces that must be added to maintain indentation.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        static int GetIndentSize(string text)
        {
            int indentSize = 0;
            int i = 0;
            int textLength = text.Length;
            while (i < textLength && indentCharacters.Contains(text[i]))
            {
                i++;
            }
            indentSize = i;
            return indentSize;
        }

        string remainingText = "";

        private string CombineRemainingText(string messageText)
        {
            if (String.IsNullOrEmpty(messageText))
            {
                messageText = remainingText;
                remainingText = "";
                return messageText;
            }

            int indentSize = GetIndentSize(messageText);
            if (remainingText != "")
            {
                if (indentSize > 0)
                {
                    //remove initial indent
                    messageText = messageText.Substring(indentSize);
                }
                messageText = remainingText + " " + messageText;
                remainingText = "";
            }
            return messageText;
        }

        public void HandleNextMessage(Action<string> outputLine)
        {
            while (!string.IsNullOrEmpty(remainingText))
            {
                bool dummy = false;
                HandleMessage("", ref dummy, outputLine);
            }
        }

        public void HandleMessage(string messageText, ref bool handled, Action<string> outputLine)
        {
            messageText = CombineRemainingText(messageText);

            int indentSize = GetIndentSize(messageText);
            int realSplitPosition = FindCharacterIndexOfRightMargin(messageText, maxCharactersPerLine);

            if (realSplitPosition < messageText.Length || handled == true)
            {
                handled = true;
                while (realSplitPosition < messageText.Length)
                {
                    int position = FindSplitPoint(messageText, realSplitPosition);
                    if (position <= indentSize)
                    {
                        //for really long lines - split them at the wrap position instead of an infinite loop
                        position = realSplitPosition;
                    }

                    string line = messageText.Substring(0, position);
                    outputLine(line);
                    //GenerateNextLine(handled);
                    messageText = messageText.Substring(position);

                    //eat spaces
                    position = 0;
                    while (position < messageText.Length && messageText[position] == ' ')
                    {
                        position++;
                    }
                    if (position > 0)
                    {
                        messageText = messageText.Substring(position);
                    }

                    //add indent if enabled
                    if (MaintainIndentation)
                    {
                        if (indentSize > 0)
                        {
                            messageText = "".PadLeft(indentSize, '　') + messageText;
                        }
                    }

                    //find next split
                    realSplitPosition = FindCharacterIndexOfRightMargin(messageText, maxCharactersPerLine);
                }

                //remaining text is set to something if this is a "next message" call, so output any leftover text at that time.
                this.remainingText = messageText;
            }
            if (!handled)
            {
                outputLine(messageText);
                handled = true;
            }
        }

        private static int FindSplitPoint(string line, int position)
        {
            int initialPosition = position;
            bool foundSpace = false;
            while (position >= 0)
            {
                //find a space, then find a non-space
                char c = line[position];

                if (c >= 0x80 && !terminatingCharacters.Contains(c))
                {
                    break;
                }
                if (c == ' ')
                {
                    if (!foundSpace)
                    {
                        foundSpace = true;
                    }
                }
                else
                {
                    if (foundSpace)
                    {
                        break;
                    }
                }
                position--;
            }
            position++;

            if (position <= 0 || position > initialPosition)
            {
                position = initialPosition;
            }
            return position;
        }

        /// <summary>
        /// Returns the character index where the text hits the margin, using either fixed-width or variable-width rules.
        /// </summary>
        /// <param name="messageText">The text to look inside</param>
        /// <param name="position"></param>
        /// <returns></returns>
        private int FindCharacterIndexOfRightMargin(string messageText, int position)
        {
            int stringLength = messageText.Length;
            int x = 0;
            int targetX = position;
            int i = 0;
            while (x < targetX && i < stringLength)
            {
                char c = messageText[i];
                if (c >= 0x80 && !(c >= 0xFF61 && c <= 0xFF9F))
                {
                    x += 2;
                }
                else
                {
                    x++;
                }
                i++;
            }
            return i;
        }
    }
}
