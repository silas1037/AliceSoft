﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace System3ScriptThing3
{
    public static class AldTextFinder
    {
        //static class AldFile
        //{
        //    public static int[] GetFileAddresses(string aldFileName)
        //    {
        //        using (var fs = new FileStream(aldFileName, FileMode.Open, FileAccess.Read))
        //        {
        //            return GetFileAddresses(fs);
        //        }
        //    }

        //    public static int[] GetFileAddresses(Stream fs)
        //    {
        //        long oldPosition = fs.Position;

        //        var br = new BinaryReader(fs);

        //        var first3Bytes = br.ReadBytes(3);
        //        fs.Position = 0;
        //        int headerSize = (first3Bytes[0] << 8) | (first3Bytes[1] << 16) | (first3Bytes[2] << 24);
        //        if (headerSize > 1024 * 1024)
        //        {
        //            //bad thing - probably invalid file
        //            headerSize = 1024 * 1024;
        //        }
        //        if (headerSize > fs.Length)
        //        {
        //            //bad thing - probably invalid file
        //            headerSize = (int)fs.Length;
        //        }
        //        var header = br.ReadBytes(headerSize);
        //        fs.Position = 0;

        //        int filesLimit = headerSize / 3;
        //        List<int> FileAddresses = new List<int>(filesLimit);
        //        int lastAddress = 0;
        //        for (int i = 1; i < filesLimit; i++)
        //        {
        //            int address = (header[i * 3 + 0] << 8) | (header[i * 3 + 1] << 16) | (header[i * 3 + 2] << 24);
        //            if (address == 0)
        //            {
        //                break;
        //            }
        //            if (address < lastAddress)
        //            {
        //                //bad thing
        //            }
        //            lastAddress = address;
        //            FileAddresses.Add(address);
        //        }
        //        fs.Position = oldPosition;

        //        return FileAddresses.ToArray();
        //    }

        //    public static byte[][] GetFileHeaders(Stream fs, int[] fileAddresses)
        //    {
        //        long oldPosition = fs.Position;
        //        var br = new BinaryReader(fs);
        //        List<byte[]> headers = new List<byte[]>(fileAddresses.Length);
        //        for (int i = 0; i < fileAddresses.Length; i++)
        //        {
        //            int address = fileAddresses[i];
        //            fs.Position = address;
        //            int headerLength = br.ReadInt32();
        //            if (headerLength != 0x20)
        //            {
        //                int remainingBytes = (int)fs.Length - address;
        //                if (headerLength > remainingBytes)
        //                {
        //                    headerLength = remainingBytes;
        //                }
        //            }
        //            fs.Position = address;
        //            var header = br.ReadBytes(headerLength);
        //            headers.Add(header);
        //        }
        //        fs.Position = oldPosition;
        //        return headers.ToArray();
        //    }

        //    public static string[] GetFileNames(Stream fs, int[] fileAddresses)
        //    {
        //        var fileHeaders = GetFileHeaders(fs, fileAddresses);
        //        return GetFileNames(fileHeaders);
        //    }

        //    static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        //    public static string[] GetFileNames(byte[][] fileHeaders)
        //    {
        //        List<string> fileNames = new List<string>(fileHeaders.Length);
        //        for (int i = 0; i < fileHeaders.Length; i++)
        //        {
        //            byte[] header = fileHeaders[i];
        //            string fileName;
        //            if (header.Length < 32)
        //            {
        //                fileName = "";
        //            }
        //            else
        //            {
        //                int nameLength = 0;
        //                for (nameLength = 0; nameLength < 16; nameLength++)
        //                {
        //                    if (header[16 + nameLength] == 0)
        //                    {
        //                        break;
        //                    }
        //                }

        //                fileName = shiftJis.GetString(header, 16, nameLength);
        //            }
        //            fileNames.Add(fileName);
        //        }
        //        return fileNames.ToArray();
        //    }

        //    public static int[] GetFileLengths(byte[][] fileHeaders)
        //    {
        //        List<int> fileLengths = new List<int>(fileHeaders.Length);
        //        for (int i = 0; i < fileHeaders.Length; i++)
        //        {
        //            byte[] header = fileHeaders[i];
        //            int length = BitConverter.ToInt32(header, 4);
        //            fileLengths.Add(length);
        //        }
        //        return fileLengths.ToArray();
        //    }
        //}

        //class ScoFile
        //{
        //    public int Address;
        //    public int Length;
        //    public string Name;
        //}
        //Dictionary<string, ScoFile> scoFiles = new Dictionary<string, ScoFile>();

        //string aldFileName;
        //byte[] bytes;
        //public AldTextFinder(string aldFileName)
        //{
        //    this.aldFileName = aldFileName;
        //    LoadFile(aldFileName);
        //}

        //private void LoadFile(string aldFileName)
        //{
        //    bytes = File.ReadAllBytes(aldFileName);
        //    var ms = new MemoryStream(bytes);

        //    int[] fileAddresses = AldFile.GetFileAddresses(ms);
        //    byte[][] fileHeaders = AldFile.GetFileHeaders(ms, fileAddresses);
        //    int[] fileLengths = AldFile.GetFileLengths(fileHeaders);
        //    string[] fileNames = AldFile.GetFileNames(fileHeaders);

        //    for (int i = 0; i < fileNames.Length; i++)
        //    {
        //        string fileName = fileNames[i];
        //        int length = fileLengths[i];
        //        int address = fileAddresses[i];

        //        var scoFile = new ScoFile();
        //        scoFile.Address = address + 32;
        //        scoFile.Length = length;
        //        scoFile.Name = fileName;

        //        string fileNameKey = GetFileNameKey(fileName);

        //        scoFiles[fileNameKey] = scoFile;
        //    }
        //}

        //public void SaveFile(string newFileName)
        //{
        //    File.WriteAllBytes(newFileName, this.bytes);
        //}

        ////ScoFile currentScoFile;
        //int fileAddress;
        //int maxAddress;
        //int currentAddress;
        //string currentScoFileName;
        //bool fileIsOkay = false;

        //public bool SetFileName(string fileName)
        //{
        //    fileName = Path.ChangeExtension(fileName, ".sco");
        //    var fileNameKey = GetFileNameKey(fileName);
        //    if (scoFiles.ContainsKey(fileNameKey))
        //    {
        //        var scoFile = scoFiles[fileNameKey];
        //        currentScoFileName = scoFile.Name;
        //        fileAddress = scoFile.Address;
        //        maxAddress = fileAddress + scoFile.Length;
        //        currentAddress = fileAddress;
        //        fileIsOkay = true;
        //        return true;
        //    }
        //    fileIsOkay = false;
        //    return false;
        //}

        //private static string GetFileNameKey(string fileName)
        //{
        //    fileName = Path.ChangeExtension(fileName, ".sco");
        //    var fileNameKey = ToFullWidth(fileName.ToUpperInvariant());
        //    return fileNameKey;
        //}

        //public bool FindString(string lookFor, out int strPosition, out int strLength)
        //{
        //    if (FindString(lookFor, currentAddress + 1, out strPosition, out strLength))
        //    {
        //        currentAddress = strPosition;
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        //public bool FindString(string lookFor, int startAddress, out int strPosition, out int strLength)
        //{
        //    strPosition = -1;
        //    strLength = -1;
        //    if (startAddress <= 0)
        //    {
        //        startAddress = fileAddress;
        //    }

        //    byte[] textBytes = EncodeText(lookFor);
        //    int index = bytes.IndexOfArray(textBytes, startAddress, maxAddress);
        //    if (index == -1)
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        strPosition = index;
        //        strLength = textBytes.Length;
        //        return true;
        //    }
        //}

        //public bool FileIsOkay
        //{
        //    get
        //    {
        //        return fileIsOkay;
        //    }
        //}

        //public int CurrentAddress
        //{
        //    get
        //    {
        //        return currentAddress;
        //    }
        //    set
        //    {
        //        currentAddress = value;
        //    }
        //}

        static Dictionary<char, char> FullwidthToHalfwidth = GetMakeHalfWidthTable();
        private static Dictionary<char, char> GetMakeHalfWidthTable()
        {
            string replace1 = " ｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ";
            string replace2 = "　。「」、・をぁぃぅぇぉゃゅょっーあいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわん゛゜";

            Dictionary<char, char> dic = new Dictionary<char, char>();
            for (int i = 0; i < replace1.Length; i++)
            {
                char c1 = replace1[i];
                char c2 = replace2[i];
                dic.Add(c2, c1);
            }
            return dic;
        }

        static Dictionary<char, char> HalfwidthToFullwidth = GetMakeFullWidthTable();
        private static Dictionary<char, char> GetMakeFullWidthTable()
        {
            string replace1 = " ｡｢｣､･ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ";
            string replace2 = "　。「」、・をぁぃぅぇぉゃゅょっーあいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわん゛゜";

            Dictionary<char, char> dic = new Dictionary<char, char>();
            for (int i = 0; i < replace1.Length; i++)
            {
                char c1 = replace1[i];
                char c2 = replace2[i];
                dic.Add(c1, c2);
            }
            return dic;
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public static string ToFullWidth(string halfWidthString)
        {
            var chars = halfWidthString.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (HalfwidthToFullwidth.ContainsKey(c))
                {
                    chars[i] = HalfwidthToFullwidth[c];
                }
                else if (c >= 'A' && c <= 'Z')
                {
                    chars[i] = (char)(c - 'A' + 'Ａ');
                }
                else if (c >= '0' && c <='9')
                {
                    chars[i] = (char)(c - '0' + '０');
                }
                else if (c >= 'a' && c <= 'z')
                {
                    chars[i] = (char)(c - 'a' + 'ａ');
                }
                else if (c == '=')
                {
                    chars[i] = '＝';
                }
                else if (c == ':')
                {
                    chars[i] = '：';
                }
                else if (c == '[')
                {
                    chars[i] = '［';
                }
                else if (c == ']')
                {
                    chars[i] = '］';
                }
            }
            return new string(chars);
        }

        public static string ToHalfWidth(string fullWidthString)
        {
            var chars = fullWidthString.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (FullwidthToHalfwidth.ContainsKey(c))
                {
                    chars[i] = FullwidthToHalfwidth[c];
                }
            }
            return new string(chars);
        }


        public static byte[] EncodeText(string lookFor)
        {
            var chars = lookFor.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (FullwidthToHalfwidth.ContainsKey(c))
                {
                    chars[i] = FullwidthToHalfwidth[c];
                }
            }
            return shiftJis.GetBytes(chars);
        }

        //public void PokeBytes(byte[] newBytes, int address)
        //{
        //    for (int i = 0; i < newBytes.Length; i++)
        //    {
        //        this.bytes[i + address] = newBytes[i];
        //    }
        //}





    }
}
