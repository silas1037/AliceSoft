﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System3ScriptThing3;

namespace System3ScriptThing3
{
    public static class FileUtil
    {
        public static string ReadAllText(string fileName)
        {
            var encoding = EncodingDetector.DetectEncoding(fileName);
            return File.ReadAllText(fileName, encoding);
        }
        public static string[] ReadAllLines(string fileName)
        {
            var encoding = EncodingDetector.DetectEncoding(fileName);
            return File.ReadAllLines(fileName, encoding);
        }
    }
}
