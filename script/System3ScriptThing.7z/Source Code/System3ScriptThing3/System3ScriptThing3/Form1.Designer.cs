﻿namespace System3ScriptThing3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ADVFilesTextBox = new System.Windows.Forms.TextBox();
            this.lblAdvFilesPath = new System.Windows.Forms.Label();
            this.BrowseButton1 = new System.Windows.Forms.Button();
            this.lblShiftJisPath = new System.Windows.Forms.Label();
            this.TXTFilesTextBox = new System.Windows.Forms.TextBox();
            this.BrowseButton2 = new System.Windows.Forms.Button();
            this.InsertScriptButton = new System.Windows.Forms.Button();
            this.extractScriptButton = new System.Windows.Forms.Button();
            this.WordWrapModeComboBox = new System.Windows.Forms.ComboBox();
            this.lblWordWrapMode = new System.Windows.Forms.Label();
            this.lblCharacterPerLine = new System.Windows.Forms.Label();
            this.CharactersPerLineTextBox = new System.Windows.Forms.TextBox();
            this.CharactersPerLineTextBox2 = new System.Windows.Forms.TextBox();
            this.lblFunctions = new System.Windows.Forms.Label();
            this.CustomCodeTextBox = new System.Windows.Forms.TextBox();
            this.TextLinesPerPageTextBox2 = new System.Windows.Forms.TextBox();
            this.TextLinesPerPageTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NewLineCodeTextBox = new System.Windows.Forms.TextBox();
            this.NextPageCodeTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ADVFilesTextBox
            // 
            this.ADVFilesTextBox.Location = new System.Drawing.Point(12, 25);
            this.ADVFilesTextBox.Name = "ADVFilesTextBox";
            this.ADVFilesTextBox.Size = new System.Drawing.Size(318, 20);
            this.ADVFilesTextBox.TabIndex = 1;
            // 
            // lblAdvFilesPath
            // 
            this.lblAdvFilesPath.AutoSize = true;
            this.lblAdvFilesPath.Location = new System.Drawing.Point(9, 9);
            this.lblAdvFilesPath.Name = "lblAdvFilesPath";
            this.lblAdvFilesPath.Size = new System.Drawing.Size(90, 13);
            this.lblAdvFilesPath.TabIndex = 0;
            this.lblAdvFilesPath.Text = "Path to ADV Files";
            // 
            // BrowseButton1
            // 
            this.BrowseButton1.Location = new System.Drawing.Point(12, 51);
            this.BrowseButton1.Name = "BrowseButton1";
            this.BrowseButton1.Size = new System.Drawing.Size(75, 23);
            this.BrowseButton1.TabIndex = 2;
            this.BrowseButton1.Text = "Browse...";
            this.BrowseButton1.UseVisualStyleBackColor = true;
            this.BrowseButton1.Click += new System.EventHandler(this.BrowseButton1_Click);
            // 
            // lblShiftJisPath
            // 
            this.lblShiftJisPath.AutoSize = true;
            this.lblShiftJisPath.Location = new System.Drawing.Point(12, 86);
            this.lblShiftJisPath.Name = "lblShiftJisPath";
            this.lblShiftJisPath.Size = new System.Drawing.Size(186, 13);
            this.lblShiftJisPath.TabIndex = 3;
            this.lblShiftJisPath.Text = "Path to three directories with TXT files";
            // 
            // TXTFilesTextBox
            // 
            this.TXTFilesTextBox.Location = new System.Drawing.Point(12, 102);
            this.TXTFilesTextBox.Name = "TXTFilesTextBox";
            this.TXTFilesTextBox.Size = new System.Drawing.Size(318, 20);
            this.TXTFilesTextBox.TabIndex = 4;
            // 
            // BrowseButton2
            // 
            this.BrowseButton2.Location = new System.Drawing.Point(12, 128);
            this.BrowseButton2.Name = "BrowseButton2";
            this.BrowseButton2.Size = new System.Drawing.Size(75, 23);
            this.BrowseButton2.TabIndex = 5;
            this.BrowseButton2.Text = "Browse...";
            this.BrowseButton2.UseVisualStyleBackColor = true;
            this.BrowseButton2.Click += new System.EventHandler(this.BrowseButton2_Click);
            // 
            // InsertScriptButton
            // 
            this.InsertScriptButton.Location = new System.Drawing.Point(234, 339);
            this.InsertScriptButton.Name = "InsertScriptButton";
            this.InsertScriptButton.Size = new System.Drawing.Size(96, 23);
            this.InsertScriptButton.TabIndex = 20;
            this.InsertScriptButton.Text = "Insert Script";
            this.InsertScriptButton.UseVisualStyleBackColor = true;
            this.InsertScriptButton.Click += new System.EventHandler(this.InsertScriptButton_Click);
            // 
            // extractScriptButton
            // 
            this.extractScriptButton.Location = new System.Drawing.Point(131, 339);
            this.extractScriptButton.Name = "extractScriptButton";
            this.extractScriptButton.Size = new System.Drawing.Size(97, 23);
            this.extractScriptButton.TabIndex = 19;
            this.extractScriptButton.Text = "Extract Script";
            this.extractScriptButton.UseVisualStyleBackColor = true;
            this.extractScriptButton.Click += new System.EventHandler(this.extractScriptButton_Click);
            // 
            // WordWrapModeComboBox
            // 
            this.WordWrapModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.WordWrapModeComboBox.FormattingEnabled = true;
            this.WordWrapModeComboBox.Items.AddRange(new object[] {
            "Rance 5D",
            "Daiakuji",
            "Tsumamigui",
            "Tsumamigui 2",
            "Custom",
            "None"});
            this.WordWrapModeComboBox.Location = new System.Drawing.Point(131, 161);
            this.WordWrapModeComboBox.Name = "WordWrapModeComboBox";
            this.WordWrapModeComboBox.Size = new System.Drawing.Size(121, 21);
            this.WordWrapModeComboBox.TabIndex = 7;
            this.WordWrapModeComboBox.SelectedIndexChanged += new System.EventHandler(this.WordWrapModeComboBox_SelectedIndexChanged);
            // 
            // lblWordWrapMode
            // 
            this.lblWordWrapMode.AutoSize = true;
            this.lblWordWrapMode.Location = new System.Drawing.Point(33, 164);
            this.lblWordWrapMode.Name = "lblWordWrapMode";
            this.lblWordWrapMode.Size = new System.Drawing.Size(95, 13);
            this.lblWordWrapMode.TabIndex = 6;
            this.lblWordWrapMode.Text = "Word Wrap Mode:";
            this.lblWordWrapMode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCharacterPerLine
            // 
            this.lblCharacterPerLine.AutoSize = true;
            this.lblCharacterPerLine.Location = new System.Drawing.Point(30, 191);
            this.lblCharacterPerLine.Name = "lblCharacterPerLine";
            this.lblCharacterPerLine.Size = new System.Drawing.Size(98, 13);
            this.lblCharacterPerLine.TabIndex = 8;
            this.lblCharacterPerLine.Text = "Characters per line:";
            this.lblCharacterPerLine.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CharactersPerLineTextBox
            // 
            this.CharactersPerLineTextBox.Location = new System.Drawing.Point(131, 188);
            this.CharactersPerLineTextBox.Name = "CharactersPerLineTextBox";
            this.CharactersPerLineTextBox.ReadOnly = true;
            this.CharactersPerLineTextBox.Size = new System.Drawing.Size(46, 20);
            this.CharactersPerLineTextBox.TabIndex = 9;
            this.CharactersPerLineTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.common_Validating);
            // 
            // CharactersPerLineTextBox2
            // 
            this.CharactersPerLineTextBox2.Location = new System.Drawing.Point(183, 188);
            this.CharactersPerLineTextBox2.Name = "CharactersPerLineTextBox2";
            this.CharactersPerLineTextBox2.ReadOnly = true;
            this.CharactersPerLineTextBox2.Size = new System.Drawing.Size(46, 20);
            this.CharactersPerLineTextBox2.TabIndex = 10;
            this.CharactersPerLineTextBox2.Validating += new System.ComponentModel.CancelEventHandler(this.common_Validating);
            // 
            // lblFunctions
            // 
            this.lblFunctions.Location = new System.Drawing.Point(3, 243);
            this.lblFunctions.Name = "lblFunctions";
            this.lblFunctions.Size = new System.Drawing.Size(125, 39);
            this.lblFunctions.TabIndex = 14;
            this.lblFunctions.Text = "Alternate width argument and function code:";
            this.lblFunctions.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CustomCodeTextBox
            // 
            this.CustomCodeTextBox.AcceptsReturn = true;
            this.CustomCodeTextBox.Location = new System.Drawing.Point(131, 240);
            this.CustomCodeTextBox.Multiline = true;
            this.CustomCodeTextBox.Name = "CustomCodeTextBox";
            this.CustomCodeTextBox.ReadOnly = true;
            this.CustomCodeTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.CustomCodeTextBox.Size = new System.Drawing.Size(199, 42);
            this.CustomCodeTextBox.TabIndex = 15;
            this.CustomCodeTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.common_Validating);
            // 
            // TextLinesPerPageTextBox2
            // 
            this.TextLinesPerPageTextBox2.Location = new System.Drawing.Point(183, 214);
            this.TextLinesPerPageTextBox2.Name = "TextLinesPerPageTextBox2";
            this.TextLinesPerPageTextBox2.ReadOnly = true;
            this.TextLinesPerPageTextBox2.Size = new System.Drawing.Size(46, 20);
            this.TextLinesPerPageTextBox2.TabIndex = 13;
            this.TextLinesPerPageTextBox2.Validating += new System.ComponentModel.CancelEventHandler(this.common_Validating);
            // 
            // TextLinesPerPageTextBox
            // 
            this.TextLinesPerPageTextBox.Location = new System.Drawing.Point(131, 214);
            this.TextLinesPerPageTextBox.Name = "TextLinesPerPageTextBox";
            this.TextLinesPerPageTextBox.ReadOnly = true;
            this.TextLinesPerPageTextBox.Size = new System.Drawing.Size(46, 20);
            this.TextLinesPerPageTextBox.TabIndex = 12;
            this.TextLinesPerPageTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.common_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Text lines per page:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 27);
            this.label2.TabIndex = 16;
            this.label2.Text = "New Line and Next Page code:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NewLineCodeTextBox
            // 
            this.NewLineCodeTextBox.Location = new System.Drawing.Point(131, 288);
            this.NewLineCodeTextBox.Name = "NewLineCodeTextBox";
            this.NewLineCodeTextBox.ReadOnly = true;
            this.NewLineCodeTextBox.Size = new System.Drawing.Size(46, 20);
            this.NewLineCodeTextBox.TabIndex = 17;
            // 
            // NextPageCodeTextBox
            // 
            this.NextPageCodeTextBox.Location = new System.Drawing.Point(183, 288);
            this.NextPageCodeTextBox.Name = "NextPageCodeTextBox";
            this.NextPageCodeTextBox.ReadOnly = true;
            this.NextPageCodeTextBox.Size = new System.Drawing.Size(46, 20);
            this.NextPageCodeTextBox.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 369);
            this.Controls.Add(this.NextPageCodeTextBox);
            this.Controls.Add(this.NewLineCodeTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TextLinesPerPageTextBox2);
            this.Controls.Add(this.TextLinesPerPageTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CustomCodeTextBox);
            this.Controls.Add(this.lblFunctions);
            this.Controls.Add(this.CharactersPerLineTextBox2);
            this.Controls.Add(this.CharactersPerLineTextBox);
            this.Controls.Add(this.lblCharacterPerLine);
            this.Controls.Add(this.lblWordWrapMode);
            this.Controls.Add(this.WordWrapModeComboBox);
            this.Controls.Add(this.extractScriptButton);
            this.Controls.Add(this.InsertScriptButton);
            this.Controls.Add(this.BrowseButton2);
            this.Controls.Add(this.TXTFilesTextBox);
            this.Controls.Add(this.lblShiftJisPath);
            this.Controls.Add(this.BrowseButton1);
            this.Controls.Add(this.lblAdvFilesPath);
            this.Controls.Add(this.ADVFilesTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "System 3.x Script Tool";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ADVFilesTextBox;
        private System.Windows.Forms.Label lblAdvFilesPath;
        private System.Windows.Forms.Button BrowseButton1;
        private System.Windows.Forms.Label lblShiftJisPath;
        private System.Windows.Forms.TextBox TXTFilesTextBox;
        private System.Windows.Forms.Button BrowseButton2;
        private System.Windows.Forms.Button InsertScriptButton;
        private System.Windows.Forms.Button extractScriptButton;
        private System.Windows.Forms.ComboBox WordWrapModeComboBox;
        private System.Windows.Forms.Label lblWordWrapMode;
        private System.Windows.Forms.Label lblCharacterPerLine;
        private System.Windows.Forms.TextBox CharactersPerLineTextBox;
        private System.Windows.Forms.TextBox CharactersPerLineTextBox2;
        private System.Windows.Forms.Label lblFunctions;
        private System.Windows.Forms.TextBox CustomCodeTextBox;
        private System.Windows.Forms.TextBox TextLinesPerPageTextBox2;
        private System.Windows.Forms.TextBox TextLinesPerPageTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NewLineCodeTextBox;
        private System.Windows.Forms.TextBox NextPageCodeTextBox;
    }
}

