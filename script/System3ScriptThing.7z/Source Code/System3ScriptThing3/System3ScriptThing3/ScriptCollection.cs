﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Security;
using System3ScriptThing3;
using System.Globalization;

namespace System3ScriptThing3
{
    public class ScriptCollection
    {
        public class Node
        {
            public List<string> JapaneseLines;
            public List<string> EnglishLines;
            public List<int> JapaneseLineAddresses = new List<int>();
            public List<int> JapaneseLineLengths = new List<int>();

            public int nodeNumber;

            public Node()
            {
                this.JapaneseLines = new List<string>();
                this.EnglishLines = new List<string>();
            }

            public Node(List<string> japaneseLines, List<string> englishLines, int nodeNumber)
            {
                this.JapaneseLines = japaneseLines;
                this.EnglishLines = englishLines;
                this.nodeNumber = nodeNumber;
            }
            public override string ToString()
            {
                if (JapaneseLines.Count > 0 && EnglishLines.Count > 0)
                {
                    return "JapaneseLines: " + JapaneseLines.Count + ", \"" + JapaneseLines[0] + "\", EnglishLines: " + EnglishLines.Count + ", \"" + EnglishLines[0] + "\"";
                }
                else
                {
                    return "JapaneseLines: " + JapaneseLines.Count + ", EnglishLines: " + EnglishLines.Count;
                }
            }
        }

        public class NodeList
        {
            public string FileName;
            public List<Node> Nodes = new List<Node>();
            public int TotalLineCount
            {
                get
                {
                    return Nodes.Sum(n => n.JapaneseLines.Count);
                }
            }
        }

        List<NodeList> nodeLists = new List<NodeList>();

        //AldTextFinder aldTextFinder = null;

        public void DoFiles(string path)
        {
            //aldTextFinder = new AldTextFinder(aldFileName);
            var files = Directory.GetFiles(path, "*.sjs");
            foreach (var fileName in files)
            {
                DoFile(fileName);
            }
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public static NodeList DoFile(string fileName)
        {
            var encoding = EncodingDetector.DetectEncoding(fileName);
            var lines = File.ReadAllLines(fileName, encoding);
            List<string> japaneseLines = new List<string>();
            List<string> englishLines = new List<string>();
            var nodeList = new NodeList();
            nodeList.FileName = Path.GetFileNameWithoutExtension(fileName);
            //bool foundFile = aldTextFinder.SetFileName(nodeList.FileName);
            //if (!foundFile)
            //{

            //}

            int lineNumber = -1;
            bool insideJapanese = false;

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (line.StartsWith("ASTT BEGIN_J "))
                {
                    string numberString = line.Substring("ASTT_BEGIN_J ".Length);
                    int.TryParse(numberString, out lineNumber);
                    insideJapanese = true;
                }
                else if (line.StartsWith(";ASTT BEGIN_E "))
                {
                    string numberString = line.Substring(";ASTT_BEGIN_E ".Length);
                    int.TryParse(numberString, out lineNumber);
                    insideJapanese = false;
                }
                else if (line.StartsWith(";ASTT END"))
                {
                    if (insideJapanese)
                    {

                    }
                    else
                    {
                        List<int> japaneseLineAddresses = new List<int>();
                        List<int> japaneseLineLengths = new List<int>();
                        Node node = new Node(japaneseLines, englishLines, lineNumber);
                        nodeList.Nodes.Add(node);

                        japaneseLines = new List<string>();
                        englishLines = new List<string>();
                        lineNumber = -1;
                    }
                }
                else
                {
                    if (line.Contains(";"))
                    {
                        if (line.Contains("It cost"))
                        {

                        }
                        line = line.Substring(0, line.IndexOf(';'));
                    }
                    if (lineNumber > -1 && line.Length > 0)
                    {
                        if (insideJapanese)
                        {
                            if (line.StartsWith("'") && line.EndsWith("'"))
                            {
                                line = line.Substring(1, line.Length - 2);
                            }
                            else
                            {
                                if (line.Contains('"'))
                                {
                                    int startIndex = line.IndexOf('"', 0);
                                    int secondIndex = line.IndexOf('"', startIndex + 1);

                                    int length = secondIndex - startIndex - 1;
                                    if (startIndex >= 0 && secondIndex >= 0 && length > 0)
                                    {
                                        line = line.Substring(startIndex + 1, length);
                                    }
                                }
                                else if (line.Contains('\''))
                                {
                                    int startIndex = line.IndexOf('\'', 0);
                                    int secondIndex = line.IndexOf('\'', startIndex + 1);

                                    int length = secondIndex - startIndex - 1;
                                    if (startIndex >= 0 && secondIndex >= 0 && length > 0)
                                    {
                                        line = line.Substring(startIndex + 1, length);
                                    }
                                }
                            }
                            japaneseLines.Add(line);
                        }
                        else
                        {
                            if (line.StartsWith("{") && line.EndsWith("}"))
                            {
                                line = line.Substring(1, line.Length - 2);

                                if (line.Contains('"'))
                                {
                                    int startIndex = line.IndexOf('"', 0);
                                    int secondIndex = line.IndexOf('"', startIndex + 1);

                                    int length = secondIndex - startIndex - 1;
                                    if (startIndex >= 0 && secondIndex >= 0 && length > 0)
                                    {
                                        line = line.Substring(startIndex + 1, length);
                                    }
                                }
                                else if (line.Contains('\''))
                                {
                                    int startIndex = line.IndexOf('\'', 0);
                                    int secondIndex = line.IndexOf('\'', startIndex + 1);

                                    int length = secondIndex - startIndex - 1;
                                    if (startIndex >= 0 && secondIndex >= 0 && length > 0)
                                    {
                                        line = line.Substring(startIndex + 1, length);
                                    }
                                }
                            }
                            else
                            {
                            }
                            line = line.Replace('’', '\'');
                            line = line.Replace('”', '"');
                            line = line.Replace("\\n", "\n");
                            englishLines.Add(line);
                        }
                    }
                }
            }
            //FindStrings(nodeList);
            return nodeList;
        }

        //private void FindStrings(NodeList nodeList)
        //{
        //    if (aldTextFinder.FileIsOkay)
        //    {
        //        for (int nodeIndex = 0; nodeIndex < nodeList.Nodes.Count; nodeIndex++)
        //        {
        //            var node = nodeList.Nodes[nodeIndex];
        //            for (int lineIndex = 0; lineIndex < node.JapaneseLines.Count; lineIndex++)
        //            {
        //                string jLine = node.JapaneseLines[lineIndex];
        //                string jLineNext = GetLine(nodeList, nodeIndex, lineIndex + 1);
        //                string eLine = "";

        //                if (lineIndex < node.EnglishLines.Count)
        //                {
        //                    eLine = node.EnglishLines[lineIndex];
        //                }

        //                int currentAddress = aldTextFinder.CurrentAddress;

        //                int address, length;
        //                int address2 = -1, length2 = -1;
        //                bool foundThis = aldTextFinder.FindString(jLine, currentAddress + 1, out address, out length);
        //                bool foundNext = false;
        //                if (jLineNext != "")
        //                {
        //                    foundNext = aldTextFinder.FindString(jLineNext, currentAddress + 1, out address2, out length2);
        //                }

        //                if (address2 > -1 && address2 < address && length2 > 2)
        //                {
        //                    aldTextFinder.CurrentAddress = address2 - 1;
        //                }
        //                else if (foundThis)
        //                {
        //                    aldTextFinder.CurrentAddress = address + length;
        //                }

        //                if (!foundThis && jLine != eLine)
        //                {

        //                }
        //                node.JapaneseLineAddresses.Add(address);
        //                node.JapaneseLineLengths.Add(length);

        //            }
        //        }
        //    }
        //    else
        //    {
        //        for (int nodeIndex = 0; nodeIndex < nodeList.Nodes.Count; nodeIndex++)
        //        {
        //            var node = nodeList.Nodes[nodeIndex];
        //            for (int lineIndex = 0; lineIndex < node.JapaneseLines.Count; lineIndex++)
        //            {
        //                node.JapaneseLineAddresses.Add(-1);
        //                node.JapaneseLineLengths.Add(-1);
        //            }
        //        }

        //    }
        //}

        private static string GetLine(NodeList nodeList, int nodeIndex, int lineIndex)
        {
            if (nodeIndex >= nodeList.Nodes.Count || nodeIndex < 0)
            {
                return "";
            }
            var node = nodeList.Nodes[nodeIndex];
            if (lineIndex >= node.JapaneseLines.Count)
            {
                return GetLine(nodeList, nodeIndex + 1, 0);
            }
            return node.JapaneseLines[lineIndex];
        }

        //private void FindStrings(List<string> japaneseLines, List<int> japaneseLineAddresses, List<int> japaneseLineLengths)
        //{
        //    if (aldTextFinder.FileIsOkay)
        //    {
        //        for (int i = 0; i < japaneseLines.Count; i++)
        //        {
        //            string jLine = japaneseLines[i];
        //            string jLineNext = "";
        //            if (i < japaneseLines.Count - 1)
        //            {
        //                jLineNext = japaneseLines[i + 1];
        //            }

        //            int currentAddress = aldTextFinder.CurrentAddress;

        //            int address, length;
        //            int address2 = -1, length2 = -1;
        //            bool foundThis = aldTextFinder.FindString(jLine, currentAddress + 1, out address, out length);
        //            bool foundNext = false;
        //            if (jLineNext != "")
        //            {
        //                foundNext = aldTextFinder.FindString(jLine, currentAddress + 1, out address2, out length2);
        //            }

        //            if (!foundThis && foundNext && address2 > 0)
        //            {
        //                aldTextFinder.CurrentAddress = address2;
        //            }

        //            if (!foundThis)
        //            {

        //            }
        //            japaneseLineAddresses.Add(address);
        //            japaneseLineLengths.Add(length);
        //        }
        //    }
        //}




        public void FindConflicts()
        {
            Dictionary<string, List<string>> LinesDictionary = new Dictionary<string, List<string>>();
            //string lastJLine = "";
            foreach (var nodeList in nodeLists)
            {
                foreach (var node in nodeList.Nodes)
                {
                    var j = node.JapaneseLines;
                    var e = node.EnglishLines;
                    if (j.Count == e.Count)
                    {
                        for (int i = 0; i < j.Count; i++)
                        {
                            string jLine = node.JapaneseLines[i];
                            string eLine = node.EnglishLines[i];
                            var l = LinesDictionary.GetOrAddNew(jLine);
                            if (!l.Contains(eLine))
                            {
                                l.Add(eLine);
                                if (l.Count > 1)
                                {
                                    if (node.JapaneseLineAddresses[i] == -1 && jLine != eLine)
                                    {

                                    }

                                }
                            }
                            //                            lastJLine = jLine;
                        }
                    }
                    else if (j.Count > e.Count)
                    {
                        for (int i = 0; i < j.Count; i++)
                        {
                            string jLine = node.JapaneseLines[i];
                            string eLine = " ";
                            if (i < e.Count)
                            {
                                eLine = e[i];
                            }
                            var l = LinesDictionary.GetOrAddNew(jLine);
                            if (!l.Contains(eLine))
                            {
                                l.Add(eLine);
                                if (l.Count > 1)
                                {
                                    if (node.JapaneseLineAddresses[i] == -1)
                                    {

                                    }
                                }
                            }
                            //                            lastJLine = jLine;
                        }
                    }
                    else if (e.Count > j.Count)
                    {
                        for (int i = 0; i < j.Count; i++)
                        {
                            string jLine = node.JapaneseLines[i];
                            string eLine = node.EnglishLines[i];
                            if (i == j.Count - 1)
                            {
                                int i2 = i + 1;
                                while (i2 < e.Count)
                                {
                                    eLine += "\n" + e[i2];
                                    i2++;
                                }
                            }
                            var l = LinesDictionary.GetOrAddNew(jLine);
                            if (!l.Contains(eLine))
                            {
                                l.Add(eLine);
                                if (l.Count > 1)
                                {
                                    if (node.JapaneseLineAddresses[i] == -1)
                                    {

                                    }
                                }
                            }
                            //                            lastJLine = jLine;
                        }
                    }
                }
            }
            var conflictsDictionary = new Dictionary<string, List<string>>();
            foreach (var pair in LinesDictionary)
            {
                if (pair.Value.Count > 1)
                {
                    conflictsDictionary.Add(pair.Key, pair.Value);
                }
            }
        }


        //public void MakeReplacementFile1(string replacementTextFile)
        //{
        //    Dictionary<string, string> LinesDictionary = new Dictionary<string, string>();
        //    HashSet<string> conflictsList = new HashSet<string>();
        //    GetCanonLines(LinesDictionary, conflictsList, false);

        //    TextWriter tw = new StreamWriter(replacementTextFile, false, shiftJis);

        //    foreach (var jLine in conflictsList)
        //    {
        //        tw.Write("j:" + jLine);
        //        tw.WriteLine();
        //        string eLine = LinesDictionary[jLine];
        //        eLine = eLine.Replace("\n", "\\n");
        //        tw.Write("e:" + eLine);
        //        tw.WriteLine();
        //    }

        //    foreach (var nodelist in nodeLists)
        //    {
        //        foreach (var node in nodelist.Nodes)
        //        {
        //            var j = node.JapaneseLines;
        //            var e = node.EnglishLines;
        //            if (j.Count == e.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = e[i];
        //                    eLine = eLine.Replace("\n", "\\n");
        //                    if (jLine != eLine)
        //                    {
        //                        tw.Write("j:" + jLine);
        //                        tw.WriteLine();
        //                        tw.Write("e:" + eLine);
        //                        tw.WriteLine();
        //                    }
        //                }
        //            }
        //            else if (j.Count > e.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = " ";
        //                    if (i < e.Count)
        //                    {
        //                        eLine = e[i];
        //                    }
        //                    eLine = eLine.Replace("\n", "\\n");
        //                    if (jLine != eLine)
        //                    {
        //                        tw.Write("j:" + jLine);
        //                        tw.WriteLine();
        //                        tw.Write("e:" + eLine);
        //                        tw.WriteLine();
        //                    }
        //                }
        //            }
        //            else if (e.Count > j.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = e[i];
        //                    if (i == j.Count - 1)
        //                    {
        //                        int i2 = i + 1;
        //                        while (i2 < e.Count)
        //                        {
        //                            eLine += "\n" + e[i2];
        //                            i2++;
        //                        }
        //                    }
        //                    eLine = eLine.Replace("\n", "\\n");
        //                    if (jLine != eLine)
        //                    {
        //                        tw.Write("j:" + jLine);
        //                        tw.WriteLine();
        //                        tw.Write("e:" + eLine);
        //                        tw.WriteLine();
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    tw.Flush();
        //    tw.Close();
        //    tw.Dispose();
        //}

        Random random = new Random(0);

        string GetUniqueName(Dictionary<string, string> LinesDictionary, int numberOfBytes)
        {
            int bytesRemaining;
            while (true)
            {
                bytesRemaining = numberOfBytes;
                List<byte> bytes = new List<byte>();
                while (bytesRemaining >= 2)
                {
                    int value = random.Next(0xE980, 0xE9FC + 1);
                    bytes.Add((byte)(value >> 8));
                    bytes.Add((byte)(value & 0xFF));
                    bytesRemaining -= 2;
                }
                if (bytesRemaining >= 1)
                {
                    int value = random.Next(0xA7, 0xDC + 1);
                    bytes.Add((byte)value);
                    bytesRemaining--;
                }

                string decoded = shiftJis.GetString(bytes.ToArray());
                string wide = AldTextFinder.ToFullWidth(decoded);
                byte[] bytes2 = shiftJis.GetBytes(decoded);
                if (bytes2.Length == numberOfBytes && !LinesDictionary.ContainsKey(wide))
                {
                    return decoded;
                }
            }
        }

        //private void GetCanonLines(Dictionary<string, string> LinesDictionary, HashSet<string> conflictsList, bool carryOutSplits)
        //{
        //    foreach (var nodelist in nodeLists)
        //    {
        //        foreach (var node in nodelist.Nodes)
        //        {
        //            var j = node.JapaneseLines;
        //            var e = node.EnglishLines;
        //            if (j.Count == e.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = e[i];
        //                    handleLines(LinesDictionary, conflictsList, jLine, eLine, ref i, node, carryOutSplits);
        //                }
        //            }
        //            else if (j.Count > e.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = " ";
        //                    if (i < e.Count)
        //                    {
        //                        eLine = e[i];
        //                    }
        //                    handleLines(LinesDictionary, conflictsList, jLine, eLine, ref i, node, carryOutSplits);
        //                }
        //            }
        //            else if (e.Count > j.Count)
        //            {
        //                for (int i = 0; i < j.Count; i++)
        //                {
        //                    string jLine = j[i];
        //                    string eLine = e[i];
        //                    if (i == j.Count - 1)
        //                    {
        //                        int i2 = i + 1;
        //                        while (i2 < e.Count)
        //                        {
        //                            eLine += "\n" + e[i2];
        //                            i2++;
        //                        }
        //                    }
        //                    handleLines(LinesDictionary, conflictsList, jLine, eLine, ref i, node, carryOutSplits);
        //                }
        //            }
        //        }
        //    }
        //}

        //private void handleLines(Dictionary<string, string> LinesDictionary, HashSet<string> conflictsList, string jLine, string eLine, ref int i, Node node, bool carryOutSplits)
        //{
        //    if (jLine != eLine)
        //    {
        //        if (carryOutSplits && eLine.Contains('\n'))
        //        {
        //            int jLineLength = node.JapaneseLineLengths[i];
        //            int jLineAddress = node.JapaneseLineAddresses[i];

        //            string[] eLines = eLine.Split('\n');
        //            int segmentSize = (jLineLength + 1) / eLines.Length;

        //            if (segmentSize < 3)
        //            {
        //                //bad thing
        //            }

        //            int countToInsert = eLines.Length - 1;
        //            while (countToInsert > 0)
        //            {
        //                node.EnglishLines.Insert(i + 1, "");
        //                node.JapaneseLines.Insert(i + 1, "");
        //                node.JapaneseLineLengths.Insert(i + 1, -1);
        //                node.JapaneseLineAddresses.Insert(i + 1, -1);
        //                countToInsert--;
        //            }

        //            int bytesRemaining = jLineLength;

        //            for (int i2 = 0; i2 < eLines.Length; i2++)
        //            {
        //                int newStringLength = segmentSize - 1;
        //                if (i2 == eLines.Length - 1)
        //                {
        //                    newStringLength = bytesRemaining;
        //                }

        //                string newString = GetUniqueName(LinesDictionary, newStringLength);
        //                string wideString = AldTextFinder.ToFullWidth(newString);

        //                node.EnglishLines[i + i2] = eLines[i2];
        //                node.JapaneseLines[i + i2] = wideString;
        //                node.JapaneseLineAddresses[i + i2] = jLineAddress;
        //                node.JapaneseLineLengths[i + i2] = newStringLength;

        //                var bytes = shiftJis.GetBytes(newString);

        //                aldTextFinder.PokeBytes(bytes, jLineAddress);
        //                var bytes2 = new byte[] { (byte)'R' };
        //                if (i2 < eLines.Length - 1)
        //                {
        //                    aldTextFinder.PokeBytes(bytes2, jLineAddress + newStringLength);
        //                }
        //                jLineAddress += newStringLength + 1;

        //                bytesRemaining -= newStringLength + 1;

        //                LinesDictionary.Add(wideString, eLines[i2]);
        //            }
        //            i += eLines.Length - 1;
        //            return;
        //        }

        //        if (carryOutSplits && node.EnglishLines.Count <= i)
        //        {
        //            node.EnglishLines.Insert(i, " ");
        //        }

        //        if (LinesDictionary.ContainsKey(jLine))
        //        {
        //            string oldLine = LinesDictionary[jLine];
        //            if (oldLine != eLine)
        //            {
        //                conflictsList.Set(jLine);
        //                if (eLine.Length > oldLine.Length)
        //                {
        //                    LinesDictionary[jLine] = eLine;
        //                }
        //            }
        //        }
        //        else
        //        {
        //            LinesDictionary[jLine] = eLine;
        //        }
        //    }
        //}

        //public void MakeReplacementFile2(string replacementTextFile, string outputAldFile)
        //{
        //    Dictionary<string, string> LinesDictionary = new Dictionary<string, string>();
        //    HashSet<string> conflictsList = new HashSet<string>();
        //    //first ensure that all japanese lines are represented in the list
        //    GetCanonLines(LinesDictionary, conflictsList, false);
        //    //next split lines
        //    GetCanonLines(LinesDictionary, conflictsList, true);

        //    TextWriter tw = new StreamWriter(replacementTextFile, false, shiftJis);

        //    //output replacement lines for everything else, and make lines unique if needed
        //    foreach (var nodelist in nodeLists)
        //    {
        //        foreach (var node in nodelist.Nodes)
        //        {
        //            var j = node.JapaneseLines;
        //            var e = node.EnglishLines;
        //            if (j.Count > e.Count)
        //            {
        //                //bad thing
        //            }
        //            for (int i = 0; i < j.Count; i++)
        //            {
        //                string jLine = j[i];
        //                string eLine = e[i];
        //                if (jLine != eLine)
        //                {
        //                    if (LinesDictionary.ContainsKey(jLine) && eLine != LinesDictionary[jLine] && node.JapaneseLineAddresses[i] != -1)
        //                    {
        //                        //mess with the japanese line
        //                        string newString = GetUniqueName(LinesDictionary, node.JapaneseLineLengths[i]);
        //                        jLine = AldTextFinder.ToFullWidth(newString);
        //                        node.JapaneseLines[i] = jLine;
        //                        var bytes = shiftJis.GetBytes(newString);
        //                        aldTextFinder.PokeBytes(bytes, node.JapaneseLineAddresses[i]);
        //                    }
        //                    tw.Write("j:" + jLine);
        //                    tw.WriteLine();
        //                    tw.Write("e:" + eLine);
        //                    tw.WriteLine();
        //                }
        //            }

        //        }
        //    }
        //    tw.Flush();
        //    tw.Close();
        //    tw.Dispose();
        //    aldTextFinder.SaveFile(outputAldFile);
        //}

        public static void ExtractFromAdvFiles3(string scriptPath, string advFilesPath)
        {
            var advFiles = Directory.GetFiles(advFilesPath, "*.adv", SearchOption.TopDirectoryOnly);
            for (int fileNumber = 0; fileNumber < advFiles.Length; fileNumber++)
            {
                string advFileName = advFiles[fileNumber];
                if (!Path.IsPathRooted(advFileName))
                {
                    advFileName = Path.Combine(advFilesPath, advFileName);
                }
                string baseAdvFileName = Path.GetFileNameWithoutExtension(advFileName);

                var stringFinder = new StringFinder();
                stringFinder.FindStrings(advFileName);
                bool hadNewLine = false;

                StringBuilder sbMessages = new StringBuilder();
                StringBuilder sbStrings = new StringBuilder();
                StringBuilder sbInlineMessages = new StringBuilder();
                StringWriter messages = new StringWriter(sbMessages);
                StringWriter strings = new StringWriter(sbStrings);
                StringWriter inlineMessages = new StringWriter(sbInlineMessages);

                for (int i = 0; i < stringFinder.FoundStrings.Count; i++)
                {
                    string str = stringFinder.FoundStrings[i];
                    str = StringUtil.UnescapeString(str);

                    bool hasNewline = stringFinder.LineIsFollowedByNewline(i);
                    bool isMessage = stringFinder.GetQuoteCharacter(i) == '\'';
                    int stringNumber = stringFinder.GetNumberBeforeString(i);

                    if (isMessage && stringNumber >= 0)
                    {
                        if (!hadNewLine)
                        {
                            messages.WriteLine("#" + " " + stringNumber.ToString());
                        }
                        messages.WriteLine(str);
                        hadNewLine = hasNewline;
                    }
                    else if (!isMessage)
                    {
                        strings.WriteLine(str);
                    }
                    else
                    {
                        inlineMessages.WriteLine(str);
                    }
                }

                if (sbMessages.Length > 0)
                {
                    messages.WriteLine("#");
                }
                if (sbMessages.Length > 0)
                {
                    string outputDirectory = Path.Combine(scriptPath, "messages");
                    string outputFileName = Path.Combine(outputDirectory, baseAdvFileName + ".txt");
                    Directory.CreateDirectory(outputDirectory);
                    File.WriteAllText(outputFileName, messages.ToString(), shiftJis);
                }
                if (sbStrings.Length > 0)
                {
                    string outputDirectory = Path.Combine(scriptPath, "strings");
                    string outputFileName = Path.Combine(outputDirectory, baseAdvFileName + ".txt");
                    Directory.CreateDirectory(outputDirectory);
                    File.WriteAllText(outputFileName, strings.ToString(), shiftJis);
                }
                if (sbInlineMessages.Length > 0)
                {
                    string outputDirectory = Path.Combine(scriptPath, "inlineMessages");
                    string outputFileName = Path.Combine(outputDirectory, baseAdvFileName + ".txt");
                    Directory.CreateDirectory(outputDirectory);
                    File.WriteAllText(outputFileName, inlineMessages.ToString(), shiftJis);
                }
            }
        }

        public static void ApplyToAdvFiles3(string scriptPath, string advFilesPath)
        {
            var advFiles = Directory.GetFiles(advFilesPath, "*.adv", SearchOption.TopDirectoryOnly);
            for (int fileNumber = 0; fileNumber < advFiles.Length; fileNumber++)
            {
                string advFileName = advFiles[fileNumber];
                if (!Path.IsPathRooted(advFileName))
                {
                    advFileName = Path.Combine(advFilesPath, advFileName);
                }
                string baseAdvFileName = Path.GetFileNameWithoutExtension(advFileName);

                var stringFinder = new StringFinder();
                stringFinder.FindStrings(advFileName);

                string[] messages = new string[0];
                string[] strings = new string[0];
                string[] inlineMessages = new string[0];

                string messagesFileName = Path.Combine(Path.Combine(scriptPath, "messages"), baseAdvFileName + ".txt");
                string stringsFileName = Path.Combine(Path.Combine(scriptPath, "strings"), baseAdvFileName + ".txt");
                string inlineMessagesFileName = Path.Combine(Path.Combine(scriptPath, "inlineMessages"), baseAdvFileName + ".txt");

                if (File.Exists(messagesFileName)) messages = FileUtil.ReadAllLines(messagesFileName);
                if (File.Exists(stringsFileName)) strings = FileUtil.ReadAllLines(stringsFileName);
                if (File.Exists(inlineMessagesFileName)) inlineMessages = FileUtil.ReadAllLines(inlineMessagesFileName);

                //build nodes from messages array
                Dictionary<int, Node> nodeList = new Dictionary<int, Node>();
                Dictionary<int, int> stringNumberToStringIndex = new Dictionary<int, int>();

                Node currentNode = null;

                bool hadNewLine = false;

                int currentString = 0;
                int currentInlineMessage = 0;

                string[] replacementStrings = stringFinder.FoundStrings.ToArray();

                for (int i = 0; i < stringFinder.FoundStrings.Count; i++)
                {
                    string str = stringFinder.FoundStrings[i];
                    bool hasNewline = stringFinder.LineIsFollowedByNewline(i);
                    bool isMessage = stringFinder.GetQuoteCharacter(i) == '\'';
                    int stringNumber = stringFinder.GetNumberBeforeString(i);

                    if (isMessage && stringNumber >= 0)
                    {
                        if (!hadNewLine)
                        {
                            if (currentNode != null)
                            {
                                nodeList[currentNode.nodeNumber] = currentNode;
                            }
                            currentNode = nodeList.GetOrAddNew(stringNumber);
                            stringNumberToStringIndex[stringNumber] = i;
                        }
                        if (currentNode != null)
                        {
                            currentNode.JapaneseLines.Add(str);
                        }
                        hadNewLine = hasNewline;
                    }
                    else if (!isMessage)
                    {
                        string replacementString = StringUtil.EscapeString(strings[currentString], '"');
                        replacementStrings[i] = replacementString;
                        currentString++;
                    }
                    else
                    {
                        if (currentInlineMessage < inlineMessages.Length)
                        {
                            string newMessage = StringUtil.EscapeString(inlineMessages[currentInlineMessage], '\'');
                            bool convertToAinString = false;
                            for (int charIndex = 0; charIndex < newMessage.Length; charIndex++)
                            {
                                char c = newMessage[charIndex];
                                if (c != ' ' && c < 128)
                                {
                                    convertToAinString = true;
                                    break;
                                }
                            }
                            //is line followed by [00]?
                            if (convertToAinString == true && stringFinder.LineIsFollowedByNull(i))
                            {
                                convertToAinString = false;
                            }

                            if (convertToAinString)
                            {
                                replacementStrings[i] = "/|'" + newMessage;
                                stringFinder.MoveLineBackOne(i);
                            }
                            else
                            {
                                replacementStrings[i] = newMessage;
                            }
                        }
                        currentInlineMessage++;
                    }
                }
                AddEnglishMessages(messages, nodeList, stringNumberToStringIndex, stringFinder);

                //now process the nodes
                foreach (var pair in nodeList)
                {
                    var node = pair.Value;
                    if (stringNumberToStringIndex.ContainsKey(node.nodeNumber))
                    {
                        int firstReplacementLine = stringNumberToStringIndex[node.nodeNumber];
                        if (node.EnglishLines.Count == node.JapaneseLines.Count)
                        {
                            for (int i = 0; i < node.EnglishLines.Count; i++)
                            {
                                replacementStrings[i + firstReplacementLine] = StringUtil.EscapeString(node.EnglishLines[i], '\'');
                            }
                        }
                        else
                        {
                            if (node.EnglishLines.Count < node.JapaneseLines.Count)
                            {
                                int i;
                                for (i = 0; i < node.EnglishLines.Count; i++)
                                {
                                    replacementStrings[i + firstReplacementLine] = StringUtil.EscapeString(node.EnglishLines[i], '\'');
                                }
                                for (; i < node.JapaneseLines.Count; i++)
                                {
                                    replacementStrings[i + firstReplacementLine] = "";
                                }
                            }
                            else
                            {
                                int lineWidth = stringFinder.GetLineWidth(firstReplacementLine);
                                int maxLines = Options.WordWrapOptions.LinesPerPageNormal;
                                if (lineWidth == Options.WordWrapOptions.LineWidthExpanded && lineWidth != Options.WordWrapOptions.LineWidthNormal)
                                {
                                    maxLines = Options.WordWrapOptions.LinesPerPageExpanded;
                                }

                                int row = 0;
                                int i = 0;
                                int l = node.JapaneseLines.Count - 1;
                                for (i = 0; i < l; i++)
                                {
                                    replacementStrings[i + firstReplacementLine] = StringUtil.EscapeString(node.EnglishLines[i], '\'');
                                    row++;
                                }
                                StringBuilder sb = new StringBuilder();
                                for (; i < node.EnglishLines.Count; i++)
                                {
                                    if (row >= maxLines)
                                    {
                                        row = 0;
                                        sb.Append("'\r\n" + Options.WordWrapOptions.NextPageCode + "\r\n/| '");
                                    }

                                    sb.Append(StringUtil.EscapeString(node.EnglishLines[i], '\''));
                                    row++;
                                    if (i < node.EnglishLines.Count - 1 && row < maxLines)
                                    {
                                        sb.Append("'\r\n" + Options.WordWrapOptions.NewLineCode + "\r\n/| '");
                                    }
                                }
                                replacementStrings[l + firstReplacementLine] = sb.ToString();
                            }
                        }
                    }
                    else
                    {

                    }
                }

                string outputFileName = Path.Combine(Path.GetDirectoryName(advFileName), "out");
                if (!Directory.Exists(outputFileName))
                {
                    Directory.CreateDirectory(outputFileName);
                }
                outputFileName = Path.Combine(outputFileName, Path.GetFileName(advFileName));
                stringFinder.ReplaceStrings(replacementStrings, outputFileName);
            }
        }

        private static void AddEnglishMessages(string[] messages, Dictionary<int, Node> nodeList, Dictionary<int, int> stringNumberToStringIndex, StringFinder stringFinder)
        {
            var wordWrapper = new WordWrapper();

            Node currentNode = null;
            foreach (var line in messages)
            {
                if (line.StartsWith("#"))
                {
                    if (currentNode != null)
                    {
                        wordWrapper.HandleNextMessage(currentNode.EnglishLines.Add);
                        nodeList[currentNode.nodeNumber] = currentNode;
                    }
                    currentNode = null;

                    int lineNumber;
                    if (int.TryParse(line.Substring(1), NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite, CultureInfo.InvariantCulture, out lineNumber))
                    {
                        if (stringNumberToStringIndex.ContainsKey(lineNumber))
                        {
                            int stringIndex = stringNumberToStringIndex[lineNumber];
                            wordWrapper.maxCharactersPerLine = stringFinder.GetLineWidth(stringIndex);
                        }
                        currentNode = nodeList.GetOrAddNew(lineNumber);
                        currentNode.nodeNumber = lineNumber;
                    }
                    else if (line.Length > 1)
                    {

                    }
                }
                else
                {
                    if (currentNode != null)
                    {
                        bool handled = false;
                        wordWrapper.HandleMessage(line, ref handled, currentNode.EnglishLines.Add);
                        //currentNode.EnglishLines.Add(line);
                    }
                }
            }
            if (currentNode != null)
            {
                wordWrapper.HandleNextMessage(currentNode.EnglishLines.Add);
                nodeList[currentNode.nodeNumber] = currentNode;
            }
        }

        public static void ApplyToAdvFiles2(string replaceTextFileName, string[] advFiles)
        {
            var hashFinder = new HashFinder();
            hashFinder.LoadFile(replaceTextFileName);
            string lastReplacedString = "";

            foreach (var advFileName in advFiles)
            {
                var stringFinder = new StringFinder();
                stringFinder.FindStrings(advFileName);
                List<string> replacementStringsList = new List<string>();
                foreach (var str in stringFinder.FoundStrings)
                {
                    string replacementString = hashFinder.ReplaceAll(str, ref lastReplacedString);
                    replacementStringsList.Add(replacementString);
                }
                string[] replacementStrings = replacementStringsList.ToArray();

                string outputFileName = Path.Combine(Path.GetDirectoryName(advFileName), "out");
                if (!Directory.Exists(outputFileName))
                {
                    Directory.CreateDirectory(outputFileName);
                }
                outputFileName = Path.Combine(outputFileName, Path.GetFileName(advFileName));
                stringFinder.ReplaceStrings(replacementStrings, outputFileName);
            }
        }

        public static void ApplyToAdvFiles(string[] sjsFiles, string[] advFiles)
        {
            KeyValuePair<string, string>[] commonFiles = GetMatchingFiles(sjsFiles, advFiles);
            foreach (var pair in commonFiles)
            {
                string sjsFileName = pair.Key;
                string advFileName = pair.Value;

                var nodeList = DoFile(sjsFileName);
                var stringFinder = new StringFinder();
                stringFinder.FindStrings(advFileName);

                string[] replacementStrings = GetReplacementStrings(nodeList, stringFinder.FoundStrings.ToArray());

                string outputFileName = Path.Combine(Path.GetDirectoryName(advFileName), "out");
                if (!Directory.Exists(outputFileName))
                {
                    Directory.CreateDirectory(outputFileName);
                }
                outputFileName = Path.Combine(outputFileName, Path.GetFileName(advFileName));
                stringFinder.ReplaceStrings(replacementStrings, outputFileName);
            }
        }

        private static string[] GetReplacementStrings(NodeList nodeList, string[] foundStrings)
        {
            string[] results = (string[])foundStrings.Clone();

            int strNumber = 0;
            for (int nodeIndex = 0; nodeIndex < nodeList.Nodes.Count; nodeIndex++)
            {
                var node = nodeList.Nodes[nodeIndex];
                for (int lineIndex = 0; lineIndex < node.JapaneseLines.Count; lineIndex++)
                {
                tryAgain:
                    string line = GetLine(nodeList, nodeIndex, lineIndex);
                    string nextLine = GetLine(nodeList, nodeIndex, lineIndex + 1);

                    string str = StringUtil.UnescapeString(foundStrings.GetOrDefault(strNumber, ""));
                    string nextString = StringUtil.UnescapeString(foundStrings.GetOrDefault(strNumber + 1, ""));

                    bool found = false;
                    if (line == str || (AldTextFinder.ToFullWidth(line) == AldTextFinder.ToFullWidth(str)))
                    {
                        found = true;
                    }
                    else
                    {
                        if (nextLine == nextString)
                        {

                        }
                        if (line == nextString)
                        {
                            strNumber++;
                            goto tryAgain;
                        }
                        if (nextLine == str)
                        {
                            strNumber--;
                        }
                        if (!(nextLine == nextString || line == nextString || nextLine == str))
                        {
                            strNumber--;
                        }
                    }
                    if (found)
                    {
                        string eString = StringUtil.EscapeString(node.EnglishLines.GetOrDefault(lineIndex, ""), '\'');
                        if (node.EnglishLines.Count < node.JapaneseLines.Count)
                        {

                        }
                        else if (node.EnglishLines.Count > node.JapaneseLines.Count)
                        {
                            if (lineIndex == node.JapaneseLines.Count - 1)
                            {
                                var remainingLines = node.EnglishLines.Skip(lineIndex + 1).ToArray();
                                foreach (var rem in remainingLines)
                                {
                                    eString += "\'\r\nR\r\n\'" + StringUtil.EscapeString(rem, '\'');
                                }
                            }
                        }
                        else
                        {

                        }
                        if (str != eString)
                        {
                            results[strNumber] = eString;
                        }
                    }


                    strNumber++;
                }
            }
            return results;
        }


        private static KeyValuePair<string, string>[] GetMatchingFiles(string[] sjsFiles, string[] advFiles)
        {
            var baseNamesSjs = sjsFiles.Select(f => Path.GetFileNameWithoutExtension(f)).ToArray();
            var baseNamesAdv = advFiles.Select(f => Path.GetFileNameWithoutExtension(f)).ToArray();

            Dictionary<string, int> baseNameToIndexSjs = new Dictionary<string, int>();
            List<KeyValuePair<string, string>> result = new List<KeyValuePair<string, string>>();

            for (int sjsIndex = 0; sjsIndex < baseNamesSjs.Length; sjsIndex++)
            {
                string baseNameSjs = baseNamesSjs[sjsIndex].ToUpperInvariant(); ;
                baseNameToIndexSjs[baseNameSjs] = sjsIndex;
            }
            for (int advIndex = 0; advIndex < baseNamesAdv.Length; advIndex++)
            {
                string baseNameAdv = baseNamesAdv[advIndex].ToUpperInvariant();
                if (baseNameToIndexSjs.ContainsKey(baseNameAdv))
                {
                    int sjsIndex = baseNameToIndexSjs[baseNameAdv];
                    result.Add(new KeyValuePair<string, string>(sjsFiles[sjsIndex], advFiles[advIndex]));
                }
            }
            return result.ToArray();
        }
    }

    public static class StringUtil
    {
        public static string EscapeString(string stringToEscape, char quoteChar)
        {
            StringBuilder sb = new StringBuilder(stringToEscape.Length);
            foreach (var c in stringToEscape)
            {
                if (c == '\r')
                {
                    sb.Append("\\r");
                }
                else if (c == '\n')
                {
                    sb.Append("\\n");
                }
                else if (c == '\t')
                {
                    sb.Append("\\t");
                }
                else if (c == quoteChar)
                {
                    sb.Append("\\" + c);
                }
                else if (c == '\\')
                {
                    sb.Append(@"\\");
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static string UnescapeString(string stringToUnescape)
        {
            StringBuilder sb = new StringBuilder(16);
            StringReader sr = new StringReader(stringToUnescape);

            while (true)
            {
                int charInt = sr.Read();
                if (charInt == -1)
                {
                    break;
                }
                char c = (char)charInt;

                if (c == '\\')
                {
                    charInt = sr.Read();
                    if (charInt == -1)
                    {
                        break;
                    }
                    c = (char)charInt;
                    if (c == 'r')
                    {
                        c = '\r';
                    }
                    else if (c == 'n')
                    {
                        c = '\n';
                    }
                    else if (c == 't')
                    {
                        c = '\t';
                    }
                    else if (c == '\r')
                    {
                        charInt = sr.Peek();
                        if (charInt == '\n')
                        {
                            sr.Read();
                            continue;
                        }
                        continue;
                    }
                    else if (c == '\n')
                    {
                        continue;
                    }
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

    }

}
