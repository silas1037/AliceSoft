﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Globalization;

namespace System3ScriptThing3
{
    public class MyTextReader2
    {
        TextReader tr;
        string fileName;

        public bool Logging
        {
            get;
            set;
        }

        public string FileName
        {
            get
            {
                return fileName;
            }
        }

        public int Row
        {
            get
            {
                return row;
            }
        }

        public int Column
        {
            get
            {
                return column;
            }
        }

        class TextReaderState
        {
            public int column, row;
            public TextReader textReader;
            public string fileName;

            public TextReaderState(TextReader reader, string fileName, int column, int row)
            {
                this.column = column;
                this.row = row;
                this.textReader = reader;
                this.fileName = fileName;
            }
        }
        int column, row;

        Stack<TextReaderState> otherTextReaders = new Stack<TextReaderState>();
        //Stack<string> otherFilenames = new Stack<string>();
        Stack<int> putbackCharacters = new Stack<int>();

        public MyTextReader2()
        {

        }

        public MyTextReader2(TextReader tr, string fileName)
        {
            IncludeTextReader(tr, fileName);
        }

        public void IncludeTextReader(TextReader tr, string fileName)
        {
            if (this.tr == null)
            {
                this.tr = tr;
                this.fileName = fileName;
                this.column = 0;
                this.row = 0;
            }
            else
            {
                otherTextReaders.Push(new TextReaderState(this.tr, this.fileName, this.column, this.row));
                this.tr = tr;
                this.fileName = fileName;
                this.column = 0;
                this.row = 0;
            }
        }

        int myCharacter = -1;

        protected void Putback(int character)
        {
            if (myCharacter != -1)
            {
                putbackCharacters.Push(myCharacter);
                myCharacter = -1;
            }
            putbackCharacters.Push(character);
        }

        protected int Peek()
        {
            if (myCharacter != -1)
            {
                return myCharacter;
            }

            if (putbackCharacters.Count > 0)
            {
                myCharacter = putbackCharacters.Pop();
                return myCharacter;
            }

            while (this.tr == null && otherTextReaders.Count > 0)
            {
                var state = otherTextReaders.Pop();
                this.tr = state.textReader;
                this.column = state.column;
                this.row = state.row;
                this.fileName = state.fileName;
            }

            if (this.tr == null)
            {
                myCharacter = -1;
                return myCharacter;
            }

            int result = this.tr.Read();
            if (result == -1)
            {
                this.tr.Close();
                this.tr = null;
                this.fileName = null;
                return Peek();
            }
            else if (result == '\n')
            {
                row++;
                column = 0;
            }
            else
            {
                column++;
            }

            myCharacter = result;
            return result;
        }

        protected int Read()
        {
            int result = Peek();
            myCharacter = -1;
            return result;
        }

        public void EatWhiteSpace()
        {
            while (true)
            {
                int c = this.Peek();
                if (c == -1)
                {
                    break;
                }
                else if (char.IsWhiteSpace((char)c))
                {
                    this.Read();
                }
                else
                {
                    break;
                }
            }
        }

        public string ReadLine()
        {
            StringBuilder sb = new StringBuilder();
            int c;
            while (true)
            {
                c = Read();
                if (c == '\r')
                {
                    c = Peek();
                    if (c == '\n')
                    {
                        c = Read();
                    }
                    break;
                }
                else if (c == '\n')
                {
                    break;
                }
                else if (c == -1)
                {
                    break;
                }
                sb.Append((char)c);
            }
            return sb.ToString();
        }
    }
}
