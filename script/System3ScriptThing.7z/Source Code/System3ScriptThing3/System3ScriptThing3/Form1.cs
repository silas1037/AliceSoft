﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Windows.Forms;
using AinDecompiler;
using System.Globalization;

namespace System3ScriptThing3
{
    public partial class Form1 : Form
    {
        WordWrapOptions customWordWrapOptions = WordWrapOptions.DaiakujiWordWrapOptions.Clone();
        WordWrapOptions[] wordWrapChoices = null;

        public Form1()
        {
            wordWrapChoices = new WordWrapOptions[] { WordWrapOptions.Rance5DWordWrapOptions, WordWrapOptions.DaiakujiWordWrapOptions, WordWrapOptions.TsumamiguiWordWrapOptions, WordWrapOptions.Tsumamigui2WordWrapOptions, this.customWordWrapOptions, WordWrapOptions.DisableWordWrapOptions };
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RegistryUtility.GetObject("CustomWordWrapOptions", customWordWrapOptions);
            ADVFilesTextBox.Text = RegistryUtility.GetSetting("ADVFiles", ADVFilesTextBox.Text);
            TXTFilesTextBox.Text = RegistryUtility.GetSetting("TXTFiles", TXTFilesTextBox.Text);
            int wordWrapMode = RegistryUtility.GetSetting("WordWrapMode", 0);
            if (wordWrapMode >= 0 && wordWrapMode <= 3)
            {
                WordWrapModeComboBox.SelectedIndex = wordWrapMode;
            }
            else
            {
                WordWrapModeComboBox.SelectedIndex = 0;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSettings();
        }

        private void SaveSettings()
        {
            RegistryUtility.SaveSetting("ADVFiles", ADVFilesTextBox.Text);
            RegistryUtility.SaveSetting("TXTFiles", TXTFilesTextBox.Text);
            RegistryUtility.SaveSetting("WordWrapMode", WordWrapModeComboBox.SelectedIndex);
            RegistryUtility.SaveObject("CustomWordWrapOptions", customWordWrapOptions);
        }

        private void BrowseButton1_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = false;
            openFileDialog.Filter = "System 3.x Source Files (*.ADV)|*.adv|All Files (*.*)|*.*";
            string inputFileName = ADVFilesTextBox.Text;
            SetFileDialogPath(openFileDialog, inputFileName);
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string outputFileName = openFileDialog.FileName;
                if (Directory.Exists(outputFileName))
                {

                }
                else
                {
                    outputFileName = Path.GetDirectoryName(outputFileName);
                }
                ADVFilesTextBox.Text = outputFileName;
                SaveSettings();
            }
        }

        private static void SetFileDialogPath(FileDialog openFileDialog, string inputFileName)
        {
            try
            {
                string inputFileNameDirectory = Path.GetDirectoryName(inputFileName);
                if (File.Exists(inputFileName))
                {
                    openFileDialog.FileName = inputFileName;
                    openFileDialog.InitialDirectory = inputFileNameDirectory;
                }
                else if (Directory.Exists(inputFileName))
                {
                    openFileDialog.InitialDirectory = inputFileName;
                }
                else if (Directory.Exists(inputFileNameDirectory))
                {
                    openFileDialog.InitialDirectory = inputFileNameDirectory;
                }
            }
            catch (ArgumentException)
            {

            }
            catch (IOException)
            {

            }
        }

        private void BrowseButton2_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "TXT Files (*.txt)|*.txt|All Files (*.*)|*.*";
            openFileDialog.CheckFileExists = false;
            string inputFileName = TXTFilesTextBox.Text;
            SetFileDialogPath(openFileDialog, inputFileName);
            openFileDialog.FileName = "SELECT DIRECTORY WITH TXT FILES";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string outputFileName = openFileDialog.FileName;
                string ext = Path.GetExtension(outputFileName).ToLowerInvariant();
                if (Directory.Exists(outputFileName))
                {

                }
                else
                {
                    //if (ext != ".txt" && !File.Exists(outputFileName))
                    //{
                    outputFileName = Path.GetDirectoryName(outputFileName);
                    //}
                }
                TXTFilesTextBox.Text = outputFileName;
                SaveSettings();
            }

        }

        private void InsertScriptButton_Click(object sender, EventArgs e)
        {
            SaveSettings();
            InsertScript();
        }

        private void InsertScript()
        {
            Options.WordWrapOptions = this.wordWrapChoices[WordWrapModeComboBox.SelectedIndex];

            string advFilesPath = ADVFilesTextBox.Text;
            string txtFilesPath = TXTFilesTextBox.Text;

            if (!Directory.Exists(advFilesPath))
            {
                MessageBox.Show("Please specify a valid path for ADV files", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            var advFiles = Directory.GetFiles(advFilesPath, "*.adv");
            if (advFiles.Length == 0)
            {
                MessageBox.Show("No ADV files found in the path!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (!Directory.Exists(txtFilesPath))
            {
                MessageBox.Show("Please specify a valid path for TXT files", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            ScriptCollection.ApplyToAdvFiles3(txtFilesPath, advFilesPath);
        }

        private void extractScriptButton_Click(object sender, EventArgs e)
        {
            ExtractScript();
        }

        private void ExtractScript()
        {
            string advFilesPath = ADVFilesTextBox.Text;
            string txtFilesPath = TXTFilesTextBox.Text;

            if (!Directory.Exists(advFilesPath))
            {
                MessageBox.Show("Please specify a valid path for ADV files", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            var advFiles = Directory.GetFiles(advFilesPath, "*.adv");
            if (advFiles.Length == 0)
            {
                MessageBox.Show("No ADV files found in the path!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (!Directory.Exists(txtFilesPath))
            {
                MessageBox.Show("Please specify a valid path for TXT files", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (Directory.GetDirectories(txtFilesPath).Length > 0)
            {
                if (MessageBox.Show(this, "Warning: Path already contains output files, overwrite?", "Warning", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {

                }
                else
                {
                    return;
                }
            }

            ScriptCollection.ExtractFromAdvFiles3(txtFilesPath, advFilesPath);
        }

        private void WordWrapModeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var textBoxes = new TextBox[] 
            { 
                this.CharactersPerLineTextBox, this.CharactersPerLineTextBox2, this.TextLinesPerPageTextBox, this.TextLinesPerPageTextBox2, 
                this.CustomCodeTextBox, this.NewLineCodeTextBox, this.NextPageCodeTextBox
            };
            var wordWrapOptions = this.wordWrapChoices[WordWrapModeComboBox.SelectedIndex];
            bool readOnly = wordWrapOptions != this.customWordWrapOptions;

            foreach (var textBox in textBoxes)
            {
                textBox.ReadOnly = readOnly;
                textBox.Text = "";
            }

            SetTextBoxesToWordWrapOptions(wordWrapOptions);
        }

        private void SetTextBoxesToWordWrapOptions(WordWrapOptions wordWrapOptions)
        {
            this.CustomCodeTextBox.Text = wordWrapOptions.SetExpandedCode + "\r\n" + wordWrapOptions.SetMarginFunctionCallCode;
            this.CharactersPerLineTextBox.Text = wordWrapOptions.LineWidthNormal.ToString();
            this.CharactersPerLineTextBox2.Text = wordWrapOptions.LineWidthExpanded.ToString();
            this.TextLinesPerPageTextBox.Text = wordWrapOptions.LinesPerPageNormal.ToString();
            this.TextLinesPerPageTextBox2.Text = wordWrapOptions.LinesPerPageExpanded.ToString();
            this.NewLineCodeTextBox.Text = wordWrapOptions.NewLineCode;
            this.NextPageCodeTextBox.Text = wordWrapOptions.NextPageCode;
        }

        private void SetWordWrapOptionsToTextBoxes(WordWrapOptions wordWrapOptions)
        {
            string[] lines = this.CustomCodeTextBox.Lines;
            if (lines.Length >= 2)
            {
                wordWrapOptions.SetExpandedCode = lines[0];
                wordWrapOptions.SetMarginFunctionCallCode = lines[1];
            }

            int lineWidthNormal, lineWidthExpanded, linesPerPage, linesPerPage2;
            if (int.TryParse(this.CharactersPerLineTextBox.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out lineWidthNormal))
            {
                wordWrapOptions.LineWidthNormal = lineWidthNormal;
            }
            if (int.TryParse(this.CharactersPerLineTextBox2.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out lineWidthExpanded))
            {
                wordWrapOptions.LineWidthExpanded = lineWidthExpanded;
            }
            if (int.TryParse(this.TextLinesPerPageTextBox.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out linesPerPage))
            {
                wordWrapOptions.LinesPerPageNormal = linesPerPage;
            }
            if (int.TryParse(this.TextLinesPerPageTextBox2.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out linesPerPage2))
            {
                wordWrapOptions.LinesPerPageExpanded = linesPerPage2;
            }
            wordWrapOptions.NewLineCode = this.NewLineCodeTextBox.Text;
            wordWrapOptions.NextPageCode = this.NextPageCodeTextBox.Text;
        }

        private void common_Validating(object sender, CancelEventArgs e)
        {
            var wordWrapOptions = this.wordWrapChoices[WordWrapModeComboBox.SelectedIndex];
            if (wordWrapOptions == this.customWordWrapOptions)
            {
                SetWordWrapOptionsToTextBoxes(wordWrapOptions);
            }
        }
    }
}
