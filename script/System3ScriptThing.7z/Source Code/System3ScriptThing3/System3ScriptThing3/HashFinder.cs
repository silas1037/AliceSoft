﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace System3ScriptThing3
{
    public class RollSumComparer : EqualityComparer<string>
    {
        public override bool Equals(string x, string y)
        {
            return x.Equals(y);
        }

        public override int GetHashCode(string str)
        {
            return RollSum.GetHashCode(str);
        }
    }

    public class FileNameComparer : EqualityComparer<string>
    {
        public override bool Equals(string x, string y)
        {
            try
            {
                x = Path.GetFullPath(x);
            }
            catch
            {

            }
            try
            {
                y = Path.GetFullPath(y);
            }
            catch
            {

            }
            return x.Equals(y, StringComparison.OrdinalIgnoreCase);
        }

        public override int GetHashCode(string x)
        {
            try
            {
                x = Path.GetFullPath(x);
            }
            catch
            {

            }
            return x.ToLowerInvariant().GetHashCode();
        }
    }

    public class HashFinder
    {
        HashSet<string> IncludedFilenames = new HashSet<string>(new FileNameComparer());
        HashSet<int> ReplacementsHashCodes = new HashSet<int>();
        Dictionary<string, string> Replacements = new Dictionary<string, string>();
        HashSet<int> Lengths = new HashSet<int>();
        Dictionary<string, Dictionary<string, string>> DuplicateLines = new Dictionary<string, Dictionary<string, string>>();  //first key is the line that has duplicates, second key is the previous line, value is the replacement text

        public void LoadFile(string fileName)
        {
            if (!IncludedFilenames.Contains(fileName) && File.Exists(fileName))
            {
                IncludedFilenames.Add(fileName);
            }
            else
            {
                return;
            }

            string previousJapaneseLine = "";
            string jLine = "", eLine = "";
            bool seenJLine = false;

            string[] lines = ReadAllLines(fileName);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (line.StartsWith("#"))
                {
                    if (line.Length >= 8 && line.Substring(1, 7).Equals("include", StringComparison.OrdinalIgnoreCase))
                    {
                        string fileNameToInclude = line.Substring(9);
                        if (fileNameToInclude.StartsWith("\"") && fileNameToInclude.EndsWith("\""))
                        {
                            fileNameToInclude = fileNameToInclude.Substring(1, fileNameToInclude.Length - 2);
                        }
                        if (!Path.IsPathRooted(fileNameToInclude))
                        {
                            fileNameToInclude = Path.Combine(Path.GetDirectoryName(fileName), fileNameToInclude);
                        }
                        fileNameToInclude = Path.GetFullPath(fileNameToInclude);
                        LoadFile(fileNameToInclude);
                    }
                    continue;
                }

                bool lineIsJapanese = false;
                bool lineIsEnglish = false;
                if (line.Length > 2 && line[1] == ':')
                {
                    if (line[0] == 'j' || line[0] == 'J')
                    {
                        lineIsJapanese = true;
                        line = line.Substring(2);
                    }
                    if (line[0] == 'e' || line[0] == 'E')
                    {
                        lineIsEnglish = true;
                        line = line.Substring(2);
                    }
                }
                int indexOfJapaneseCharacter = IndexOfJapaneseCharacter(line);
                if (!lineIsEnglish && (indexOfJapaneseCharacter >= 0 || lineIsJapanese))
                {
                    jLine = line;
                    seenJLine = true;
                }
                else
                {
                    eLine = line;
                    if (seenJLine)
                    {
                        Add(jLine, eLine, ref previousJapaneseLine);
                        seenJLine = false;
                    }
                }
            }
        }

        public void Add(string jLine, string eLine, ref string previousJapaneseLine)
        {
            if (Replacements.ContainsKey(jLine))
            {
                if (DuplicateLines.ContainsKey(previousJapaneseLine))
                {
                    Dictionary<string, string> secondary = DuplicateLines[previousJapaneseLine];
                    secondary[previousJapaneseLine] = eLine;
                    //if (secondary.ContainsKey(previousJapaneseLine))
                    //{
                    //    //oh noes, we now need a tree
                    //    secondary[previousJapaneseLine, eLine);
                    //}
                    //else
                    //{
                    //    secondary.Add(previousJapaneseLine, eLine);
                    //}
                }
                else
                {
                    Dictionary<String, String> secondary = new Dictionary<string, string>();
                    secondary.Add(previousJapaneseLine, eLine);
                    DuplicateLines.Add(jLine, secondary);
                }
            }
            else
            {
                ReplacementsHashCodes.Add(RollSum.GetHashCode(jLine));
                Replacements[jLine] = eLine;
            }
            previousJapaneseLine = jLine;
            Lengths.Add(jLine.Length);
        }

        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public static int IndexOfJapaneseCharacter(string text)
        {
            int length = text.Length - 1;
            for (int i = 0; i < length; i++)
            {
                int c = text[i];
                if (c >= 0x80)
                {
                    var bytes = shiftJis.GetBytes(new char[] { (char)c });
                    if (bytes.Length >= 2)
                    {
                        int b0 = bytes[0];
                        int b1 = bytes[1];
                        c = (b0 << 8) | b1;

                        if ((c >= 0x8141 && c <= 0x8149) || (c >= 0x8163 && c <= 0x8164) || //japanese punctuation
                            (c >= 0x824F && c <= 0x829A) || //fullwidth ASCII
                            (c >= 0x829F && c <= 0x82F1) || //hiragana
                            (c >= 0x8340 && c <= 0x8396) || //katakana
                            (c >= 0x889F && c <= 0xEEEC) || //kanji
                            (c >= 0xFA5C && c <= 0xFC4B)) //kanji
                        {
                            return i;
                        }
                    }
                }
            }
            return -1;
        }

        public static string[] ReadAllLines(string fileName)
        {
            Encoding encoding = EncodingDetector.DetectEncoding(fileName);
            string text = File.ReadAllText(fileName, encoding);
            text = StringUtil.UnescapeString(text);
            var stringReader = new StringReader(text);

            List<string> lines = new List<string>();

            string line;
            while ((line = stringReader.ReadLine()) != null)
            {
                lines.Add(line);
            }
            return lines.ToArray();
        }

        int depth = 0;

        public String ReplaceAll(String str, ref String lastReplacedString)
        {
            if (depth > 100) return str;

            //try entire length first
            int length = str.Length;
            if (length == 0) return str;
            depth++;
            RollSum sum = new RollSum();
            //hash entire string
            for (int i = 0; i < length; i++)
            {
                sum.RollIn(str[i]);
            }
            //int hashCode = RollsumDigest(&sum);
            //if (replacements.ContainsKey(str, hashCode))
            //{
            //	return replacements.GetValue(str, hashCode);
            //}

            RollSum baseSum = sum.Clone();
            //try each string length down to 2
            for (int l = length; l >= 1; l--)
            {
                if (l < length)
                {
                    baseSum.RollOut(str[l]);
                }
                if (!Lengths.Contains(l))
                {
                    continue;
                }
                sum.AssignFrom(baseSum);

                int limit = length - l;
                int i = 0;
                while (i <= limit)
                {
                    int hashCode = sum.Digest();
                    if (ReplacementsHashCodes.Contains(hashCode))
                    {
                        String sub = str.Substring(i, l);
                        if (Replacements.ContainsKey(sub))
                        {
                            bool found = false;
                            String replacement = "";
                            if (DuplicateLines.ContainsKey(sub))
                            {
                                Dictionary<String, String> secondary = DuplicateLines[sub];
                                if (secondary.ContainsKey(lastReplacedString))
                                {
                                    replacement = secondary[lastReplacedString];
                                    found = true;
                                }
                            }
                            if (found == false)
                            {
                                replacement = Replacements[sub];
                            }
                            String leftSide = ReplaceAll(str.Substring(0, i), ref lastReplacedString);
                            lastReplacedString = sub;
                            String rightSide = ReplaceAll(str.Substring(l + i), ref lastReplacedString);
                            String returnValue = leftSide + replacement + rightSide;
                            depth--;
                            return returnValue;
                        }
                    }
                    if (i >= limit)
                    {
                        break;
                    }
                    sum.Rotate(str[i], str[i + l]);
                    i++;
                }
            }
            depth--;
            return str;
        }
    }
}
