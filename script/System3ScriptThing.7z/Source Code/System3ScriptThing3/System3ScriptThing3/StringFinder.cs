﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Security;

namespace System3ScriptThing3
{
    class StringFinder
    {
        string fileContents;
        public Encoding encoding;
        public StringFinder()
        {
            this.FoundStrings = new StringCollection(this);
        }

        public StringCollection FoundStrings;

        public void ReplaceStrings(string[] newStrings, string outputFileName)
        {
            using (var fs = new FileStream(outputFileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
            {
                var sw = new StreamWriter(fs, this.encoding);
                int position = 0;
                for (int i = 0; i < this.stringStartPositions.Count + 1; i++)
                {
                    int nextPosition;
                    int nextPosition2;
                    if (i >= this.stringStartPositions.Count)
                    {
                        nextPosition = this.fileContents.Length;
                        nextPosition2 = nextPosition;
                    }
                    else
                    {
                        nextPosition = this.stringStartPositions[i];
                        nextPosition2 = nextPosition + this.stringLengths[i];
                    }
                    //copy from position to nextPosition
                    int chunkLength = nextPosition - position;

                    sw.Write(this.fileContents.Substring(position, chunkLength));
                    if (i < this.stringStartPositions.Count)
                    {
                        sw.Write(newStrings[i]);
                    }
                    position = nextPosition2;
                }

                sw.Flush();

                fs.Flush();
                fs.Close();
                fs.Dispose();
            }

        }


        [DebuggerTypeProxy(typeof(StringCollection.DebugView))]
        public class StringCollection : ReadOnlyIList<string>
        {
            internal class DebugView
            {
                public DebugView(StringCollection parent)
                {
                    this.parent = parent;
                }
                private StringCollection parent;
                [DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
                public string[] Rows
                {
                    get
                    {
                        return parent.ToArray();
                    }
                }

            }

            public StringCollection(StringFinder parent)
            {
                this.parent = parent;
            }
            StringFinder parent;

            public override string this[int index]
            {
                get
                {
                    return parent.fileContents.Substring(parent.stringStartPositions[index], parent.stringLengths[index]);
                }
            }

            public override int Count
            {
                get
                {
                    return parent.stringLengths.Count;
                }
            }
        }

        List<int> stringStartPositions = new List<int>();
        List<int> stringLengths = new List<int>();

        int lineWidth = Options.WordWrapOptions.LineWidthNormal;
        List<int> lineWidths = new List<int>();

        public void FindStrings(string advFileName)
        {
            lineWidth = Options.WordWrapOptions.LineWidthNormal;
            this.stringStartPositions.Clear();
            this.stringLengths.Clear();

            this.encoding = EncodingDetector.DetectEncoding(advFileName);
            this.fileContents = File.ReadAllText(advFileName, this.encoding);
            var stringReader = new MyStringReader(fileContents);

            string previousLine = "";
            while (true)
            {
                int linePosition = stringReader.Position;
                string line = stringReader.ReadLine();
                if (line == null)
                {
                    break;
                }
                int indexOfCommentCharacter = line.IndexOf(';');
                if (indexOfCommentCharacter >= 0)
                {
                    line = line.Substring(0, indexOfCommentCharacter);
                }

                if (line == Options.WordWrapOptions.SetMarginFunctionCallCode)
                {
                    if (previousLine == Options.WordWrapOptions.SetExpandedCode)
                    {
                        lineWidth = Options.WordWrapOptions.LineWidthExpanded;
                    }
                    else
                    {
                        lineWidth = Options.WordWrapOptions.LineWidthNormal;
                    }
                }

                FindStringsInLine(line, linePosition);
                previousLine = line;
            }
        }

        private void FindStringsInLine(string line, int linePosition)
        {
            int startPosition = 0;
            while (true)
            {
                int indexOfSingleQuote = line.IndexOf('\'', startPosition);
                int indexOfDoubleQuote = line.IndexOf('"', startPosition);
                if (indexOfSingleQuote == -1) indexOfSingleQuote = line.Length;
                if (indexOfDoubleQuote == -1) indexOfDoubleQuote = line.Length;

                int indexOfFirstQuote = Math.Min(indexOfSingleQuote, indexOfDoubleQuote);
                if (indexOfFirstQuote >= line.Length)
                {
                    break;
                }

                char quoteCharacter = line[indexOfFirstQuote];
                bool lastWasEscape = false;
                //look for end quote
                int i;
                for (i = indexOfFirstQuote + 1; i < line.Length; i++)
                {
                    char c = line[i];
                    if (lastWasEscape)
                    {
                        lastWasEscape = false;
                    }
                    else
                    {
                        if (c == '\\')
                        {
                            lastWasEscape = true;
                        }
                        else if (c == quoteCharacter)
                        {
                            break;
                        }
                    }
                }
                if (i >= line.Length)
                {
                    break;
                }

                stringStartPositions.Add(indexOfFirstQuote + 1 + linePosition);
                stringLengths.Add(i - (indexOfFirstQuote + 1));
                lineWidths.Add(lineWidth);

                startPosition = i + 1;
            }
        }


        public char GetQuoteCharacter(int index)
        {
            return fileContents[stringStartPositions[index] - 1];
        }

        public int GetNumberBeforeString(int index)
        {
            int i = stringStartPositions[index] - 2;
            int rightmostDigit = -1;
            int leftmostDigit = -1;

            while (i >= 0)
            {
                char c = fileContents[i];
                if (c == ' ' && rightmostDigit == -1)
                {
                    i--;
                }
                else if (c >= '0' && c <= '9')
                {
                    if (rightmostDigit == -1)
                    {
                        rightmostDigit = i + 1;
                    }
                    i--;
                }
                else
                {
                    if (rightmostDigit != -1)
                    {
                        leftmostDigit = i + 1;
                    }
                    break;
                }
            }
            int l = rightmostDigit - leftmostDigit;
            if (l >= 1)
            {
                string substr = fileContents.Substring(leftmostDigit, l);
                return int.Parse(substr);
            }
            return -1;
        }

        public bool LineIsFollowedByNewline(int index)
        {
            return LineIsFollowedByCode(index, "~R:") || LineIsFollowedByCode(index, "R");
        }
        public bool LineIsFollowedByNextPage(int index)
        {
            return LineIsFollowedByCode(index, "~A:") || LineIsFollowedByCode(index, "A");
        }

        private bool LineIsFollowedByCode(int index, string lookFor)
        {
            int i = stringStartPositions[index] + stringLengths[index] + 1;
            int j = 0;
            while (true)
            {
                if (i >= fileContents.Length)
                {
                    return false;
                }
                char c = fileContents[i];
                if (char.IsWhiteSpace(c))
                {

                }
                else
                {
                    if (c == lookFor[j])
                    {
                        j++;
                        if (j >= lookFor.Length)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                i++;
            }
        }

        public int GetLineWidth(int index)
        {
            return lineWidths[index];
        }

        public void MoveLineBackOne(int index)
        {
            stringStartPositions[index]--;
            stringLengths[index]++;
        }

        public bool LineIsFollowedByNull(int index)
        {
            int i = stringStartPositions[index] + stringLengths[index] + 1;
            int j = 0;
            string lookFor = "[00]";
            while (true)
            {
                if (i >= fileContents.Length)
                {
                    return false;
                }
                char c = fileContents[i];
                if (char.IsWhiteSpace(c))
                {

                }
                else
                {
                    if (c == lookFor[j])
                    {
                        j++;
                        if (j >= lookFor.Length)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                i++;
            }
        }
    }

    public abstract class ReadOnlyIList<T> : IList<T> where T : IEquatable<T>
    {
        public abstract T this[int index] { get; }
        public abstract int Count { get; }

        public IEnumerator<T> GetEnumerator()
        {
            return Enumerate().GetEnumerator();
        }

        #region IList<T> Members

        int IList<T>.IndexOf(T item)
        {
            int count = this.Count;
            for (int i = 0; i < count; i++)
            {
                if (this[i].Equals(item))
                {
                    return i;
                }
            }
            return -1;
        }

        void IList<T>.Insert(int index, T item)
        {
            throw new InvalidOperationException();
        }

        void IList<T>.RemoveAt(int index)
        {
            throw new InvalidOperationException();
        }

        #endregion

        #region ICollection<T> Members

        void ICollection<T>.Add(T item)
        {
            throw new InvalidOperationException();
        }

        void ICollection<T>.Clear()
        {
            throw new InvalidOperationException();
        }

        bool ICollection<T>.Contains(T item)
        {
            return ((IList<T>)this).IndexOf(item) != -1;
        }

        void ICollection<T>.CopyTo(T[] array, int arrayIndex)
        {
            int count = this.Count;
            for (int i = 0; i < count; i++)
            {
                array[arrayIndex + i] = this[i];
            }
        }

        bool ICollection<T>.IsReadOnly
        {
            get
            {
                return true;
            }
        }

        bool ICollection<T>.Remove(T item)
        {
            throw new InvalidOperationException();
        }

        #endregion

        IEnumerable<T> Enumerate()
        {
            int count = this.Count;
            for (int i = 0; i < count; i++)
            {
                yield return this[i];
            }
        }

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        #region IList<T> Members

        T IList<T>.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                throw new InvalidOperationException();
            }
        }

        #endregion
    }

    public class MyStringReader : TextReader
    {
        private string _s;
        private int _pos;
        private int _length;
        [SecuritySafeCritical]
        public MyStringReader(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException("s");
            }
            this._s = s;
            this._length = ((s == null) ? 0 : s.Length);
        }
        public override void Close()
        {
            this.Dispose(true);
        }
        protected override void Dispose(bool disposing)
        {
            this._s = null;
            this._pos = 0;
            this._length = 0;
            base.Dispose(disposing);
        }
        [SecuritySafeCritical]
        public override int Peek()
        {
            if (this._s == null)
            {
                throw new ObjectDisposedException("_s");
            }
            if (this._pos == this._length)
            {
                return -1;
            }
            return (int)this._s[this._pos];
        }
        [SecuritySafeCritical]
        public override int Read()
        {
            if (this._s == null)
            {
                throw new ObjectDisposedException("_s");
            }
            if (this._pos == this._length)
            {
                return -1;
            }
            return (int)this._s[this._pos++];
        }
        public override int Read(char[] buffer, int index, int count)
        {
            if (buffer == null)
            {
                throw new ArgumentNullException("buffer");
            }
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count");
            }
            if (buffer.Length - index < count)
            {
                throw new ArgumentException("Argument_InvalidOffLen");
            }
            if (this._s == null)
            {
                throw new ObjectDisposedException("_s");
            }
            int num = this._length - this._pos;
            if (num > 0)
            {
                if (num > count)
                {
                    num = count;
                }
                this._s.CopyTo(this._pos, buffer, index, num);
                this._pos += num;
            }
            return num;
        }
        public override string ReadToEnd()
        {
            if (this._s == null)
            {
                throw new ObjectDisposedException("_s");
            }
            string result;
            if (this._pos == 0)
            {
                result = this._s;
            }
            else
            {
                result = this._s.Substring(this._pos, this._length - this._pos);
            }
            this._pos = this._length;
            return result;
        }
        [SecuritySafeCritical]
        public override string ReadLine()
        {
            if (this._s == null)
            {
                throw new ObjectDisposedException("_s");
            }
            int i;
            for (i = this._pos; i < this._length; i++)
            {
                char c = this._s[i];
                if (c == '\r' || c == '\n')
                {
                    string result = this._s.Substring(this._pos, i - this._pos);
                    this._pos = i + 1;
                    if (c == '\r' && this._pos < this._length && this._s[this._pos] == '\n')
                    {
                        this._pos++;
                    }
                    return result;
                }
            }
            if (i > this._pos)
            {
                string result2 = this._s.Substring(this._pos, i - this._pos);
                this._pos = i;
                return result2;
            }
            return null;
        }

        public int Position
        {
            get
            {
                return _pos;
            }
        }
    }


}
