/*

�@�@Only you �`���E�N���X�`

*/
#include	<conio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<stdio.h>
#include	<io.h>
#include	<string.h>

#define	ESC	0x1b
#define	CR	0x0d
#define	MAXTBL	0x6000

#define	DLINE	16
#define DCOL	8
#define	TOPP	(buf+off)

typedef	unsigned char	uchar;
typedef	unsigned int	uint;

/* HELO �֘A�ް� */

struct	s_dfunc	{						/* dll�֐��f�[�^�L�^�p */
	uchar	*name;						/* dll�֐��� */
	int		cnt;						/* �p�����[�^�� */
	int		*para;						/* �p�����[�^��ރR�[�h */
	};

struct	s_hel	{						/* HEL�t�@�C���L�^�p */
	uchar	*name;						/* HEL�t�@�C���� */
	int		cnt;						/* �o�^�֐��̐� */
	struct s_dfunc *dfunc;				/* dll�֐��f�[�^�\���̂ւ̃|�C���^ */
	};

struct	s_hel	*hel;					/* HEL�t�@�C���\���̂ւ̃|�C���^ */

	int	hel_count;						/* HEL��`�t�@�C���̐� */
	FILE	*fp_hel;					/* HEL��`�t�@�C���p */


/* FUNC �֘A�ް� */

struct	s_func	{
	uchar	*name;						/* �֐��� */
	short	page;						/* �y�[�W�ԍ� */
	int		adr;						/* .sco�̐擪����̑��΃A�h���X */
};

struct	s_func	*func;					/* �֐����\���̂ւ̃|�C���^ */

	int	func_count;						/* �֐���`�� */


/* VARI �֘A�ް� */

struct	s_vari	{
	uchar	*name;						/* �ϐ��� */
};

struct	s_vari	*vari;					/* �֐����\���̂ւ̃|�C���^ */

	int	vari_count;						/* �ϐ���`�� */

/* MSGI �֘A�ް� */

struct	s_msgi	{
	uchar	*name;						/* �������ް� */
};

struct	s_msgi	*msgi;					/* �������ް��\���̂ւ̃|�C���^ */

	int	msgi_count;						/* �������ް��� */



	FILE	*fp,*fp2,*fp3;
	uchar	*buf;		/* file top pointer */
	uchar	*fbuf;		/* flag top pointer */
	int	pre;		/* pre count */
	int	len;		/* file length */
	int	off;		/* file offset */
	int	offtop;		/* off top */
	uint	*adr_buf;	/* if goto address */
	int	adrp;		/* buff address offset */
	int	errcnt;		/* error counter */

	uint	*label_buf;	/* label address */
	uint	*label_lib_buf;	/* label lib address */
	int	labelp;		/* label buffer address offset */

	uint	*data_buf;	/* data address */
	uint	*data_lib_buf;	/* data lib address */
	int	datap;		/* data buffer address offset */

	uint	*loop_buf;	/* loop address */
	uint	*loop_lib_buf;	/* loop lib address */
	int	loopp;		/* loop buffer address offset */

	uint	*call_buf;	/* call address */
	uint	*call_lib_buf;	/* call lib address */
	int	callp;		/* call buffer address offset */

	int	ald_len;	/* ald file length */
	uint	libcnt;		/* lib count */
	uchar	*ald_buf;	/* ald file buff */
	uchar	*ald_flg;	/* ald flag buff */

	uchar	*str;		/* string buffer */
	int	swait;		/* string wait write mode */
	int	swait2=1;

	int	pass;		/* pass */

	int	dump_mode;	/* 0: nondump 1:dump */
	int	debug_mode;	/* 0: nondebug 1:debug */
	int	pre_mode;	/* 0: nonprint 1:preprint */
	int	sen_mode;	/* 0: nonsen 1:�I�����[�h */
	int	sco_mode;	/* 0:nonsco 1:��sco�쐬 */

	int	tabcnt;		/* tab count */

	uint	varmax,varmin;	/* �ϐ��ő�l(�ő�l�ی�p) */
	int	kanji_flg;	/* �����t�B�[���h�n�m�@�n�e�e */
	char	advname[256];	/* adv name */

void	dump(void);
void	dump16(uchar *,int,int);
void	dump_err(uchar *,int,int);
int	get_block(void);
void	sputs(char *);
void	sputsi(char *,uint);
void	sputsc(char *,uchar *);
uchar	*get_adv_name(uint);
void	usage(char *);		/* �G���[���b�Z�[�W */
void	dump_sub(void);
void	copy_adv_name(uchar *,uchar *);
void	name_set(char *,char *);

uchar 	*kana_zen(uint c)
{	/* ���p�J�i��S�p�Ђ炪�Ȃɕϊ�(SYS3.5�p) */
static	uchar	*kana = "�@�B�u�v�A�E������������������[�����������������������������������ĂƂȂɂʂ˂̂͂Ђӂւق܂݂ނ߂������������h�K";
	if (c== 0x20)	return	kana;
	return	kana + (c - 0xa0)*2;
}
void	debug(char *s)
{	/* �f�o�b�O���b�Z�[�W�\�� */
	if (debug_mode)	{
		sputs(s);
	}
}		
void	debugi(char *s,uint c)
{	/* �f�o�b�O���b�Z�[�W�\���i���l�t���j */
	if (debug_mode)
		sputsi(s,c);
}		
void	set_flg(uint offset,uint cnt)
{	/* pass 0���̂݃t���O���Z�b�g���� */
	if (pass)	return;
	memset(fbuf+offset,1,cnt);
}
void	reset_flg(uint offset,uint cnt)
{	/* pass 0���̂݃t���O����Z�b�g���� */
	if (pass)	return;
	memset(fbuf+offset,0,cnt);
}
void	sputs(char *p)
{	/* ������o�� */
	if (pass && swait2)
		fprintf(fp,p);
	return;
	if (pass)	{
		if (swait)	strcat(str,p);
		else	{
			if (debug_mode)	printf(p);
			else		fprintf(fp,p);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	strcat(str,p);
			else	if (debug_mode)	printf(p);
		}
	}
}
void	sputsi(char *p,uint c)
{	/* ������o�́i���l�t���j */
	uchar	st[512];
	if (pass && swait2)
		fprintf(fp,p,c);
	return;
	if (pass)	{
		if (swait)	{
			sprintf(st,p,c);
			strcat(str,st);
		}
		else	{
			if (debug_mode)	printf(p,c);
			else		fprintf(fp,p,c);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	{
				sprintf(st,p,c);
				strcat(str,st);
			}
			else	if (debug_mode)	printf(p,c);
		}
	}
}
void	sputsc(char *p,uchar *s)
{	/* ������o�́i�ǉ�������t���j */
	uchar	st[512];
	if (pass && swait2)
		fprintf(fp,p,s);
	return;
	if (pass)	{
		if (swait)	{
			sprintf(st,p,s);
			strcat(str,st);
		}
		else	{
			if (debug_mode)	printf(p,s);
			else		fprintf(fp,p,s);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	{
				sprintf(st,p,s);
				strcat(str,st);
			}
			else	if (debug_mode)	printf(p,s);
		}
	}
}
void	usage(char *p)		/* �G���[���b�Z�[�W */
{
	if (pass)	fclose(fp);
	puts( "\nUsage : DC39 file [T][D][P][A���ڽ��`̧��][N][S]" );
	puts( p );
	exit( 1 );
}
void	*chk_malloc(int size)
{	/* �`�F�b�N�@�\�t���������A���P�[�V���� */
	void *mem;
	mem=malloc(size);
	if (mem==NULL)	usage("��ذ���۹���݂ł��܂���");
	return	mem;
}
int	kana_chk(uint c)
{	/* ���������`�F�b�N�iSYS3.5������p�j */
	if (c==0x20)	return	1;
	if (c>0xa0 && c<0xe0)	return	1;
	return	0;
}
int	kanji_chk(uint c)
{	/* ������P�o�C�g�`�F�b�N */
	if ((c>(uint)0x80 && c<(int)0xa0) || (c>=(uint)0xe0 && c<=(uint)0xef))	return	1;
	return	0;
}
int	kanji_chk2(uint c)
{	/* ������Q�o�C�g�`�F�b�N */
	if (c>=0x40 && c!=0x7f && c!=0xff)	return	1;
	return	0;
}
void	tab(void)
{	/* �C���f���g��TAB�����o�� */
	int	lp;
	if (sen_mode)	return;
	for (lp=0;lp<tabcnt;lp++)	{
		sputs("\t");
	}
}
void	put_1(void)
{	/* �P�����R�}���h�W�J */
	debug(" put_1");
	tab();
	sputsi("%c",*TOPP);
	dump16(buf,off,1);
	set_flg(off,1);
	off++;
}
void	put_str(void)
{	/* �R�}���h��������W�J */
	uchar	c,*kana;
	uint	woff;
	int	cnt;
	woff = off;
	cnt = 0;
	while ((c = *TOPP) != ':')	{
		if (cnt >= 128)	{
			dump_err(buf,woff,off - woff);
			usage("�����񂪂P�Q�W�o�C�g�ȏ゠��");
		}
		if (c<0x20)	{
			dump_err(buf,woff,off - woff);
			usage("������ɕs���Ȃ��̂�����");
		}
		if (kanji_chk(*TOPP))	{
			sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
			sputsi("%c",*TOPP);
			cnt++;
		}
		else
		if (kana_chk(*TOPP))	{
			kana = kana_zen(*TOPP);
			sputsi("%c",*kana);
			sputsi("%c",*(kana+1));
		}
		else	sputsi("%c",*TOPP);
		set_flg(off,1);
		off++;
		cnt++;
	}
	set_flg(off,1);
	off++;
}
void	put_strd(void)
{	/* ������o�͑I�����p */
	uchar	c,*kana;
	uint	woff;
	int	cnt;
	woff = off;
	cnt = 0;
	while ((c = *TOPP) != '$')	{
		if (cnt >= 128)	{
			dump_err(buf,woff,off - woff);
			usage("�I�����p�����񂪂P�Q�W�o�C�g�ȏ゠��");
		}
		if (c<0x20)	{
			dump_err(buf,woff,off - woff);
			usage("�I�����p������ɕs���Ȃ��̂�����");
		}
		if (kanji_chk(*TOPP))	{
			sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
			sputsi("%c",*TOPP);
			cnt++;
		}
		else
		if (kana_chk(*TOPP))	{
			kana = kana_zen(*TOPP);
			sputsi("%c",*kana);
			sputsi("%c",*(kana+1));
		}
		else	sputsi("%c",*TOPP);
		set_flg(off,1);
		off++;
		cnt++;
	}
	set_flg(off,1);
	off++;
}
void	put_strz(void)
{	/* �R�}���h��������W�J(sys38�p) */
	uchar	c,*kana;
	uint	woff;
	int	cnt;
	woff = off;
	cnt = 0;
	while ((c = *TOPP) != 0x00)	{
		if (cnt >= 128)	{
			dump_err(buf,woff,off - woff);
			usage("�����񂪂P�Q�W�o�C�g�ȏ゠��");
		}
		if (c<0x20)	{
			dump_err(buf,woff,off - woff);
			usage("������ɕs���Ȃ��̂�����");
		}
		if (kanji_chk(*TOPP))	{
			sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
			sputsi("%c",*TOPP);
			cnt++;
		} else if (c==0x22 || c==0x27 || c==0x5c) {
			sputsi("%c",0x5c);
			sputsi("%c",c);
		} else
			sputsi("%c",*TOPP);
		set_flg(off,1);
		off++;
		cnt++;
	}
	set_flg(off,1);
	off++;
}
int	back_str(uchar *p,int sp)
{	/* �ЂƂO�̃X�g�����O�|�C���g�𓾂� */
	int	lp;
	if (sp==0)	return	sp;
	sp--;
	while (sp)	{
		sp--;
		if (p[sp] == 0)	return	sp+1;
	}
	return	sp;
}
int	chk_stpd(int stp,int woff)
{	/* �v�Z���W�J�p�����ُ�͈͔���BϲŽ���g�p�O�A��׽���g�p������� �_�~�[�p */
	if (stp==0 || stp>=127)	{
		return	1;	/* �ُ� */
	}
	return	0;	/* ����͈� */
}
int	chk_stp(int stp,int woff)
{	/* �v�Z���W�J�p�����ُ�͈͔���BϲŽ���g�p�O�A��׽���g�p������� */
	if (stp==0 || stp>=127)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			varmax = varmin;	/* �ϐ��}�b�N�X�߂� */
			return	1;	/* �ُ� */
		}
		else	usage("�v�Z���W�J�G���[");
	}
	return	0;	/* ����͈� */
}
int	chk_rpo(int woff)	/* woff ���������擪 */
{	/* 1: �n�j	0:�m�f */
	uchar	c,c1;
	uint	num;
	uint	st[128];
	uchar	p[4096],pt[4096];
	int	cnt,lp,sp,s1,s2,s3,stp,t3;
/*	varmin = varmax;	*/
	stp = sp = 0;
	p[0] =0;
	pt[0] = 0;
loop:	c = *TOPP;
/*	set_flg(off,1);	*/
	off++;
	if (c>=0xc0)	{
		if (c==0xc0 && *TOPP == 1)	{	/* �z�� */
/*			set_flg(off,3);	*/
			off++;
			num = *TOPP * 256;
			off++;
			num += *TOPP;
			s1 = sp + sprintf(&p[sp],"%s[",vari[num].name) + 1;
/*			if (varmax < num)	varmax = num;	*/
			sp = s1;
			st[stp++] = 2;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			off++;
		}
		else if (c==0xc0 && (*TOPP==2 || *TOPP==3 || *TOPP==4))	{
/*			set_flg(off,1);	*/
			c1 = *TOPP;
			off++;
			switch(c1)	{
			case	2:
				s1 = sp + sprintf(&p[sp],"pp") + 1;
				st[stp++] = 3;
				if (chk_stpd(stp,woff))	return	0;
				sp = s1;
				break;
			case	3:
				s1 = sp + sprintf(&p[sp],"<=") + 1;
				st[stp++] = 3;
				if (chk_stpd(stp,woff))	return	0;
				sp = s1;
				break;
			case	4:
				s1 = sp + sprintf(&p[sp],">=") + 1;
				st[stp++] = 3;
				if (chk_stpd(stp,woff))	return	0;
				sp = s1;
				break;
			}
			s1 = back_str(p,sp);
			if (chk_stpd(stp,woff))	return	0;
			--stp;
			s2 = back_str(p,s1);
			if (chk_stpd(stp,woff))	return	0;
			--stp;
			s3 = back_str(p,s2);
			if (chk_stpd(stp,woff))	return	0;
			t3 = st[--stp];
			sprintf(pt,"(%s%s%s)",&p[s3],&p[s1],&p[s2]);
			if (t3 == 2)	{
				strcat(pt,"]");
/*				set_flg(off,1);	*/
				off++;
			}
			s3 += sprintf(&p[s3],pt) + 1;  
			st[stp++] = 4;
			if (chk_stpd(stp,woff))	return	0;
			pt[0] = 0;
			sp = s3;
		}
		else	{	/* �ϐ� */
			s1 = sp + sprintf(&p[sp],"%s",vari[num = (c - 0xc0)*256 + *TOPP].name) + 1;
/*			printf("var = %s\n",vari[num]);	*/
/*			if (varmax < num)	varmax = num;	*/
			sp = s1;
			st[stp++] = 1;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			set_flg(off,1);
			off++;
		}
	}
	else
	if (c>=0x80)	{	/* �ϐ� */
		s1 = sp + sprintf(&p[sp],"%s",vari[num = c - 0x80].name) + 1;
/*		printf("var = %s\n",vari[num]);	*/
/*		if (varmax < num)	varmax = num;	*/
		sp = s1;
		st[stp++] = 1;
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
	}
	else
	if (c == 0x7f)	{
		s1 = back_str(p,sp);	/* ����� */
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		if (s1>0)	{
			s2 = back_str(p,s1);	/* �O���� */
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			--stp;
			sprintf(pt,"%s%s]",&p[s2],&p[s1]);
			s2 += sprintf(&p[s2],pt) + 1;
			st[stp++] = 4;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			pt[0] = 0;
			sp = s2;
			goto	loop;
		}
		for(cnt=0;cnt<4096;cnt++) if (p[cnt]==0x70) p[cnt] = 0x25;
/*		sputs(p);	*/
		return	1;	/* ���� */
	}
	else
	if (c>=0x74)	{	/* ���Z�q */
		switch (c)	{
		case	0x79:
			s1 = sp + sprintf(&p[sp],"+") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7a:
			s1 = sp + sprintf(&p[sp],"-") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x77:
			s1 = sp + sprintf(&p[sp],"*") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x78:
			s1 = sp + sprintf(&p[sp],"/") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7e:
			s1 = sp + sprintf(&p[sp],"\\") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x74:
			s1 = sp + sprintf(&p[sp],"&") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x75:
			s1 = sp + sprintf(&p[sp],"|") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x76:
			s1 = sp + sprintf(&p[sp],"^") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7b:
			s1 = sp + sprintf(&p[sp],"=") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7c:
			s1 = sp + sprintf(&p[sp],"<") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7d:
			s1 = sp + sprintf(&p[sp],">") + 1;
			st[stp++] = 3;
			if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		}
		s1 = back_str(p,sp);	/* ���Z�q */
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s2 = back_str(p,s1);	/* ����� */
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s3 = back_str(p,s2);	/* �O���� */
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
		t3 = st[--stp];
		sprintf(pt,"(%s%s%s)",&p[s3],&p[s1],&p[s2]);
		if (t3 == 2)	{
			strcat(pt,"]");
/*			set_flg(off,1);	*/
			off++;
		}
		s3 += sprintf(&p[s3],pt) + 1;  
		st[stp++] = 4;
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
		pt[0] = 0;
		sp = s3;
	}
	else
	if (c>=0x40)	{	/* ���l */
		s1 = sp + sprintf(&p[sp],"%d",c - 0x40) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
	}	
	else	{		/* ���l */
		num =(uint)c * 256 + *TOPP;
		s1 = sp + sprintf(&p[sp],"%d",num) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stpd(stp,woff))	return	0;/* stp�͈͔��� */
/*		set_flg(off,1);	*/
		off++;
	}
	goto	loop;
}
int	put_rpo(int woff)	/* woff ���������擪 */
{	/* 1: �n�j	0:�m�f */
	uchar	c,c1;
	uint	num;
	uint	st[4096];
	uchar	p[8192],pt[8192];
	int	cnt,lp,sp,s1,s2,s3,stp,t3;
	varmin = varmax;
	stp = sp = 0;
	p[0] =0;
	pt[0] = 0;
loop:	c = *TOPP;
	set_flg(off,1);
	off++;
	if (c>=0xc0)	{
		if (c==0xc0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			num += *TOPP;
			s1 = sp + sprintf(&p[sp],"%s[",vari[num].name) + 1;
			if (varmax < num)	varmax = num;
			sp = s1;
			st[stp++] = 2;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			off++;
		}
		else if (c==0xc0 && (*TOPP==2 || *TOPP==3 || *TOPP==4))	{
			set_flg(off,1);
			c1 = *TOPP;
			off++;
			switch(c1)	{
			case	2:
				s1 = sp + sprintf(&p[sp],"\x01\x01") + 1;
				st[stp++] = 3;
				if (chk_stp(stp,woff))	return	0;
				sp = s1;
				break;
			case	3:
				s1 = sp + sprintf(&p[sp],"<=") + 1;
				st[stp++] = 3;
				if (chk_stp(stp,woff))	return	0;
				sp = s1;
				break;
			case	4:
				s1 = sp + sprintf(&p[sp],">=") + 1;
				st[stp++] = 3;
				if (chk_stp(stp,woff))	return	0;
				sp = s1;
				break;
			}
			s1 = back_str(p,sp);
			if (chk_stp(stp,woff))	return	0;
			--stp;
			s2 = back_str(p,s1);
			if (chk_stp(stp,woff))	return	0;
			--stp;
			s3 = back_str(p,s2);
			if (chk_stp(stp,woff))	return	0;
			t3 = st[--stp];
			sprintf(pt,"(%s%s%s)",&p[s3],&p[s1],&p[s2]);
			if (t3 == 2)	{
				strcat(pt,"]");
				set_flg(off,1);
				off++;
			}
			s3 += sprintf(&p[s3],pt) + 1;
			st[stp++] = 4;
			if (chk_stp(stp,woff))	return	0;
			pt[0] = 0;
			sp = s3;
		}
		else	{	/* �ϐ� */
			s1 = sp + sprintf(&p[sp],"%s",vari[num = (c - 0xc0)*256 + *TOPP].name) + 1;
/*			printf("var = %s\n",vari[num]);	*/
			if (varmax < num)	varmax = num;
			sp = s1;
			st[stp++] = 1;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			set_flg(off,1);
			off++;
		}
	}
	else
	if (c>=0x80)	{	/* �ϐ� */
		num = c - 0x80;
		s1 = sp + sprintf(&p[sp],"%s",vari[num].name) + 1;
/*		printf("%s, sp = %d\n",&p[sp],sp);	*/
		if (varmax < num)	varmax = num;
		sp = s1;
		st[stp++] = 1;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
	}
	else
	if (c == 0x7f)	{
		s1 = back_str(p,sp);	/* ����� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		if (s1>0)	{
			s2 = back_str(p,s1);	/* �O���� */
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			--stp;
			sprintf(pt,"%s%s]",&p[s2],&p[s1]);
/*			printf("s2 = <%s> s1 = <%s>\n",&p[s2],&p[s1]);	*/
			s2 += sprintf(&p[s2],pt) + 1;
			st[stp++] = 4;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			pt[0] = 0;
			sp = s2;
			goto	loop;
		}
		for(cnt=0;cnt<4096;cnt++) if (p[cnt]==0x01) p[cnt] = 0x25;
		sputs(p);
		return	1;	/* ���� */
	}
	else
	if (c>=0x74)	{	/* ���Z�q */
		switch (c)	{
		case	0x79:
			s1 = sp + sprintf(&p[sp],"+") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7a:
			s1 = sp + sprintf(&p[sp],"-") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x77:
			s1 = sp + sprintf(&p[sp],"*") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x78:
			s1 = sp + sprintf(&p[sp],"/") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7e:
			s1 = sp + sprintf(&p[sp],"\\") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x74:
			s1 = sp + sprintf(&p[sp],"&") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x75:
			s1 = sp + sprintf(&p[sp],"|") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x76:
			s1 = sp + sprintf(&p[sp],"^") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7b:
			s1 = sp + sprintf(&p[sp],"=") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7c:
			s1 = sp + sprintf(&p[sp],"<") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7d:
			s1 = sp + sprintf(&p[sp],">") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		}
		s1 = back_str(p,sp);	/* ���Z�q */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s2 = back_str(p,s1);	/* ����� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s3 = back_str(p,s2);	/* �O���� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		t3 = st[--stp];
		sprintf(pt,"(%s%s%s)",&p[s3],&p[s1],&p[s2]);
		if (t3 == 2)	{
			strcat(pt,"]");
			set_flg(off,1);
			off++;
		}
		s3 += sprintf(&p[s3],pt) + 1;
		st[stp++] = 4;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		pt[0] = 0;
		sp = s3;
	}
	else
	if (c>=0x40)	{	/* ���l */
		s1 = sp + sprintf(&p[sp],"%d",c - 0x40) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
	}
	else	{		/* ���l */
		num =(uint)c * 256 + *TOPP;
		s1 = sp + sprintf(&p[sp],"%d",num) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		set_flg(off,1);
		off++;
	}
	goto	loop;
}
int	chk_call_adr(uint adr,uint lib)
{	/* �֐��w��A�h���X���`�F�b�N���� */
	int	lp;
	for (lp=0;lp<func_count;lp++)	{
		if (func[lp].page == lib && func[lp].adr == adr)	return	lp+1;
	}
	return	0;
/*
	callp = (adr*64) & (MAXTBL-1);
	while (call_buf[callp])	{
		if ((call_buf[callp] == adr)
		&& (call_lib_buf[callp] == lib))	return	1;
		callp = (callp+1) & (MAXTBL-1);
	}
	return	0;
*/
}
void	set_call_adr(uint adr,uint lib)
{	/* �֐�call���̃A�h���X��ۑ����� */
	return;
/*
	if (chk_call_adr(adr,lib)==0)	{
		call_buf[callp] = adr;
		call_lib_buf[callp] = lib;
	}
*/
}
int	chk_loop_adr(uint adr)
{	/* �w��A�h���X�`�F�b�N���� */
	loopp = (adr*64) & (MAXTBL-1);
	while (loop_buf[loopp])	{	/* 0�Ȃ�Ȃ� */
		if ((loop_buf[loopp] == adr)
		&& (loop_lib_buf[loopp] == libcnt))	return	1;
		loopp = (loopp+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_loop_adr(uint adr)
{	/* loop���̃A�h���X��ۑ����� */
	if (chk_loop_adr(adr)==0)	{
		loop_buf[loopp] = adr;
		loop_lib_buf[loopp] = libcnt;
	}
}
int	chk_label_adr(uint adr)
{	/* �w��A�h���X�`�F�b�N���� */
	labelp = (adr*64) & (MAXTBL-1);
	while (label_buf[labelp])	{	/* 0�Ȃ�Ȃ� */
		if ((label_buf[labelp] == adr)
		&& (label_lib_buf[labelp] == libcnt))	return	1;
		labelp = (labelp+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_label_adr(uint adr)
{	/* label���̃A�h���X��ۑ����� */
	if (chk_label_adr(adr)==0)	{
		label_buf[labelp] = adr;
		label_lib_buf[labelp] = libcnt;
	}
}
int	chk_data_adr(uint adr)
{	/* �w��f�[�^�A�h���X�`�F�b�N���� */
	datap = (adr*64) & (MAXTBL-1);
	while (data_buf[datap])	{	/* 0�Ȃ�Ȃ� */
		if ((data_buf[datap] == adr)
		&& (data_lib_buf[datap] == libcnt))	return	1;
		datap = (datap+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_data_adr(uint adr)
{	/* data���̃A�h���X��ۑ����� */
	if (chk_data_adr(adr)==0)	{
		data_buf[datap] = adr;
		data_lib_buf[datap] = libcnt;
	}
}
void	set_adr(uint adr)
{	/* if���̕��J�b�R�̃A�h���X��ۑ����� */
	adr_buf[adrp++] = adr;
}
int	chk_adr(uint adr)
{	/* �w��A�h���X�ɕ��J�b�R�����K�v���`�F�b�N���� */
	int	lp,cnt;
	cnt = 0;
	for (lp=0;lp<adrp;lp++)	{
		if (adr_buf[lp] == adr)	cnt++;
	}
	return	cnt;
}
void	del_adr(uint adr)
{	/* �w��A�h���X���e�[�u������폜���� */
	int	lp;
	for (lp=0;lp<adrp;lp++)	{
		if (adr_buf[lp] == adr)	{
			adr_buf[lp] = adr_buf[--adrp];
			lp--;
		}
	}
}
void	put_dai(int type)
{	/* ������W�J */
	uchar	c;
	uint	woff,num;
	debug(" put_dai");
	varmin = varmax;
	woff = off;
	tab();
	sputs("!");
	set_flg(off,1);
	off++;
	if (*TOPP>=0xc0)	{
		num = (*TOPP - 0xc0)*256;
		set_flg(off,1);
		off++;
		if (num==0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			sputsc("%s[",vari[num = num + *TOPP].name);
			off++;
			if (put_rpo(woff)==0)	return;
			if (varmax < num)	varmax = num;
			sputs("]");
			goto	sk;
		}
		else	sputs(vari[num = num + *TOPP].name);
		if (varmax < num)	varmax = num;
	}
	else	{
		sputs(vari[num = (uint)*TOPP - 0x80].name);
		if (varmax < num)	varmax = num;
	}
	set_flg(off,1);
	off++;
sk:	if (type==0) sputs(":");
	else if (type==1) sputs("+:");
	else if (type==2) sputs("-:");
	else if (type==3) sputs("*:");
	else if (type==4) sputs("/:");
	else if (type==5) sputs("%%:");
	else if (type==6) sputs("&:");
	else if (type==7) sputs("|:");
	else if (type==8) sputs("^:");
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}
	sputs("!");
	dump16(buf,woff,off - woff);
	if (*TOPP == '<')
		set_loop_adr(woff);
}
void	put_dai2(void)
{
	uchar	c,s[512],*sw;
	uint	num,woff;
	debug(" put_dai2");
	varmin = varmax;
	woff = off;
	tab();
	sputs("<");
	if (pass)	tabcnt++;
	set_flg(off,1);
	off++;
	if (*TOPP>=0xc0)	{
		num = (*TOPP - 0xc0)*256;
		set_flg(off,1);
		off++;
		if (num==0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			sputsc("%s[",vari[num = num + *TOPP].name);
			off++;
			if (put_rpo(woff)==0)	return;
			if (varmax < num)	varmax = num;
			sputs("]:");
			goto	sk;
		}
		else	sputsc("%s,",vari[num = num + *TOPP].name);
		if (varmax < num)	varmax = num;
	}
	else	{
		sputsc("%s,",vari[num = (uint)*TOPP - 0x80].name);
		if (varmax < num)	varmax = num;
	}
	set_flg(off,1);
	off++;
sk:	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}
	sputs(",");
	set_flg(off,8);
	off += 8;
	sw = str;
	swait++;
	swait2=0;
	str = s;
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* �ϐ� */
	swait--;
	swait2=1;
	str = sw;
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 3 */
	sputs(",");
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_jyo(void)
{
	uchar	c;
	uint	adr,wk,woff;
	woff = off;
	debug(" put_jyo");
	tab();
	if (pass)	tabcnt++;
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)	return;
	sputs(":");
	adr = *TOPP;
	set_flg(off,4);
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	set_adr(adr);
	dump16(buf,woff,off - woff);
}
void	put_jyo2(void)
{
	uchar	c;
	uint	adr,woff;
	woff = off;
	debug(" put_jyo2");
	tab();
	if (pass)	tabcnt++;
	sputs("<@");
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)	return;
	sputs(":");
	set_flg(off,4);
	off++;
	off++;
	off++;
	off++;
	dump16(buf,woff,off - woff);
}
void	put_goto(void)
{	/* �W�����v���ߓW�J */
	uint	adr,wk,woff,c1;
	woff = off;
	c1 = *TOPP;
	debug(" put_goto");
	tab();
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr == 0)	{
		sputsi("%c0:",c1);
	}
	else	{
		/*
		if (pass==0)	{
			if (adr >= (uint)len)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			} 
		}
		else	if (adr >= (uint)len)	{
			dump_err(buf,woff,off - woff);
			usage("�W�����v�A�h���X�s��");
		}
		*/
		if (adr!=off || c1!=0x40) {
			set_label_adr(adr);
			sputsi("%c",c1);
			sputsi("L_%05x:",adr);
		}
	}
	dump16(buf,woff,off - woff);
}
void	put_label(void)
{	/* ���x���̓W�J */
	uint	adr,woff;
	woff = off;
	debug(" put_label");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (pass==0)	{
		if (adr >= (uint)len)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		} 
	}
	else	if (adr >= (uint)len)	{
		dump_err(buf,woff,off - woff);
		usage("���x���A�h���X�s��");
	}
	sputsi("D_%05x,",adr);
	if (put_rpo(woff)==0)	return;
	set_data_adr(adr);
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_call(void)
{	/* �֐��R�[���� */
	uint	adr,wk,lib,libwk,lenwk,woff,cnt;
	uchar	*bufwk,*fbufwk,*s;
	woff = off;
	debug(" put_call");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,3);
	off++;
	lib = *TOPP;
	off++;
	lib += *TOPP*256;
	off++;
	if (lib == 0xffff)	{
		sputs("~");
		if (put_rpo(woff)==0)	return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	if (lib == 0)	{
		sputs("0,");
		if (put_rpo(woff)==0)	return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	adr = *TOPP;
	set_flg(off,4);
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr == 0)	{
		sputs("0:");
		dump16(buf,woff,off - woff);
		return;
	}
	else	{
		if (pass==0 && 0)	{	/* ��ѐ�m�F���� */
			libwk = libcnt;
			wk = off;
			bufwk = buf;
			fbufwk = fbuf;
			lenwk = len;
			if (libcnt != lib)	{
				libcnt = lib;
				if (get_block()==0)	{
					libcnt = libwk;
					buf = bufwk;
					fbuf = fbufwk;
					len = lenwk;
					off = wk;
					reset_flg(woff,off - woff);
					off = len;
					return;	/* �u���b�N�Ȃ� */
				}
			}
			off = adr;
			if ((uint)off >= (uint)len)	{
				libcnt = libwk;
				buf = bufwk;
				fbuf = fbufwk;
				len = lenwk;
				off = wk;
				reset_flg(woff,off - woff);
				off = len;
				return;	/* ��ѐ�Ȃ� */
			}
			off = wk;
			libcnt = libwk;
			buf = bufwk;
			fbuf = fbufwk;
			len = lenwk;
		}
		if (cnt = chk_call_adr(adr,lib))	{/*fix*/
			sputsc("%s:",func[cnt-1].name);
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�Ȃ�");
		}
/*
		set_call_adr(adr,lib);
		sputsi("F_%05x_",adr);
		s = get_adv_name(lib-1);
		if (s != 0)	sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
*/
	}
	dump16(buf,woff,off - woff);
}
void	put_sen(void)
{	/* �I�����\�� */
	uint	adr,wk,woff;
	if (sen_mode)	{
		sen_mode = 0;
		set_flg(off,1);
		off++;
		sputs("$");
		return;
	}
	woff = off;
	debug(" put_sen");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
/*	printf("sen adr = %08x\n",adr);	*/
	if (pass==0)	{
		if (adr >= (uint)len)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		} 
	}
	else	if (adr >= (uint)len)	{
		dump_err(buf,woff,off - woff);
		usage("�I�����A�h���X�s��");
	}
	set_label_adr(adr);
	sputsi("L_%05x$",adr);
	dump16(buf,woff,off - woff);
	sen_mode = 1;
}
void	put_b(void)
{	/* B�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_b");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%d,",c);
	switch(c)	{
	case	1:
	case	2:
	case	3:
	case	4:
		if (put_rpo(woff)==0)	return;
		sputs(",");
		if (put_rpo(woff)==0)	return;
		sputs(",");
		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	21:
	case	22:
	case	23:
	case	24:
	case	31:
	case	32:
	case	33:
	case	34:

		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	10:
	case	11:
		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	0:
	case	12:
	case	13:
	case	14:
		if (put_rpo(woff)==0)	return;
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_c(void)
{	/* C�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_c");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'K':
		if (*TOPP>=4 || *TOPP == 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'D':
		if (put_rpo(woff)==0)	return;	/* 10 */
		sputs(",");
	case	'E':
	case	'M':
		if (put_rpo(woff)==0)	return;	/* 9 */
		sputs(",");
	case	'K':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
	case	'S':
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
	case	'C':
	case	'U':
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
	case	'B':
	case	'F':
	case	'L':
	case	'Y':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'P':
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_d(void)
{	/* D�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_d");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'C':
	case	'F':
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_e(void)
{	/* E�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_e");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
	case	'G':
	case	'N':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
	case	'M':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_f(void)
{	/* F�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_f");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c>=12 || c==0)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
	}
	sputsi("%d ",c);
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_g(void)
{	/* G�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_g");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c >= 0x40)	sputsi("%c ",c);
	else	sputs(" ");
	switch(c)	{
	case	'X':
	case	'S':
	case	1:
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	0:
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_h(void)
{	/* H�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_h");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi(" %d,",c);
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_i(void)
{	/* I�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_i");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'K':
		if (*TOPP >= 7)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'G':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
	case	'E':
	case	'M':
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'X':
	case	'Y':
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	'K':
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_j(void)
{	/* J�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff= off;
	debug(" put_j");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c < 0x40)	sputsi("%d",c);
	if (c>=5)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
	}
	switch(c)	{
	case	0:
	case	1:
	case	2:
	case	3:
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	4:
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_k(void)
{	/* K�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_k");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'Q':
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'K':
	case	'N':
	case	'P':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_l(void)
{	/* L�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_l");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if ((c == 'H')|| (c == 'X'))
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'L':
		if (*TOPP != 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'E':
		if (*TOPP > 1)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = woff;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				return;
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'H':
		sputsi("%c ",*TOPP);
		set_flg(off,1);
		off++;
		if (*TOPP > 3 || *TOPP == 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'X':
		c = *TOPP;
		sputsi("%c ",c);
		set_flg(off,1);
		off++;
		switch (c)	{
		case	'G':
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			put_str();	/* 2 */
			sputs(",");
			put_str();	/* 1 */
			sputs(":");
			break;
		case	'O':
		case	'L':
		case	'S':
		case	'P':
		case	'R':
		case	'W':
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		case	'C':
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'E':
		put_str();	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	'L':	
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'D':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_m(void)
{	/* M�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_m");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'G':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'N':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'T':
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'E':
	case	'J':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
	case	'F':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'D':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'A':
	case	'C':
	case	'L':
	case	'M':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_n(void)
{	/* N�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_n");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c == 'D')
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'D':
		sputsi("%c ",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch(c)	{
		case	'+':
		case	'-':
		case	'*':
		case	'/':
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	'A':
		case	'H':
		case	'C':
		case	'D':
		case	'M':
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	case	'O':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'T':
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'I':
	case	'<':
	case	'>':
	case	'=':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'B':
	case	'+':
	case	'-':
	case	'*':
	case	'/':
	case	'&':
	case	'|':
	case	'^':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
	case	'R':
	case	'\\':
	case	'~':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_p(void)
{	/* P�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_p");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'F':
	case	'W':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	2:
		case	3:
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	0:
		case	1:
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	case	'T':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	1:
			if (put_rpo(woff)==0)   return;	/* 5 */
			sputs(",");
		case	2:
			if (put_rpo(woff)==0)   return;	/* 4 */
			sputs(",");
		case	0:
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'G':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'D':
	case	'N':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_q(void)
{	/* Q�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_q");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'E':
		if (*TOPP > 1)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = woff;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				off = woff;
				return;
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		put_str();	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'D':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_s(void)
{	/* S�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_s");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'I':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'R':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'G':
		sputsi("%d,",*TOPP);
		if (*TOPP>4) {
			set_flg(off,1);
			off++;
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		} else {
			set_flg(off,1);
			off++;
		}
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'X':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		sputsi("%d",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	1:
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
		case	2:
		case	4:
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
		case	3:
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'Q':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'U':
	case	'P':
/*	case	'R':*/
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'L':
	case	'M':
	case	'O':
	case	'S':
	case	'T':
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
}
void	put_tx(void)
{	/* T&X�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_tx");
	tab();
	sputsi("%c ",c = *TOPP);
	set_flg(off,1);
	off++;
	switch (c)	{
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
	}
	dump16(buf,woff,off - woff);
}
void	put_u(void)
{	/* U�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_u");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'C':
	case	'P':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'P':
		put_str();	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'S':
	case	'G':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'D':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_v(void)
{	/* V�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_v");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if ((c == 'I')||(c == 'F'))
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'I':
		sputsi("%c ",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'A':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 10 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 9 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
	case	'B':
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
	case	'E':
	case	'P':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
	case	'G':
	case	'J':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'W':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	'F':
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_w(void)
{	/* W�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_w");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'V':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_z(void)
{	/* Z�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_z");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'A':
	case	'D':
		sputsi("%d,",c = *TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		return;
	case	'K':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		return;
	case	'Z':
		sputsi("%d,",c = *TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		return;
	case	'T':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	10:
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
		case	11:
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	0:
		case	1:
		case	2:
		case	3:
		case	4:
		case	5:
		case	20:
		case	21:
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				return;
			}
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'C':
	case	'I':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'A':
	case	'B':
	case	'D':
	case	'E':
	case	'F':
	case	'G':
	case	'H':
	case	'L':
	case	'M':
	case	'S':
	case	'W':
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
			return;
		}
	}	
	dump16(buf,woff,off - woff);
}
void	put_y(void)
{	/* Y�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_y");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_38com(void)
{	/* system39�ǉ����ߓW�J */
	int	hel_file;	/* hel�t�@�C���ԍ� */
	int hel_dfunc;	/* �֐��ԍ� */
	int	prmcnt;		/* hel �p�����[�^�� */
	int	lp;
	int	cnt;
	uint	wk,libwk,lenwk;
	uchar	*bufwk,*fbufwk;

	uint	woff, adr,lib;
	uchar	c, *s;
	woff = off;
	debug(" put_38com");
	tab();
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	switch(c)	{
	case	0x00:
		sputs("TOC:");
		break;
	case	0x01:
		sputs("TOS:");
		break;
	case	0x02:
		sputs("TPC ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x03:
		sputs("TPS ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x04:
		sputs("TOP:");
		break;
	case	0x05:
		sputs("TPP:");
		break;
	case	0x06:
		sputs("inc ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x07:
		sputs("dec ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x08:
		sputs("TAA ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x09:
		sputs("TAB ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0a:
		sputs("wavLoad ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0b:
		sputs("wavPlay ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0c:
		sputs("wavStop ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0d:
		sputs("wavUnload ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0e:
		sputs("wavIsPlay ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x0f:
		sputs("wavFade ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x10:
		sputs("wavIsFade ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x11:
		sputs("wavStopFade ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x12:
		sputs("trace \"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x13:
		sputs("wav3DSetPos ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x14:
		sputs("wav3DCommit:");
		break;
	case	0x15:
		sputs("wav3DGetPos ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x16:
		sputs("wav3DSetPosL ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x17:
		sputs("wav3DGetPosL ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x18:
		sputs("wav3DFadePos ");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x19:
		sputs("wav3DIsFadePos ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x1a:
		sputs("wav3DStopFadePos ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x1b:
		sputs("wav3DFadePosL ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x1c:
		sputs("wav3DIsFadePosL ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x1d:
		sputs("wav3DStopFadePosL:");
		break;
	case	0x1e:
		sputs("sndPlay ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x1f:
		sputs("sndStop:");
		break;
	case	0x20:
		sputs("sndIsPlay ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x21:
		sputs("'");
		put_strz();						/* 1 */
		sputs("'");
		break;
	case	0x22:
		sputs("HH ");
		sputsi("%d,",*TOPP);			/* 2 */
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x23:
		sputs("LC ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x24:
		sputs("LE ");
		sputsi("%d,\"",*TOPP);			/* 4 */
		set_flg(off,1);
		off++;
		put_strz();						/* 3 */
		sputs("\",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x25:
		sputs("LXG ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",\"");
		put_strz();						/* 2 */
		sputs("\",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x26:
		sputs("MI ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x27:
		sputs("MS ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x28:
		sputs("MT \"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x29:
		sputs("NT \"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x2a:
		sputs("QE ");
		sputsi("%d,\"",*TOPP);			/* 4 */
		set_flg(off,1);
		off++;
		put_strz();						/* 3 */
		sputs("\",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x2b:
		sputs("UP ");
		sputsi("%d,\"",*TOPP);			/* 3 */
		set_flg(off,1);
		off++;
		put_strz();						/* 2 */
		sputs("\",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x2c:
		sputs("F");
		sputsi("%d,",*TOPP);			/* 3 */
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x2d:
		sputs("wavWaitTime ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x2e:
		sputs("wavGetPlayPos ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x2f:
		sputs("wavWaitEnd ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x30:
		sputs("wavGetWaveTime ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x31:
		lib = *TOPP;
		off++;
		lib += *TOPP*256;
		off++;
		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;

		if (cnt = chk_call_adr(adr,lib))	{
			sputsc("menuSetCbkSelect %s:",func[cnt-1].name);
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}

/*		set_call_adr(adr,lib);
		sputsi("menuSetCbkSelect F_%05x_",adr);
		s = get_adv_name(lib-1);
		if (s != 0)
			sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
*/
		break;
	case	0x32:
		lib = *TOPP;
		off++;
		lib += *TOPP*256;
		off++;
		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;

		if (cnt = chk_call_adr(adr,lib))	{
			sputsc("menuSetCbkCancel %s:",func[cnt-1].name);
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
/*
		set_call_adr(adr,lib);
		sputsi("menuSetCbkCancel F_%05x_",adr);
		s = get_adv_name(lib-1);
		if (s != 0)
			sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
*/
		break;
	case	0x33:
		sputs("menuClearCbkSelect:");
		break;
	case	0x34:
		sputs("menuClearCbkCancel:");
		break;
	case	0x35:
		sputs("wav3DSetMode ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x36:
		sputs("grCopyStretch ");
		if (put_rpo(woff)==0)   return;	/* 9 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x37:
		sputs("grFilterRect ");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x38:
		sputs("iptClearWheelCount:");
		break;
	case	0x39:
		sputs("iptGetWheelCount ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x3a:
		sputs("menuGetFontSize ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x3b:
		sputs("msgGetFontSize ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x3c:
		sputs("strGetCharType ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x3d:
		sputs("strGetLengthASCII ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x3e:
		sputs("sysWinMsgLock:");
		break;
	case	0x3f:
		sputs("sysWinMsgUnlock:");
		break;
	case	0x40:
		sputs("aryCmpCount ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x41:
		sputs("aryCmpTrans ");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x42:
		sputs("grBlendColorRect ");
		if (put_rpo(woff)==0)   return;	/* 9 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x43:
		sputs("grDrawFillCircle ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x44:
		sputs("MHH ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x45:
		lib = *TOPP;
		off++;
		lib += *TOPP*256;
		off++;
		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;

		if (cnt = chk_call_adr(adr,lib))	{
			sputsc("menuSetCbkInit %s:",func[cnt-1].name);
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
/*
		set_call_adr(adr,lib);
		sputsi("menuSetCbkInit F_%05x_",adr);
		s = get_adv_name(lib-1);
		if (s != 0)
			sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
*/
		break;
	case	0x46:
		sputs("menuClearCbkInit:");
		break;
	case	0x47:
		sputs("]");
		set_flg(off,1);
		off++;
		break;
	case	0x48:
		sputs("sysOpenShell \"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x49:
		sputs("sysAddWebMenu \"");
		put_strz();						/* 2 */
		sputs("\",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x4a:
		sputs("iptSetMoveCursorTime ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x4b:
		sputs("iptGetMoveCursorTime ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x4c:
		sputs("grBlt ");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x4d:
		sputs("LXWT ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x4e:
		sputs("LXWS ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x4f:
		sputs("LXWE ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x50:
		sputs("LXWH ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x51:
		sputs("LXWHH ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		sputsi("%d,",*TOPP);			/* 2 */
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x52:
		sputs("sysGetOSName ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x53:
		sputs("patchEC ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x54:
		sputs("mathSetClipWindow ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x55:
		sputs("mathClip ");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x56:
		sputs("LXF ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",\"");
		put_strz();						/* 2 */
		sputs("\",\"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x57:
		sputs("strInputDlg ");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",\"");
		put_strz();						/* 4 */
		sputs("\",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x58:
		sputs("strCheckASCII ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x59:
		sputs("strCheckSJIS ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x5a:
		sputs("strMessageBox \"");
		put_strz();						/* 1 */
		sputs("\":");
		break;
	case	0x5b:
		sputs("strMessageBoxStr ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x5c:
		sputs("grCopyUseAMapUseA ");
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x5d:
		sputs("grSetCEParam ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x5e:
		sputs("grEffectMoveView ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x5f:
		sputs("cgSetCacheSize ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x60:	/* dll */
		hel_file = *TOPP;			/* hel�t�@�C���ԍ��𓾂� */
		set_flg(off,4);
		off++;
		hel_file += *TOPP*256;
		off++;
		hel_file += *TOPP*256*256;
		off++;
		hel_file += *TOPP*256*256*256;
		off++;

		hel_dfunc = *TOPP;			/* �֐��ԍ��𓾂� */
		set_flg(off,4);
		off++;
		hel_dfunc += *TOPP*256;
		off++;
		hel_dfunc += *TOPP*256*256;
		off++;
		hel_dfunc += *TOPP*256*256*256;
		off++;
		sputsc("%s.",hel[hel_file].name);	/* hel�t�@�C����. */
		sputsc("%s ",hel[hel_file].dfunc[hel_dfunc].name);	/* �֐��� */
		prmcnt = hel[hel_file].dfunc[hel_dfunc].cnt;	/* �֐��p�����[�^�� */ 
		for (lp=0;lp<prmcnt;lp++)	{
			switch (hel[hel_file].dfunc[hel_dfunc].para[lp])	{
			/* �����W�J */
			case 0: /* pword */
			case 1: /* int   */
			case 3: /* IString */
				if (put_rpo(woff)==0)	return;
				break;
			/* �W�J�Ȃ� */
			case 2: /* ISurface */
			case 4: /* IWinMsg */
			case 5: /* ITimer */
			case 6: /* IUI    */
			case 7: /* ISys3xDIB */
			case 9: /* ISys3xCG */
			case 10: /* ISys3xStringTable */
			case 13: /* ISys3xSystem */
			case 14: /* ISys3xMusic */
			case 15: /* ISys3xMsgString */
			case 16: /* ISys3xInputDevice */
			case 17: /* ISys3x */
				set_flg(off,2);
				off += 2;
				break;

			case 18: /* IConstString */
				put_strz();
				break;
			}
			if (lp+1 < prmcnt)		sputs(",");
		}
		sputs(":");
		break;
	case	0x61:
		sputs("gaijiSet ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x62:
		sputs("gaijiClearAll:");
		break;
	case	0x63:
		sputs("menuGetLatestSelect ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x64:
		sputs("lnkIsLink ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x65:
		sputs("lnkIsData ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x66:
		sputs("fncSetTable ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		set_flg(off,2);
		lib = *TOPP;
		off++;
		lib += *TOPP*256;
		off++;

		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		if (pass==0 && 0)	{	/* ��ѐ�m�F���� */
			libwk = libcnt;
			wk = off;
			bufwk = buf;
			fbufwk = fbuf;
			lenwk = len;
			if (libcnt != lib)	{
				libcnt = lib;
				if (get_block()==0)	{
					libcnt = libwk;
					buf = bufwk;
					fbuf = fbufwk;
					len = lenwk;
					off = wk;
					reset_flg(woff,off - woff);
					off = len;
					return;	/* �u���b�N�Ȃ� */
				}
			}
			off = adr;
			if ((uint)off >= (uint)len)	{
				libcnt = libwk;
				buf = bufwk;
				fbuf = fbufwk;
				len = lenwk;
				off = wk;
				reset_flg(woff,off - woff);
				off = len;
				return;	/* ��ѐ�Ȃ� */
			}
			off = wk;
			libcnt = libwk;
			buf = bufwk;
			fbuf = fbufwk;
			len = lenwk;
		}
		if (cnt = chk_call_adr(adr,lib))	{
			sputsc("%s:",func[cnt-1].name);
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
/*
		set_call_adr(adr,lib);
		sputsi("F_%05x_",adr);
		s = get_adv_name(lib-1);
		if (s != 0)	sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
*/
		break;
	case	0x67:
		sputs("fncSetTableFromStr ");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x68:
		sputs("fncClearTable ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x69:
		sputs("fncCall ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6a:
		sputs("fncSetReturnCode ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6b:
		sputs("fncGetReturnCode ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6c:
		sputs("msgSetOutputFlag ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6d:
		sputs("saveDeleteFile ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6e:
		sputs("wav3DSetUseFlag ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x6f:
		sputs("wavFadeVolume ");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x70:
		sputs("patchEMEN ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x71:
		sputs("wmenuEnableMsgSkip ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x72:
		sputs("winGetFlipFlag ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x73:
		sputs("cdGetMaxTrack ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x74:
		sputs("dlgErrorOkCancel ");
		put_strz();	/* 1 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x75:
		sputs("menuReduce ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x76:
		sputs("menuGetNumof ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x77:
		sputs("menuGetText ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x78:
		sputs("menuGoto ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x79:
		sputs("menuReturnGoto ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x7a:
		sputs("menuFreeShelterDIB:");
		break;
	case	0x7b:
		sputs("msgFreeShelterDIB:");
		break;
	case	0x7c:
		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		sputsc("'%s'",msgi[adr].name);
		break;
	case	0x7d:
		set_flg(off,5);
		adr = *TOPP;
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		adr = *TOPP;
		off++;
		sputsi("H %d,",adr);
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x7e:
		set_flg(off,5);
		adr = *TOPP;
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		adr = *TOPP;
		off++;
		sputsi("HH %d,",adr);
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	0x7f:
		adr = *TOPP;
		set_flg(off,4);
		off++;
		adr += *TOPP*256;
		off++;
		adr += *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		sputs("X ");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}
	dump16(buf,woff,off - woff);
}
void	copy_adv_name(uchar *dp,uchar *sp)
{	/* ADV�t�@�C�������쐬����(���x���p) */
	int	cnt;
	cnt = 0;
	while (*sp  != 0)	{
		if ((sp[0] == '.') && (toupper(sp[1]) == 'A')
		&& (toupper(sp[2]) == 'D') && (toupper(sp[3]) == 'V'))	{
			strcpy(dp,"_ADV");
			return;
		}
		*dp++ = *sp++;
		cnt++;
		if (cnt >= 128)	usage("�\�[�X�t�@�C�������擾�ł��Ȃ�");
	}
}
void	copy_adv_name_f(uchar *dp,uchar *sp)
{	/* ADV�t�@�C�������쐬����(�t�@�C���p) */
	int	cnt;
	cnt = 0;
	while (*sp  != 0)	{
		if ((sp[0] == '.') && (toupper(sp[1]) == 'A')
		&& (toupper(sp[2]) == 'D') && (toupper(sp[3]) == 'V'))	{
			strcpy(dp,".ADV");
			return;
		}
		*dp++ = *sp++;
		cnt++;
		if (cnt >= 128)	usage("�\�[�X�t�@�C�������擾�ł��Ȃ�");
	}
}
uchar	*get_adv_name(uint num)
{	/* ALD�t�@�C������NUM�Ԗڂ�ADV�t�@�C�����𓾂�(���x���p) */
	uint	start,ap,mp,page;
	debug(" get_adv_name");
	
	sprintf(advname, "_page%03d_adv", num+1);
	
	mp = ald_buf[0];
	mp += ald_buf[1]*256;
	mp += ald_buf[2]*256*256;
	mp = mp*256;			/* ײ���ؔԍ�ð��قւ̵̾�Ă𓾂� */
	if (num * 3 >= mp)	return	advname;	/* �e�[�u���O */
	
	if (ald_buf[mp+num*3]!=0x01) {
		return	advname;
	}
	
	page = ald_buf[mp+num*3+1];
	page += ald_buf[mp+num*3+2]*256;
	
retry:	ap = ald_buf[page*3];
	ap += ald_buf[page*3+1]*256;
	ap += ald_buf[page*3+2]*256*256;
	ap = ap*256;			/* ײ����ͯ�ނւ̵̾�Ă𓾂� */
	if (ap == 0)	return	advname;
	start = ald_buf[ap];
	start += ald_buf[ap+1]*256;
	start += ald_buf[ap+2]*256*256;
	start += ald_buf[ap+3]*256*256*256;
	if (start > 0x30)	return	advname;
	copy_adv_name(advname,ald_buf+ap+start+18);
	return	advname;
}
uchar	*get_adv_name_f(uint num)
{	/* ALD�t�@�C������NUM�Ԗڂ�ADV�t�@�C�����𓾂�(�t�@�C���p) */
	uint	start,ap,mp,page;
	debug(" get_adv_name");
	
	sprintf(advname, "_page%03d_adv", num+1);
	
	mp = ald_buf[0];
	mp += ald_buf[1]*256;
	mp += ald_buf[2]*256*256;
	mp = mp*256;			/* ײ���ؔԍ�ð��قւ̵̾�Ă𓾂� */
	if (num * 3 >= mp)	return	advname;	/* �e�[�u���O */
	
	if (ald_buf[mp+num*3]!=0x01) {
		return	advname;
	}
	
	page = ald_buf[mp+num*3+1];
	page += ald_buf[mp+num*3+2]*256;
	
retry:	ap = ald_buf[page*3];
	ap += ald_buf[page*3+1]*256;
	ap += ald_buf[page*3+2]*256*256;
	ap = ap*256;			/* ײ����ͯ�ނւ̵̾�Ă𓾂� */
	if (ap == 0)	return	advname;
	start = ald_buf[ap];
	start += ald_buf[ap+1]*256;
	start += ald_buf[ap+2]*256*256;
	start += ald_buf[ap+3]*256*256*256;
	if (start > 0x30)	return	advname;
	copy_adv_name_f(advname,ald_buf+ap+start+18);
	return	advname;
}
void	put_advjp(void)
{	/* �y�[�W�R�[���y�[�W�W�����v�n���߂̓W�J */
	uchar	*s;
	uint	c;
	uint	num;
	uint	woff;
	uint	wk,libwk,lenwk;
	uchar	*bufwk,*fbufwk;
	woff = off;
	debug(" put_advjp");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	c = *TOPP;
	if (c>=0x80)	{
		if (put_rpo(woff)==0)   return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}	
	if (c>=0x40)	{
		num = c - 0x40;
	}	
	else	{
		set_flg(off,1);
		off++;
		num = c * 256 + *TOPP;
	}
	if (num == 0)	{
		sputs("0");
	}
	else	{
		s = get_adv_name_f(num);
		if (s == 0)	sputsi("%d",num);
		else		sputsc("#%s",s);
	}
	set_flg(off,1);
	off++;
	set_flg(off,1);
	off++;
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_loop(void)
{	/* LOOP���ߓW�J */
	uchar	c,s[256],*sw;
	uint	num;
	uint	woff;
	woff = off;
	debug(" put_loop");
	if (pass)	tabcnt++;
	set_flg(off,8);
	off +=8;
	sw = str;
	swait++;
	swait2=0;
	str = s;
	if (put_rpo(woff)==0)   return;	/* �ϐ� */
	swait--;
	swait2=1;
	str = sw;
	if (put_rpo(woff)==0)   return;	/* 3 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_loop_end(void)
{	/* LOOP END���ߓW�J */
	uchar	c;
	uint	adr,wk;
	uint	woff;
	woff = off;
	debugi("\nput_loop_end off = %x",off);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr >= (uint)len)	{
		reset_flg(woff,off - woff);
		off = len;
		if (pass == 0)	return;
		dump_err(buf,woff,off - woff);
		usage("���[�v�G���h���������ȃA�h���X�������Ă���");
		return;
	}
	set_loop_adr(adr);
	if (pass)	tabcnt--;
	tab();
	sputs(">");
	dump16(buf,woff,off - woff);
}
int	data_fld_kanji(int f)
{	/* �����f�[�^���`�F�b�N���W�J���� */
	uint	c,wk,cnt,lp;
	uchar	*kana;
/*	debug(" data_fld_kanji");	*/
	cnt = 0;
	wk = off;
loop:	if (kanji_chk(*TOPP) && fbuf[off] == 0)	{
		off++;
		if (kanji_chk2(*TOPP) && fbuf[off] == 0) {
			cnt+=2;	/* �Q�o�C�g�R�[�h */
			off++;
			goto	loop;
		}
		else	{	/* �Q�o�C�g�ڂ��s�� */
			off = wk;
			return	0;
		}
	}
	else
	if (kana_chk(*TOPP) && fbuf[off] == 0)	{
		cnt++;	/* �P�o�C�g�J�i�R�[�h */
		off++;
		goto	loop;
	}
	if (*TOPP != 0 || fbuf[off] != 0 || off >= len)	{
		off = wk;
		return	0;
	}
	off = wk;
	if (f==0)	return	cnt;

	if (cnt)	{
		sputs("\n");
		tab();
		sputs("\"");
		for (lp=0;lp<cnt;lp++)	{
			if (f)	{
				if (kanji_chk(*TOPP))	{
					sputsi("%c",*TOPP);
					off++;
					lp++;
					sputsi("%c",*TOPP);
				}
				else
				if (kana_chk(*TOPP))	{
					kana = kana_zen(*TOPP);
					sputsi("%c",*kana);
					sputsi("%c",*(kana+1));
				}
				else	sputsi("%c",*TOPP);
			}
			off++;
		}
		off++;
		sputs("\"");
		dump16(buf,wk,off-wk);
	}
	return	cnt;
}
int	data_fld_kanjip(int f)
{	/* �����\���R�}���h��W�J���� */
	uint	c,wk,cnt,lp,lp2,cnt2;
	uint	woff,ioff;
	uchar	*kana;
/*	debugi("\ndata_fld_kanjip f = %d",f);	*/
	cnt = 0;
	wk = off;
	kanji_flg = 0;
loop:	if (kanji_chk(*TOPP))	{
		off++;
		if (kanji_chk2(*TOPP)) {
			cnt+=2;	/* �Q�o�C�g�R�[�h */
			off++;
			goto	loop;
		}
		else	{	/* �Q�o�C�g�ڂ��s�� */
			off = wk;
			return	0;
		}
	}
	else
	if (kana_chk(*TOPP))	{
		cnt++;	/* �P�o�C�g�J�i�R�[�h */
		off++;
		goto	loop;
	}
	if (*TOPP == 0 && off < len)	{
		off = wk;
		return	0;
	}
	if (cnt && pass==1 && fbuf[off]==0)	{
		memset(fbuf+wk,0,off - wk);
		off = wk;
		kanji_flg = wk;
		return	0;
	}
	off = wk;
	if (f==0)	return	cnt;
	if (cnt)	{
		woff = off;
		tab();
		sputs("'");
		for (lp=0;lp<cnt;lp++)	{
			if ((cnt2 = chk_adr(off))!=0)	{
				sputs("'");
				dump16(buf,woff,off-woff);
				sputs("\n");
				for (lp2=0;lp2<cnt2;lp2++)	{
					if (pass)	tabcnt--;
					tab();
					sputs("}\n");
				}
				del_adr(off);
				tab();
				sputs("'");
				woff = off;
			}	
			if (kanji_chk(*TOPP))	{
				sputsi("%c",*TOPP);
				set_flg(off,1);
				off++;
				lp++;
				sputsi("%c",*TOPP);
			}
			else
			if (kana_chk(*TOPP))	{
				kana = kana_zen(*TOPP);
				sputsi("%c",*kana);
				sputsi("%c",*(kana+1));
			}
			else	sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
		}
		sputs("'");
		dump16(buf,woff,off-woff);
	}
	return	cnt;
}
void	data_fld(void)
{	/* �f�[�^�t�B�[���h��W�J���� */
	uint	c,f,cnt,wk,lp,adr,adrf;
	int	woff;
	debug(" data_fld");
	woff = off;
	f = 0;
	cnt = 0;	
	adrf = 0;
	do	{
		if (off >= len)	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		if (chk_data_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			sputsi("\n*D_%05x:\n",off);
			adrf = 1;
			f = 0;
			cnt = 0;
		}
		else
		if (chk_label_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			sputsi("\n*L_%05x:\n",off);
			adrf = 0;
			f = 0;
			cnt = 0;
		}
		if (fbuf[off]==1)	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off-woff);
			}
			return;
		}
		c = *TOPP;
		off++;
		if (chk_data_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		else
		if (chk_label_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		c += *TOPP*256;
		off++;
		adr = c + *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		if (adr >= (uint)offtop && adr<(uint)len)	{
			if ((adrf == 1) && (fbuf[adr] == 0))	{
				if (cnt != 0)	{
					sputs("]");
					dump16(buf,woff,off - woff);
				}
				cnt = 0;
				f = 0;
				tab();
				sputsi("_D_%05x:\n",adr);
				set_data_adr(adr);
				dump16(buf,off-4,4);
				continue;
			}
		}
		else	{
			off -= 4;
			if (data_fld_kanji(0)>=2)	{	/* ������`�F�b�N */
				if (cnt>0)	{
					sputs("]");
					dump16(buf,woff,off-woff);
				}
				data_fld_kanji(1);	/* �����񏑂����� */
				cnt = 0;
				f = 0;
				adrf = 0;
				continue;
			}
			off += 4;
		}
		adrf = 0;
		off -=2;
		if (cnt == 0)	{
			sputs("\n");
			tab();
			sputs("[");
			woff = off - 2;
		}
		if (f)	sputs(",");
		else	f = 1;
		sputsi("%d",c);
		cnt++;
		if (cnt >= 8)	{
			sputs("]");
			dump16(buf,woff,off - woff);
			f = 0;
			cnt = 0;
		}
	}	while (fbuf[off] == 0);
	if (cnt>0)	{
		sputs("]\n");
		dump16(buf,woff,off - woff);
	}
}
int	chk_dump(void)
{	/* ��ѐ���v���O�����G���A�Ƃ݂Ȃ��`�F�b�N���� */
	int	woff;
	woff = off;
	if (chk_label_adr(off))	{
		dump();
		if (fbuf[woff]==0)	{
			printf("\nlabel error pre = %d",pre);
			dump_err(buf,woff,32);
		}
		off = woff;
		return	1;
	}
	if (chk_call_adr(off,libcnt))	{/*fix*/
		dump();
		if (fbuf[woff]==0)	{
			printf("\ncall error pre = %d",pre);
			dump_err(buf,woff,32);
		}
		off = woff;
		return	1;
	}
	return	0;
}
void	data_fld_adr_set(void) {
	debug(" data_fld_adr_set");

top:	while (fbuf[off]==1 && off <len)	off++;
	if (off >= len)	return;
	/*if (chk_dump())	return;*/
	if (chk_dump())	goto	top;
	off++;
	if (off >= len)	return;
	goto	top;
}
void	chk_adr_all(void)
{	/* �e��A�h���X���`�F�b�N�B�K�v�Ȃ烉�x�����̑��𐶐����� */
	uchar	*s;
	int	lp,cnt;
	if ((cnt = chk_adr(off))!=0)	{
		for (lp=0;lp<cnt;lp++)	{
			if (pass)	tabcnt--;
			tab();
			sputs("}");
			if (sen_mode==0)	sputs("\n");
		}
		del_adr(off);
	}	
	if (cnt = chk_call_adr(off,libcnt))	{/*fix*/
		sputsc("\n**%s:\n",func[cnt-1].name);
	}
	if (chk_label_adr(off))	{
		sputsi("\n*L_%05x:\n",off);
	}
	if (chk_data_adr(off))	{
		sputsi("\n*D_%05x:\n",off);
	}
}
void	dump_sub(void)
{	/* �t�R���p�C���@���ߒP�ʂ̓W�J */
	uint	lp,c,cnt,woff,ioff,cbak;
	int	pf,dp;
	uchar	*s;
	if (sen_mode==0)	sputs("\n");
	if (pass)	{ 
		if (fbuf[off] == 0)	{
			ioff = off;
			data_fld();
			if (off >= len)	return;
			if ((uint)off != ioff)	return;
		}
	}
	else	{
		if (fbuf[off] == 1)	{
			off =len;
			return;
		} 
	}
	ioff = off;
	c = *TOPP;
	if (data_fld_kanjip(0))	{	/* ������`�F�b�N */
		chk_adr_all();
		data_fld_kanjip(1);	/* �����񏑂����� */
		return;
	}
	if (kanji_flg)	{
		if (fbuf[off] == 0)	{
			data_fld();
		}
		return;
	}
	chk_adr_all();
	switch (c)	{
	case	']':
	case	'A':
	case	'R':
		put_1();
		break;
	case	'B':
		put_b();
		break;
	case	'C':
		put_c();
		break;
	case	'D':
		put_d();
		break;
	case	'E':
		put_e();
		break;
	case	'F':
		put_f();
		break;
	case	'G':
		put_g();
		break;
	case	'H':
		put_h();
		break;
	case	'I':
		put_i();
		break;
	case	'J':
		put_j();
		break;
	case	'K':
		put_k();
		break;
	case	'L':
		put_l();
		break;
	case	'M':
		put_m();
		break;
	case	'N':
		put_n();
		break;
	case	'P':
		put_p();
		break;
	case	'Q':
		put_q();
		break;
	case	'S':
		put_s();
		break;
	case	'T':
	case	'X':
		put_tx();
		break;
	case	'U':
		put_u();
		break;
	case	'V':
		put_v();
		break;
	case	'W':
		put_w();
		break;
	case	'Y':
		put_y();
		break;
	case	'Z':
		put_z();
		break;
	case	'!':
		if (chk_loop_adr(off))	{
			put_dai2();
		}
		else	put_dai(0);
		break;
	case	0x10:
		put_dai(1);
		break;
	case	0x11:
		put_dai(2);
		break;
	case	0x12:
		put_dai(3);
		break;
	case	0x13:
		put_dai(4);
		break;
	case	0x14:
		put_dai(5);
		break;
	case	0x15:
		put_dai(6);
		break;
	case	0x16:
		put_dai(7);
		break;
	case	0x17:
		put_dai(8);
		break;
	case	'{':
		if (chk_loop_adr(off))	{
			put_jyo2();
		}
		else	put_jyo();
		break;
	case	'$':
		put_sen();
		break;
	case	'@':
	case	'\\':
		put_goto();
		break;
	case	'~':
		put_call();
		break;
	case	'#':
		put_label();
		break;
	case	'&':
	case	'%':
		put_advjp();
		break;
	case	'<':
		put_loop();
		break;
	case	'>':
		put_loop_end();
		break;
	case	0x2f:
		put_38com();
		break;
	default:
		if (pass == 0)	{
			off = len; 
			return;
		}
		woff = off;
		do	{
			fbuf[off] = 0;
			if (*TOPP == 0x7f)	break;
			off++;
		}	while(fbuf[off] == 1 && off < len);
		off = woff;
		sputs("\n");
		return;
	}
	if (pass == 0 && ioff == (uint)off)	{	/* �R�}���h�G���[ */
		off = len;
		return;
	}
	if (pass == 1 && ioff == (uint)off)	{	/* �R�}���h�G���[ */
		if (off < len)	fbuf[off] = 0;
	}
}
void	dump_flg(uchar *p,int woff,int byte)
{	/* �����t���O�_���v���X�g */
	int	lp;
	uint	c;
	if (dump_mode==0)	return;
	p = fbuf;
	p += woff;
	sputsi("\n;F A:%06x-",p - ald_flg);
	sputsi("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		sputsi("%02x ",*(p+lp));
	}
	sputs(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				sputsi("%c",c);
				sputsi("%c",*(p+lp));
			}
			else	sputs(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	sputsi("%c",c);
			else	sputs(".");
		}
	}
/*	sputs("\n");	*/
}
void	dump_flg_err(uchar *p,int woff,int byte)
{	/* �G���[�������t���O�_���v���X�g */
	int	lp;
	uint	c;
	p = fbuf;
	p += woff;
	printf("\n;ERR F A:%06x-",p - ald_flg);
	printf("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		printf("%02x ",*(p+lp));
	}
	printf(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				printf("%c",c);
				printf("%c",*(p+lp));
			}
			else	printf(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	printf("%c",c);
			else	printf(".");
		}
	}
	printf("\n");
}
void	dump16(uchar *p,int woff,int byte)
{	/* �f�[�^�_���v���X�g */
	int	lp;
	uint	c;
	dump_flg(p,woff,byte);
	if (dump_mode==0)	return;
	p += woff;
	sputsi("\n;D A:%06x-",p - ald_buf);
	sputsi("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		sputsi("%02x ",*(p+lp));
	}
	sputs(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				sputsi("%c",c);
				sputsi("%c",*(p+lp));
			}
			else	sputs(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	sputsi("%c",c);
			else	sputs(".");
		}
	}
	sputs("\n");
}
void	dump_err(uchar *p,int woff,int byte)
{	/* �G���[���_���v���X�g(�����t���O�t��) */
	int	lp;
	uint	c;
	dump_flg_err(p,woff,byte);
	p += woff;
	printf("\n;ERR D A:%06x-",p - ald_buf);
	printf("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		printf("%02x ",*(p+lp));
	}
	printf(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				printf("%c",c);
				printf("%c",*(p+lp));
			}
			else	printf(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	printf("%c",c);
			else	printf(".");
		}
	}
	printf("\n");
}
void	dump(void)
{	/*�@�t�R���p�C�����t�@�C���̍Ō�܂ŌJ��Ԃ� */
	while (off < len)	{
		dump_sub();
	}
}
int	get_block(void)
{	/* ALD�t�@�C������eSCO�t�@�C���̈ʒu��A�I�t�Z�b�g�𓾂� */
	uint	ap,byte,start,mp,page;
	uchar	*p;
	FILE	*sco;
	debugi("\nget_block lincnt = %d",libcnt);
	p = ald_buf;
	if (((p[0]=='S') && (p[1]=='3')&& (p[2]=='5') && (p[3]=='1'))
	|| ((p[0]=='1') && (p[1]=='5')&& (p[2]=='3') && (p[3]=='S'))
	|| ((p[0]=='S') && (p[1]=='3')&& (p[2]=='8') && (p[3]=='0')))	{
		if (libcnt >= 2)	return	0;
		
		off = ald_buf[4];
		off += ald_buf[5]*256;
		off += ald_buf[6]*256*256;
		off += ald_buf[7]*256*256*256;
		len = ald_len;
		buf = p;
		fbuf = ald_flg;
		offtop = off;
		return	1;
	}
	if (libcnt == 0)	return	0;

	mp = p[0];
	mp += p[1]*256;
	mp += p[2]*256*256;
	mp = mp*256;			/* ײ���ؔԍ�ð��قւ̵̾�Ă𓾂� */
	if (mp >= (uint)ald_len)	usage("�I�u�W�F�N�g�t�@�C���s��");
	if (libcnt * 3 >= mp)	return	0;	/* �e�[�u���O */
	
	if (p[mp+(libcnt-1)*3]==0x00)	return	0;
	if (p[mp+(libcnt-1)*3]!=0x01)	return	2;
	page = p[mp+(libcnt-1)*3+1];
	page += p[mp+(libcnt-1)*3+2]*256;
	
	ap = p[page*3];
	ap += p[page*3+1]*256;
	ap += p[page*3+2]*256*256;
	ap = ap*256;			/* ײ����ͯ�ނւ̵̾�Ă𓾂� */
	if (ap == 0)	return	0;
	debugi("\nap = %08x ",ap);
	if ((p[ap]=='N')&&(p[ap+1]=='L'))	return	0;
	start = p[ap];
	start += p[ap+1]*256;
	start += p[ap+2]*256*256;
	start += p[ap+3]*256*256*256;	/* sco�t�@�C���ւ̃I�t�Z�b�g�𓾂� */
	if (start > 0x30)	return	0;
	debugi("\nstart = %x ",start);
	byte = p[ap+4];
	byte += p[ap+5]*256;
	byte += p[ap+6]*256*256;
	byte += p[ap+7]*256*256*256;	/* sco�t�@�C���̃o�C�g���𓾂� */
	debugi("\nbyte = %08x ",byte);
	off = p[ap+start+4];
	off += p[ap+start+5]*256;
	off += p[ap+start+6]*256*256;
	off += p[ap+start+7]*256*256*256;/* ��۸��ъJ�n�ʒu�ւ̵̾�Ă𓾂� */
	len = byte;
	buf = p+ap+start;
	fbuf = ald_flg+ap+start;
	offtop = off;
	copy_adv_name_f(advname,buf+18);
	name_set(advname,".SCO");
	if (pass == 1 && sco_mode==1)	{
		if( (sco=fopen(advname,"wb" ))==(FILE *)NULL )
			usage( "���I�u�W�F�N�g�t�@�C�����쐬�ł��܂���B\n" );
		if (fwrite(buf,sizeof(*buf),len,sco) < (size_t)len)
			usage( "���I�u�W�F�N�g�t�@�C���ɏ������߂܂���B\n" );
		fclose(sco);
		printf("\nCreate = %s  lib = %d",advname,libcnt);
	}
	return	1;
}
void	name_set(char *p,char *q)
{	/* �t�@�C���̊g���q���Z�b�g */
	while(*p != 0)	{
		if (*p == '.')	{
			strcpy(p,q);
			break;
		}
		p++;
	}
}
void	set_flg_allarea(int offset,int byte,int flg)
{	/* �����t���O���Z�b�g�����Z�b�g���� */
	int	lp;
	for (lp=0;lp<byte;lp++)	{
		ald_flg[offset+lp] = flg;
	}
}
void	pgm_data(uchar *name)
{	/* �v���O�����G���A���f�[�^�G���A���ăZ�b�g���� */
	int	fh,leng;
	char	buf[512],*p,c;
	int	start,end;
	if (*name == 0)	return;
	if( (fp3=fopen(name,"rt" ))==(FILE *)NULL )
		usage( "�A�h���X�t�@�C�����I�[�v���ł��܂���B\n" );
	while (fgets(buf,512,fp3)!=NULL)	{
		p = buf;
		sscanf(p+1,"%x,%x",&start,&end);
		if (start < offtop)	break;
		if (end < offtop)	break;
		if (start > ald_len)	break;
		if (end > ald_len)	break;
		c = tolower(*p);
		switch (c)	{
		case	'p':	/* �v���O�����G���A */
			set_flg_allarea(start,end - start + 1,1);
			break;
		case	'd':	/* �f�[�^�G���A */
			set_flg_allarea(start,end - start + 1,0);
			break;
		}
	}
	fclose(fp3);
}
uchar	*dfunc_make(uchar *p,struct s_dfunc *dfunc)
{	/* �ЂƂ̊֐���`����� */
	int	lp;
	dfunc->name = p;
	p+=strlen(p)+1;							/* �|�C���^���֐����̌��ɃZ�b�g */
	dfunc->cnt = *((int *)p);				/* �֐���`���𓾂� */
	p+=4;
	if (dfunc->cnt)
		dfunc->para = (int *)chk_malloc(dfunc->cnt*sizeof(int));
	for (lp=0;lp<dfunc->cnt;lp++)	{
		dfunc->para[lp] = *((int *)p);
		p+=4;
	}
	return	p;
}
uchar	*hel_make(uchar *p,struct s_hel *hel)
{	/* �ЂƂ�HEL�t�@�C����`����� */
	int	lp;
	hel->name = p;					/* hel�t�@�C����(�g���q������)�̈ʒu���Z�b�g */
	p+=strlen(p)+1;							/* �|�C���^��hel�t�@�C�����̌��ɃZ�b�g */
	hel->cnt = *((int *)p);		/* �֐���`���𓾂� */
	p+=4;
	if (hel->cnt)
		hel->dfunc = (struct s_dfunc *)chk_malloc(hel->cnt*sizeof(struct s_dfunc));
	printf("hel = %s dfunc_count = %d\n",hel->name, hel->cnt);
	for (lp=0;lp<hel->cnt;lp++)	{
		p = dfunc_make(p,&hel->dfunc[lp]);			/* �ЂƂ̊֐���`����� */
	}
	return	p;
}
void	dfunc_list(struct s_dfunc *dfunc)
{	/* dll�֐��������o�� */
	int	lp;
	char	buf[1024];
	fprintf(fp_hel,"void %s(",dfunc->name);
	if (dfunc->cnt == 0)	{
		fputs("void)\n",fp_hel);
		return;
	}
	for (lp=0;lp<dfunc->cnt;lp++)	{
		switch (dfunc->para[lp])	{
			case 0:fputs("pword foo",fp_hel);break;
			case 1:fputs("int foo",fp_hel);break;
			case 2:fputs("ISurface foo",fp_hel);break;
			case 3:fputs("IString foo",fp_hel);break;
			case 4:fputs("IWinMsg foo",fp_hel);break;
			case 5:fputs("ITimer foo",fp_hel);break;
			case 6:fputs("IUI foo",fp_hel);break;
			case 7:fputs("ISys3xDIB foo",fp_hel);break;
			case 9:fputs("ISys3xCG foo",fp_hel);break;
			case 10:fputs("ISys3xStringTable foo",fp_hel);break;
			case 13:fputs("ISys3xSystem foo",fp_hel);break;
			case 14:fputs("ISys3xMusic foo",fp_hel);break;
			case 15:fputs("ISys3xMsgString foo",fp_hel);break;
			case 16:fputs("ISys3xInputDevice foo",fp_hel);break;
			case 17:fputs("ISys3x foo",fp_hel);break;
			case 18:fputs("IConstString foo",fp_hel);break;
		}
		if (lp+1 < dfunc->cnt)	fputs(",",fp_hel);
	}
	fputs(")\n",fp_hel);
}
void	hel_list(struct s_hel *hel)
{	/* HEL�t�@�C������� */
	int	lp;
	char	buf[1024];
	sprintf(buf,"%s.HEL",hel->name);
	if( (fp_hel=fopen(buf,"wt" ))==(FILE *)NULL )
		puts("�t�@�C�����I�[�v���ł��܂���B\n");
	fputs("\n",fp_hel);
	for (lp=0;lp<hel->cnt;lp++)	{					/* �֐��̕��J��Ԃ� */
		dfunc_list(&hel->dfunc[lp]);					/* �֐��������o�� */
	}
	fclose(fp_hel);
}
int	chk_helname(int cnt)
{	/* �����hel�t�@�C�����������`�F�b�N */
	int	lp;
	for (lp=0;lp<cnt;lp++)	{
		if (strcmpi(hel[lp].name,hel[cnt].name)==0)	return	0;
	}
	return	1;
}
uchar *helo_proc(uchar *p)
{	/* ain�t�@�C������͂��āA�f�[�^���\������hel�t�@�C�����쐬���� */
	int lp;
	p+=8;
	if (strcmp("HEL0",p)!=0)	return	p;	/* HELO �w�b�_ */
	p+=8;
	hel_count = *((int *)p);			/* HEL��`�t�@�C���̐��𓾂� */
	if (hel_count)
		hel = (struct s_hel *)chk_malloc(hel_count*sizeof(struct s_hel));
	p+=4;
	printf("hel_count = %d\n",hel_count);
	for (lp=0;lp<hel_count;lp++)	{
		p = hel_make(p,&hel[lp]);						/* �ЂƂ�HEL�t�@�C����`����� */
	}
	for (lp=0;lp<hel_count;lp++)	{
		if (chk_helname(lp))
			hel_list(&hel[lp]);								/* HEL�t�@�C�����쐬���� */
	}
	return	p;
}
uchar	*func_make(uchar *p,struct s_func *func)
{	/* �ЂƂ�HEL�t�@�C����`����� */
	int	lp;
	func->name = p;					/* �֐����̈ʒu���Z�b�g */
	p+=strlen(p)+1;					/* �|�C���^���֐����t�@�C�����̌��ɃZ�b�g */
	func->page = *((short *)p);		/* �y�[�W�ԍ��𓾂� */
	p+=2;
	func->adr = *((int *)p);		/* .sco�擪����̑��΃A�h���X�𓾂� */
	p+=4;
	return	p;
}
void	func_list(struct s_func *func)
{	/* FNC�t�@�C������� */
	int	lp;
	char	buf[1024];
	FILE	*fp_func;
	fprintf(fp_func,"func = %s  page = %d adr = %08x\n",func->name,func->page,func->adr);
}
uchar *func_proc(uchar *p)
{	/* ain�t�@�C������͂��āA�֐��f�[�^���\������fnc�t�@�C�����쐬���� */
	char	buf[1024];
	FILE	*fp_func;
	int lp;
	if (strcmp("FUNC",p)!=0)	return	p;	/* FUNC �w�b�_ */
	p+=8;
	func_count = *((int *)p);				/* �֐���`�̐��𓾂� */
	if (func_count)
		func = (struct s_func *)chk_malloc(func_count*sizeof(struct s_func));
	p+=4;
	printf("func_count = %d\n",func_count);
	for (lp=0;lp<func_count;lp++)	{
		p = func_make(p,&func[lp]);						/* �ЂƂ̊֐���`����� */
	}
	sprintf(buf,"SYSTEM39.FNC");
	if( (fp_func=fopen(buf,"wt" ))==(FILE *)NULL )
		usage("�t�@�C�����I�[�v���ł��܂���B\n");
	for (lp=0;lp<func_count;lp++)	{
		fprintf(fp_func,"func = %s  page = %d adr = %08x\n",func[lp].name,func[lp].page,func[lp].adr);
	}
	fclose(fp_func);
	return	p;
}
uchar *vari_proc(uchar *p)
{	/* ain�t�@�C������͂��āA�ϐ��f�[�^���\������var�t�@�C�����쐬���� */
	char	buf[1024];
	FILE	*fp_vari;
	int lp;
	if (strcmp("VARI",p)!=0)	return	p;	/* VARI �w�b�_ */
	p+=8;
	vari_count = *((int *)p);				/* �ϐ���`�̐��𓾂� */
	if (vari_count)
		vari = (struct s_vari *)chk_malloc(vari_count*sizeof(struct s_vari));
	p+=4;
	printf("vari_count = %d\n",vari_count);
	for (lp=0;lp<vari_count;lp++)	{
		vari[lp].name = p;					/* �ϐ����̈ʒu���Z�b�g */
		p+=strlen(p)+1;						/* �|�C���^��ϐ����̌��ɃZ�b�g */
	}
	sprintf(buf,"SYSTEM39.VAR");
	if( (fp_vari=fopen(buf,"wt" ))==(FILE *)NULL )
		usage("�t�@�C�����I�[�v���ł��܂���B\n");
	for (lp=0;lp<vari_count;lp++)	{
		fprintf(fp_vari,"vari = %s\n",vari[lp].name);
	}
	fclose(fp_vari);
	return	p;
}
uchar *msgi_proc(uchar *p)
{	/* ain�t�@�C������͂��āA������f�[�^���\������msg�t�@�C�����쐬���� */
	char	buf[1024];
	FILE	*fp_msgi;
	int lp,msgi_count;
	if (strcmp("MSGI",p)!=0)	return	p;	/* MSGI �w�b�_ */
	p+=8;
	msgi_count = *((int *)p);				/* �������ް��̐��𓾂� */
	if (msgi_count)
		msgi = (struct s_msgi *)chk_malloc(msgi_count*sizeof(struct s_msgi));
	p+=4;
	printf("msgi_count = %d\n",msgi_count);
	for (lp=0;lp<msgi_count;lp++)	{
		msgi[lp].name = p;					/* �������ް��̈ʒu���Z�b�g */
		p+=strlen(p)+1;						/* �|�C���^�𕶎����ް��̌��ɃZ�b�g */
	}
	sprintf(buf,"SYSTEM39.MSG");
	if( (fp_msgi=fopen(buf,"wt" ))==(FILE *)NULL )
		usage("�t�@�C�����I�[�v���ł��܂���B\n");
	for (lp=0;lp<msgi_count;lp++)	{
		fprintf(fp_msgi,"msgi = %s\n",msgi[lp].name);
	}
	fclose(fp_msgi);
	return	p;
}
int	shift(uchar *p,int len)
{
	int lp;
	unsigned char c;
	for (lp=0;lp<len;lp++)	{
		*p = _crotl(*p,2);
		p++;
	}
}
int	main(int argc,char *argv[])
{
	int		fh,lp,cnt,non_hed,fncnt;
	char	name[256],advname[256];
	int		hel_len;					/* hel file length */
	uchar	*hel_buf,*p;				/* hel file buff */

	printf("\nSYSTEM 3.9  DIS COMPILER Ver.1.00  By T.HASEGAWA\n");
	printf("\n     Modify   : DC38.exe Ver.1.05  By TOTO@UnitBase\n");
	printf("     original : DC36.exe Ver.1.07  By T.HASEGAWA\n\n");

	if( argc < 2 )
		usage("�ǂݍ��݃t�@�C�����w�肵�ĉ�����\n");

/* ald(sco)�t�@�C���̓ǂݍ��� */

	if( (fp=fopen(argv[1],"rb" ))==(FILE *)NULL )
		usage( "�t�@�C�����I�[�v���ł��܂���B\n" );
	fh = fileno( fp );
	ald_len=(uint)filelength(fh);
	ald_buf = chk_malloc(ald_len+32);
	ald_flg = chk_malloc(ald_len+32);
	memset(ald_flg,0,ald_len+32);
	if( (read( fh,(char *)(ald_buf),ald_len ))<(uint)1 )	{
		usage("�t�@�C�����ǂ߂܂���B\n");
	}
	fclose(fp);
/* system3.9.ain��ǂݍ��݉�͂��� */
	if( (fp_hel=fopen("system39.ain","rb" ))==(FILE *)NULL )
		puts("�t�@�C�����I�[�v���ł��܂���B\n");

	fh = fileno( fp_hel );
	hel_len=(uint)filelength(fh);
	hel_buf = malloc(hel_len+32);

	if( (read( fh,(char *)(hel_buf),hel_len ))<(uint)1 )	{
		puts("�t�@�C�����ǂ߂܂���B\n");
	}
	fclose(fp_hel);

	shift(hel_buf,hel_len);	/* �f�[�^�̐��퉻 */

	if( (fp_hel=fopen("system39.a2","wb" ))==(FILE *)NULL )
		puts( "A2�t�@�C�����쐬�ł��܂���B\n" );
	fh = fileno( fp_hel );
	write(fh,hel_buf,hel_len);
	fclose(fp_hel);

	p = helo_proc(hel_buf);		/* dll�����\�������t�@�C���o�͂��� */
	p = func_proc(p);			/* �֐������\����&�t�@�C���o�͂��� */
	p = vari_proc(p);			/* �ϐ������\����&�t�@�C���o�͂��� */
	p = msgi_proc(p);			/* ����������\����&�t�@�C���o�͂��� */

	if( (fp2=fopen("DC39C.HED","wt" ))==(FILE *)NULL )
		usage( "�g�d�c�t�@�C�����I�[�v���ł��܂���B\n" );
	fprintf(fp2,"#SYSTEM35\n");
	dump_mode = 0;
	debug_mode = 0;
	pre_mode = 0;
	non_hed = 0;
	name[0] = 0;
	sco_mode = 0;
	for (lp=2;lp<argc;lp++)	{
		switch (tolower(*argv[lp]))	{
		case	't':	debug_mode = 1;break;
		case	'd':	dump_mode = 1;break;
		case	'p':	pre_mode = 1;break;
		case	'a':	strcpy(name,argv[lp]+1);break;
		case	'n':	non_hed = 1;break;
		case	's':	sco_mode = 1;break;
		}
	}

	adr_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* if goto address */

	label_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	label_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);/* label address */
	memset(label_buf,0,sizeof(uint)*MAXTBL);
	memset(label_lib_buf,0,sizeof(uint)*MAXTBL);

	data_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	data_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	memset(data_buf,0,sizeof(uint)*MAXTBL);
	memset(data_lib_buf,0,sizeof(uint)*MAXTBL);

	loop_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* loop address */
	loop_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* loop address */
	memset(loop_buf,0,sizeof(uint)*MAXTBL);
	memset(loop_lib_buf,0,sizeof(uint)*MAXTBL);

	call_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* call address */
	call_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* call address */
	memset(call_buf,0,sizeof(uint)*MAXTBL);
	memset(call_lib_buf,0,sizeof(uint)*MAXTBL);

	str = 0;				/* string buff address */

	libcnt = 1;	/* ���C�u�����ԍ� */
	callp = 0;	/* call buffer address offset */
	errcnt = 0;

	varmax = 0;	/* �ϐ��ő吔 */

	labelp = 0;	/* label buffer address offset */
	datap = 0;	/* data buffer address offset */
	loopp = 0;	/* loop buffer address offset */
	pass = 0;	/* pass run */
	swait = 0;	/* ������o�͈ꎞ��~ */
	swait2 = 1;
	sen_mode = 0;	/* �I�������W�J���[�h */

	adrp = 0;	/* buff address offset */ 
	tabcnt = 1;	/* �C���f���gTAB�� */

	pre = 0;	/* �v���X�L�����J�E���^�[ */
	kanji_flg = 0;	/* �����t���O */

next:if (get_block()==0)	{
		if (pre <= 1)	{
			pre++;
			libcnt = 1;
			adrp = 0;
			goto	next;
		}
		if (pass == 0)	{
			debug(" pass = 1");
			libcnt = 1;
			adrp = 0;
			pgm_data(name);
			pass = 1;
			goto	next;
		}
		fputs("\n#DLLHeader\n",fp2);
		for (lp=0;lp<hel_count;lp++)	{
			fprintf(fp2,"%s.HEL\n",hel[lp].name);
		}
		fclose(fp2);
		if (name[0] != 0 && pre == 2)	{
			pre++;
			libcnt = 1;
			adrp = 0;
			if( (fp2=fopen("DC39C.HED","wt" ))==(FILE *)NULL )
				usage( "�g�d�c�t�@�C�����I�[�v���ł��܂���B\n" );
			fprintf(fp2,"#SYSTEM35\n");
			goto	next;
		}
		return	0;
	} else if(get_block()==2) {
		if (pass!=0) {
			sprintf(advname, "_page%03d_adv", libcnt);
			if( (fp=fopen(advname,"wt" ))==(FILE *)NULL )
				usage( "�V�i���I�t�@�C�����쐬�ł��܂���B\n" );
			fprintf(fp2,"%s\n",advname);
			printf("\nCreate = %s  lib = %d  (dummy)",advname,libcnt);
			fprintf(fp,";name : %s\n",advname);
			fprintf(fp,";lib  : %d\n",libcnt);
			for (cnt=0;cnt<=0xffff;cnt++) {
				if (fncnt=chk_call_adr(cnt,libcnt))
					fprintf(fp,"\n**%s:\n	%%0:\n",func[fncnt].name);
			}
			fprintf(fp,"\n	'dummy'\n");
			fclose(fp);
		}
		libcnt++;
		goto	next;
	}
	if (pass == 0 && pre == 0)	{
		off = offtop;
		dump();
		off = offtop;
		data_fld_adr_set();
		libcnt++;
		goto	next;
	}
	if (pass == 0)	{
		off = offtop;
		data_fld_adr_set();
		libcnt++;
		goto	next;
	}
	copy_adv_name_f(advname,buf+18);
	if( (fp=fopen(advname,"wt" ))==(FILE *)NULL )
		usage( "�V�i���I�t�@�C�����쐬�ł��܂���B\n" );
	fprintf(fp2,"%s\n",advname);
	printf("\nCreate = %s  lib = %d",advname,libcnt);
	sputsc(";name : %s\n",advname);
	sputsi(";lib  : %d\n",libcnt);
	if (libcnt == 1 && non_hed==0)	{
		for (lp=0;lp<(int)varmax;lp++)	{
			sputsc("\t!%s:0!\n",vari[lp].name);
		}
	}
	adrp = 0;	/* buff address offset */ 
	tabcnt = 1;
	dump();
	sputs("\n");
	chk_adr_all();
	if (pre==2)	{
		pass=0;
		off = offtop;
		data_fld_adr_set();
		pass=1;
	}
	fclose(fp);
	libcnt++;
	goto	next;
}
