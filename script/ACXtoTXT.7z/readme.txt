This is the tool to turn ACX files into plain text files, so you can translate them, or hack the int values.
It works by using AliceSoft's own DLL (ACXLoader.dll, taken from Alice2010) to read them.
I'm also including the TXTtoACX.exe tool which came from the System 4.2 SDK.

These programs are all command-line driven, you need to open a command prompt window, or you can drag an ACX file onto ACXtoTXT.exe, and drag a TXT file onto TXTtoACX.

What's an ACX file?
-------------------
Some of AliceSoft's System 4.x games include ACX files in a directory named Data.
These are tables consisiting of int and string values.
The file format is compressed, so you can't directly edit it with a hex editor.

What's this tool?
-----------------
This tool (ACXtoTXT.exe) loads an ACX file, and outputs a plain TXT file.
To use it, run it from the command line, or drag an ACX file on top of ACXtoTXT.exe.

This tool works by using AliceSoft's ACXLoader.dll to do all the dirty work.
I just had to figure out exactly how to call the functions of the DLL properly.  See the source code for details.

What's the other tool (TXTtoACX)?
---------------------------------
The other tool (TXTtoACX.EXE) comes from the AliceSoft System 4.2 SDK, and converts a TXT file into an ACX file.
To use it, run it form the command line, or drag a TXT file on top of TXTtoACX.exe
Note that the TXT files specify the filename of the ACX file that gets created.

Example batch files
-------------------
To convert all ACX files to TXT files in the current directory:

@echo off
for %F in (*.ACX) DO "ACXtoTXT.exe" "%F"

To convert all TXT files to ACX files in the current directory:

@echo off
for %F in (*.TXT) DO "TXTtoACX.exe" "%F"
