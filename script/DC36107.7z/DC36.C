/*

�@�@�A�g���N���i�N�A&�S�{��&�뎮&�����X�P&�����X�R&���_�s�s�P&�ς��Ă�`���C��
�@�@�A���r�o�����c&��ޏ�&�l��&Dr.STOP!&������ɂ�

*/
#include	<conio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<stdio.h>
#include	<io.h>
#include	<string.h>

#define	ESC	0x1b
#define	CR	0x0d
#define	MAXTBL	0x2000

#define	DLINE	16
#define DCOL	8
#define	TOPP	(buf+off)

typedef	unsigned char	uchar;
typedef	unsigned int	uint;

        FILE    *fp,*fp2,*fp3;
	uchar	*buf;		/* file top pointer */
	uchar	*fbuf;		/* flag top pointer */
	int	pre;		/* pre count */
	int	len;		/* file length */
	int	off;		/* file offset */
	int	offtop;		/* off top */
	uint	*adr_buf;	/* if goto address */
	int	adrp;		/* buff address offset */ 
	int	errcnt;		/* error counter */

	uint	*label_buf;	/* label address */
	uint	*label_lib_buf;	/* label lib address */
	int	labelp;		/* label buffer address offset */

	uint	*data_buf;	/* data address */
	uint	*data_lib_buf;	/* data lib address */
	int	datap;		/* data buffer address offset */

	uint	*loop_buf;	/* loop address */
	uint	*loop_lib_buf;	/* loop lib address */
	int	loopp;		/* loop buffer address offset */

	uint	*call_buf;	/* call address */
	uint	*call_lib_buf;	/* call lib address */
	int	callp;		/* call buffer address offset */

	int	ald_len;	/* ald file length */
	uint	libcnt;		/* lib count */
	uchar	*ald_buf;	/* ald file buff */
	uchar	*ald_flg;	/* ald flag buff */

	uchar	*str;		/* string buffer */
	int	swait;		/* string wait write mode */

	int	pass;		/* pass */

	int	dump_mode;	/* 0: nondump 1:dump */
	int	debug_mode;	/* 0: nondebug 1:debug */
	int	pre_mode;	/* 0: nonprint 1:preprint */
	int	sen_mode;	/* 0: nonsen 1:�I�����[�h */
	int	sco_mode;	/* 0:nonsco 1:��sco�쐬 */

	int	tabcnt;		/* tab count */

	uint	varmax,varmin;	/* �ϐ��ő�l(�ő�l�ی�p) */
	int	kanji_flg;	/* �����t�B�[���h�n�m�@�n�e�e */
	char	advname[256];	/* adv name */

void	dump(void);
void	dump16(uchar *,int,int);
void	dump_err(uchar *,int,int);
int	get_block(void);
void	sputs(char *);
void	sputsi(char *,uint);
void	sputsc(char *,uchar *);
uchar	*get_adv_name(uint);
void	usage(char *);		/* �G���[���b�Z�[�W */
void	dump_sub(void);
void	copy_adv_name(uchar *,uchar *);
void	name_set(char *,char *);

uchar 	*kana_zen(uint c)
{	/* ���p�J�i��S�p�Ђ炪�Ȃɕϊ�(SYS3.5�p) */
static	uchar	*kana = "�@�B�u�v�A�E������������������[�����������������������������������ĂƂȂɂʂ˂̂͂Ђӂւق܂݂ނ߂������������h�K";
	if (c== 0x20)	return	kana;
	return	kana + (c - 0xa0)*2;
}
void	debug(char *s)
{	/* �f�o�b�O���b�Z�[�W�\�� */
	if (debug_mode)	{
		sputs(s);
	}
}		
void	debugi(char *s,uint c)
{	/* �f�o�b�O���b�Z�[�W�\���i���l�t���j */
	if (debug_mode)
		sputsi(s,c);
}		
void	set_flg(uint offset,uint cnt)
{	/* pass 0���̂݃t���O���Z�b�g���� */
	if (pass)	return;
	memset(fbuf+offset,1,cnt);
}
void	reset_flg(uint offset,uint cnt)
{	/* pass 0���̂݃t���O����Z�b�g���� */
	if (pass)	return;
	memset(fbuf+offset,0,cnt);
}
void	sputs(char *p)
{	/* ������o�� */
	if (pass)	{
		if (swait)	strcat(str,p);
		else	{
			if (debug_mode)	printf(p);
			else		fprintf(fp,p);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	strcat(str,p);
			else	if (debug_mode)	printf(p);
		}
	}
}
void	sputsi(char *p,uint c)
{	/* ������o�́i���l�t���j */
	uchar	st[512];
	if (pass)	{
		if (swait)	{
			sprintf(st,p,c);
			strcat(str,st);
		}
		else	{
			if (debug_mode)	printf(p,c);
			else		fprintf(fp,p,c);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	{
				sprintf(st,p,c);
				strcat(str,st);
			}
			else	if (debug_mode)	printf(p,c);
		}
	}
}
void	sputsc(char *p,uchar *s)
{	/* ������o�́i�ǉ�������t���j */
	uchar	st[512];
	if (pass)	{
		if (swait)	{
			sprintf(st,p,s);
			strcat(str,st);
		}
		else	{
			if (debug_mode)	printf(p,s);
			else		fprintf(fp,p,s);
		}
	}
	else	{
		if (pre_mode)	{
			if (swait)	{
				sprintf(st,p,s);
				strcat(str,st);
			}
			else	if (debug_mode)	printf(p,s);
		}
	}
}
void	usage(char *p)		/* �G���[���b�Z�[�W */
{
	if (pass)	fclose(fp);
	puts( "\nUsage : DC36 file [D]" );
	puts( p );
	exit( 1 );
}
void	*chk_malloc(int size)
{	/* �`�F�b�N�@�\�t���������A���P�[�V���� */
	void *mem;
	mem=malloc(size);
	if (mem==NULL)	usage("��ذ���۹���݂ł��܂���");
	return	mem;
}
int	kana_chk(uint c)
{	/* ���������`�F�b�N�iSYS3.5������p�j */
	if (c==0x20)	return	1;
	if (c>0xa0 && c<0xe0)	return	1;
	return	0;
}
int	kanji_chk(uint c)
{	/* ������P�o�C�g�`�F�b�N */
	if ((c>(uint)0x80 && c<(int)0xa0) || (c>=(uint)0xe0 && c<=(uint)0xef))	return	1;
	return	0;
}
int	kanji_chk2(uint c)
{	/* ������Q�o�C�g�`�F�b�N */
	if (c>=0x40 && c!=0x7f && c!=0xff)	return	1;
	return	0;
}
void	tab(void)
{	/* �C���f���g��TAB�����o�� */
	int	lp;
	if (sen_mode)	return;
	for (lp=0;lp<tabcnt;lp++)	{
		sputs("\t");
	}
}
void	put_1(void)
{	/* �P�����R�}���h�W�J */
	debug(" put_1");
	tab();
	sputsi("%c",*TOPP);
	dump16(buf,off,1);
	set_flg(off,1);
	off++;
}
void	put_str(void)
{	/* �R�}���h��������W�J */
	uchar	c,*kana;
	uint	woff;
	int	cnt;
	woff = off;
	cnt = 0;
	while ((c = *TOPP) != ':')	{
		if (cnt >= 128)	{
			dump_err(buf,woff,off - woff);
			usage("�����񂪂P�Q�W�o�C�g�ȏ゠��");
		}
		if (c<0x20)	{
			dump_err(buf,woff,off - woff);
			usage("������ɕs���Ȃ��̂�����");
		}
		if (kanji_chk(*TOPP))	{
			sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
			sputsi("%c",*TOPP);
			cnt++;
		}
		else
		if (kana_chk(*TOPP))	{
			kana = kana_zen(*TOPP);
			sputsi("%c",*kana);
			sputsi("%c",*(kana+1));
		}
		else	sputsi("%c",*TOPP);
		set_flg(off,1);
		off++;
		cnt++;
	}
	set_flg(off,1);
	off++;
}
void	put_strd(void)
{	/* ������o�͑I�����p */
	uchar	c,*kana;
	uint	woff;
	int	cnt;
	woff = off;
	cnt = 0;
	while ((c = *TOPP) != '$')	{
		if (cnt >= 128)	{
			dump_err(buf,woff,off - woff);
			usage("�I�����p�����񂪂P�Q�W�o�C�g�ȏ゠��");
		}
		if (c<0x20)	{
			dump_err(buf,woff,off - woff);
			usage("�I�����p������ɕs���Ȃ��̂�����");
		}
		if (kanji_chk(*TOPP))	{
			sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
			sputsi("%c",*TOPP);
			cnt++;
		}
		else
		if (kana_chk(*TOPP))	{
			kana = kana_zen(*TOPP);
			sputsi("%c",*kana);
			sputsi("%c",*(kana+1));
		}
		else	sputsi("%c",*TOPP);
		set_flg(off,1);
		off++;
		cnt++;
	}
	set_flg(off,1);
	off++;
}
int	back_str(uchar *p,int sp)
{	/* �ЂƂO�̃X�g�����O�|�C���g�𓾂� */
	int	lp;
	if (sp==0)	return	sp;
	sp--;
	while (sp)	{
		sp--;
		if (p[sp] == 0)	return	sp+1;
	}
	return	sp;
}
int	chk_stp(int stp,int woff)
{	/* �v�Z���W�J�p�����ُ�͈͔���BϲŽ���g�p�O�A��׽���g�p������� */
	if (stp==0 || stp>=127)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			varmax = varmin;	/* �ϐ��}�b�N�X�߂� */
			return	1;	/* �ُ� */
		}
		else	usage("�v�Z���W�J�G���[");
	}
	return	0;	/* ����͈� */
}
int	put_rpo(int woff)	/* woff ���������擪 */
{	/* 1: �n�j	0:�m�f */
	uchar	c;
	uint	num;
	uint	st[128];
	uchar	p[4096],pt[4096];
	int	cnt,lp,sp,s1,s2,s3,stp,t3;
	varmin = varmax;
	stp = sp = 0;
	p[0] =0;
	pt[0] = 0;
loop:	c = *TOPP;
	set_flg(off,1);
	off++;
	if (c>=0xc0)	{
		if (c==0xc0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			num += *TOPP;
			s1 = sp + sprintf(&p[sp],"VAR%04d[",num) + 1;
			if (varmax < num)	varmax = num;
			sp = s1;
			st[stp++] = 2;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			off++;
		}
		else	{	/* �ϐ� */
			s1 = sp + sprintf(&p[sp],"VAR%04d",num = (c - 0xc0)*256 + *TOPP) + 1;
			if (varmax < num)	varmax = num;

			sp = s1;
			st[stp++] = 1;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			set_flg(off,1);
			off++;
		}
	}
	else
	if (c>=0x80)	{	/* �ϐ� */
		s1 = sp + sprintf(&p[sp],"VAR%04d",num = c - 0x80) + 1;
		if (varmax < num)	varmax = num;
		sp = s1;
		st[stp++] = 1;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
	}
	else
	if (c == 0x7f)	{
		s1 = back_str(p,sp);	/* ����� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		if (s1>0)	{
			s2 = back_str(p,s1);	/* �O���� */
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			--stp;
			sprintf(pt,"%s%s]",&p[s2],&p[s1]);
			s2 += sprintf(&p[s2],pt) + 1;
			st[stp++] = 4;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			pt[0] = 0;
			sp = s2;
			goto	loop;
		}
		sputs(p);
		return	1;	/* ���� */
	}
	else
	if (c>=0x74)	{	/* ���Z�q */
		switch (c)	{
		case	0x79:	
			s1 = sp + sprintf(&p[sp],"+") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7a:	
			s1 = sp + sprintf(&p[sp],"-") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x77:
			s1 = sp + sprintf(&p[sp],"*") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x78:
			s1 = sp + sprintf(&p[sp],"/") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7e:
			s1 = sp + sprintf(&p[sp],"\\") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x74:
			s1 = sp + sprintf(&p[sp],"&") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x75:
			s1 = sp + sprintf(&p[sp],"|") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x76:
			s1 = sp + sprintf(&p[sp],"^") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7b:
			s1 = sp + sprintf(&p[sp],"=") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7c:
			s1 = sp + sprintf(&p[sp],"<") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		case	0x7d:
			s1 = sp + sprintf(&p[sp],">") + 1;
			st[stp++] = 3;
			if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
			sp = s1;
			break;
		}
		s1 = back_str(p,sp);	/* ���Z�q */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s2 = back_str(p,s1);	/* ����� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		--stp;
		s3 = back_str(p,s2);	/* �O���� */
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		t3 = st[--stp];
		sprintf(pt,"(%s%s%s)",&p[s3],&p[s1],&p[s2]);
		if (t3 == 2)	{
			strcat(pt,"]");
			set_flg(off,1);
			off++;
		}
		s3 += sprintf(&p[s3],pt) + 1;  
		st[stp++] = 4;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		pt[0] = 0;
		sp = s3;
	}
	else
	if (c>=0x40)	{	/* ���l */
		s1 = sp + sprintf(&p[sp],"%d",c - 0x40) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
	}	
	else	{		/* ���l */
		num =(uint)c * 256 + *TOPP;
		s1 = sp + sprintf(&p[sp],"%d",num) + 1;
		sp = s1;
		st[stp++] = 0;
		if (chk_stp(stp,woff))	return	0;/* stp�͈͔��� */
		set_flg(off,1);
		off++;
	}
	goto	loop;
}
int	chk_call_adr(uint adr,uint lib)
{	/* �֐��w��A�h���X���`�F�b�N���� */
	callp = (adr*64) & (MAXTBL-1);
	while (call_buf[callp])	{	/* 0�Ȃ�Ȃ� */
		if ((call_buf[callp] == adr)
		&& (call_lib_buf[callp] == lib))	return	1;
		callp = (callp+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_call_adr(uint adr,uint lib)
{	/* �֐�call���̃A�h���X��ۑ����� */
	if (chk_call_adr(adr,lib)==0)	{
		call_buf[callp] = adr;
		call_lib_buf[callp] = lib;
	}
}
int	chk_loop_adr(uint adr)
{	/* �w��A�h���X�`�F�b�N���� */
	loopp = (adr*64) & (MAXTBL-1);
	while (loop_buf[loopp])	{	/* 0�Ȃ�Ȃ� */
		if ((loop_buf[loopp] == adr)
		&& (loop_lib_buf[loopp] == libcnt))	return	1;
		loopp = (loopp+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_loop_adr(uint adr)
{	/* loop���̃A�h���X��ۑ����� */
	if (chk_loop_adr(adr)==0)	{
		loop_buf[loopp] = adr;
		loop_lib_buf[loopp] = libcnt;
	}
}
int	chk_label_adr(uint adr)
{	/* �w��A�h���X�`�F�b�N���� */
	labelp = (adr*64) & (MAXTBL-1);
	while (label_buf[labelp])	{	/* 0�Ȃ�Ȃ� */
		if ((label_buf[labelp] == adr)
		&& (label_lib_buf[labelp] == libcnt))	return	1;
		labelp = (labelp+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_label_adr(uint adr)
{	/* label���̃A�h���X��ۑ����� */
	if (chk_label_adr(adr)==0)	{
		label_buf[labelp] = adr;
		label_lib_buf[labelp] = libcnt;
	}
}
int	chk_data_adr(uint adr)
{	/* �w��f�[�^�A�h���X�`�F�b�N���� */
	datap = (adr*64) & (MAXTBL-1);
	while (data_buf[datap])	{	/* 0�Ȃ�Ȃ� */
		if ((data_buf[datap] == adr)
		&& (data_lib_buf[datap] == libcnt))	return	1;
		datap = (datap+1) & (MAXTBL-1);
	}
	return	0;
}
void	set_data_adr(uint adr)
{	/* data���̃A�h���X��ۑ����� */
	if (chk_data_adr(adr)==0)	{
		data_buf[datap] = adr;
		data_lib_buf[datap] = libcnt;
	}
}
void	set_adr(uint adr)
{	/* if���̕��J�b�R�̃A�h���X��ۑ����� */
	adr_buf[adrp++] = adr;
}
int	chk_adr(uint adr)
{	/* �w��A�h���X�ɕ��J�b�R�����K�v���`�F�b�N���� */
	int	lp,cnt;
	cnt = 0;
	for (lp=0;lp<adrp;lp++)	{
		if (adr_buf[lp] == adr)	cnt++;
	}
	return	cnt;
}
void	del_adr(uint adr)
{	/* �w��A�h���X���e�[�u������폜���� */
	int	lp;
	for (lp=0;lp<adrp;lp++)	{
		if (adr_buf[lp] == adr)	{
			adr_buf[lp] = adr_buf[--adrp];
			lp--;
		}
	}
}
void	put_dai(void)
{	/* ������W�J */
	uchar	c;
	uint	woff,num;
	debug(" put_dai");
	varmin = varmax;
	woff = off;
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	if (*TOPP>=0xc0)	{
		num = (*TOPP - 0xc0)*256;
		set_flg(off,1);
		off++;
		if (num==0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			sputsi("VAR%04d[",num = num + *TOPP);
			off++;
			if (put_rpo(woff)==0)	return;
			if (varmax < num)	varmax = num;
			sputs("]:");
			goto	sk;
		}
		else	sputsi("VAR%04d:",num = num + *TOPP);
		if (varmax < num)	varmax = num;
	}
	else	{
		sputsi("VAR%04d:",num = (uint)*TOPP - 0x80);
		if (varmax < num)	varmax = num;
	}
	set_flg(off,1);
	off++;
sk:	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}
	sputs("!");
	dump16(buf,woff,off - woff);
	if (*TOPP == '<')
		set_loop_adr(woff);
}
void	put_dai2(void)
{
	uchar	c,s[512],*sw;
	uint	num,woff;
	debug(" put_dai2");
	varmin = varmax;
	woff = off;
	tab();
	sputs("<");
	if (pass)	tabcnt++;
	set_flg(off,1);
	off++;
	if (*TOPP>=0xc0)	{
		num = (*TOPP - 0xc0)*256;
		set_flg(off,1);
		off++;
		if (num==0 && *TOPP == 1)	{	/* �z�� */
			set_flg(off,3);
			off++;
			num = *TOPP * 256;
			off++;
			sputsi("VAR%04d[",num = num + *TOPP);
			off++;
			if (put_rpo(woff)==0)	return;
			if (varmax < num)	varmax = num;
			sputs("]:");
			goto	sk;
		}
		else	sputsi("VAR%04d:",num = num + *TOPP);
		if (varmax < num)	varmax = num;
	}
	else	{
		sputsi("VAR%04d,",num = (uint)*TOPP - 0x80);
		if (varmax < num)	varmax = num;
	}
	set_flg(off,1);
	off++;
sk:	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}
	sputs(",");
	set_flg(off,8);
	off += 8;
	sw = str;
	swait++;
	str = s;
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* �ϐ� */
	swait--;
	str = sw;
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 3 */
	sputs(",");
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)	{
		varmax = varmin;
		return;
	}	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_jyo(void)
{
	uchar	c;
	uint	adr,wk,woff;
	woff = off;
	debug(" put_jyo");
	tab();
	if (pass)	tabcnt++;
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)	return;
	sputs(":");
	adr = *TOPP;
	set_flg(off,4);
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	set_adr(adr);
	dump16(buf,woff,off - woff);
}
void	put_jyo2(void)
{
	uchar	c;
	uint	adr,woff;
	woff = off;
	debug(" put_jyo2");
	tab();
	if (pass)	tabcnt++;
	sputs("<@");
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)	return;
	sputs(":");
	set_flg(off,4);
	off++;
	off++;
	off++;
	off++;
	dump16(buf,woff,off - woff);
}
void	put_goto(void)
{	/* �W�����v���ߓW�J */
	uint	adr,wk,woff;
	woff = off;
	debug(" put_goto");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr == 0)	{
		sputs("0:");
	}
	else	{
		if (pass==0)	{
			if (adr >= (uint)len)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			} 
		}
		else	if (adr >= (uint)len)	{
			dump_err(buf,woff,off - woff);
			usage("�W�����v�A�h���X�s��");
		}
		set_label_adr(adr);
		sputsi("L_%05x:",adr);
	}
	dump16(buf,woff,off - woff);
}
void	put_label(void)
{	/* ���x���̓W�J */
	uint	adr,woff;
	woff = off;
	debug(" put_label");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (pass==0)	{
		if (adr >= (uint)len)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		} 
	}
	else	if (adr >= (uint)len)	{
		dump_err(buf,woff,off - woff);
		usage("���x���A�h���X�s��");
	}
	sputsi("D_%05x,",adr);
	if (put_rpo(woff)==0)	return;
	set_data_adr(adr);
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_call(void)
{	/* �֐��R�[���� */
	uint	adr,wk,lib,libwk,lenwk,woff;
	uchar	*bufwk,*fbufwk,*s;
	woff = off;
	debug(" put_call");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,3);
	off++;
	lib = *TOPP;
	off++;
	lib += *TOPP*256;
	off++;
	if (lib == 0xffff)	{
		sputs("~");
		if (put_rpo(woff)==0)	return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	if (lib == 0)	{
		sputs("0,");
		if (put_rpo(woff)==0)	return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	adr = *TOPP;
	set_flg(off,4);
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr == 0)	{
		sputs("0:");
		dump16(buf,woff,off - woff);
		return;
	}
	else	{
		if (pass==0)	{
			libwk = libcnt;
			wk = off;
			bufwk = buf;
			fbufwk = fbuf;
			lenwk = len;
			if (libcnt != lib)	{
				libcnt = lib;
				if (get_block()==0)	{
					libcnt = libwk;
					buf = bufwk;
					fbuf = fbufwk;
					len = lenwk;
					off = wk;
					reset_flg(woff,off - woff);
					off = len;
					return;	/* �u���b�N�Ȃ� */
				}
			}
			off = adr;
			if ((uint)off >= (uint)len)	{
				libcnt = libwk;
				buf = bufwk;
				fbuf = fbufwk;
				len = lenwk;
				off = wk;
				reset_flg(woff,off - woff);
				off = len;
				return;	/* ��ѐ�Ȃ� */
			}
			off = wk;
			libcnt = libwk;
			buf = bufwk;
			fbuf = fbufwk;
			len = lenwk;
		}
		set_call_adr(adr,lib);
		sputsi("F_%05x_",adr);
		s = get_adv_name(lib);
		if (s != 0)	sputsc("%s:",s);
		else	{
			dump_err(buf,woff,off - woff);
			usage("��ѐ�y�[�W�Ȃ�");
		}
	}
	dump16(buf,woff,off - woff);
}
void	put_sen(void)
{	/* �I�����\�� */
	uint	adr,wk,woff;
	if (sen_mode)	{
		sen_mode = 0;
		set_flg(off,1);
		off++;
		sputs("$");
		return;
	}
	woff = off;
	debug(" put_sen");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (pass==0)	{
		if (adr >= (uint)len)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		} 
	}
	else	if (adr >= (uint)len)	{
		dump_err(buf,woff,off - woff);
		usage("�I�����A�h���X�s��");
	}
	set_label_adr(adr);
	sputsi("L_%05x$",adr);
	dump16(buf,woff,off - woff);
	sen_mode = 1;
}
void	put_b(void)
{	/* B�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_b");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%d,",c);
	switch(c)	{
	case	1:
	case	2:
	case	3:
	case	4:
		if (put_rpo(woff)==0)	return;
		sputs(",");
		if (put_rpo(woff)==0)	return;
		sputs(",");
		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	21:
	case	22:
	case	23:
	case	24:
	case	31:
	case	32:
	case	33:
	case	34:

		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	10:
	case	11:
		if (put_rpo(woff)==0)	return;
		sputs(",");
	case	0:
		if (put_rpo(woff)==0)	return;
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_c(void)
{	/* C�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_c");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'K':
		if (*TOPP>=4 || *TOPP == 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'D':
		if (put_rpo(woff)==0)	return;	/* 10 */
		sputs(",");
	case	'E':
	case	'M':
		if (put_rpo(woff)==0)	return;	/* 9 */
		sputs(",");
	case	'K':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
	case	'C':
	case	'U':
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
	case	'B':
	case	'F':
	case	'L':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'P':
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_d(void)
{	/* D�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_d");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'C':
	case	'F':
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_e(void)
{	/* C�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_e");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_f(void)
{	/* F�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_f");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c>=8 || c==0)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
	}
	sputsi("%d ",c);
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_g(void)
{	/* G�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_g");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c >= 0x40)	sputsi("%c ",c);
	else	sputs(" ");
	switch(c)	{
	case	'X':
	case	'S':
	case	1:
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	0:
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_h(void)
{	/* H�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_h");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi(" %d,",c);
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_i(void)
{	/* I�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_i");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'K':
		if (*TOPP >= 7)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'G':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
	case	'M':
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'X':
	case	'Y':
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	'K':
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_j(void)
{	/* J�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff= off;
	debug(" put_j");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c < 0x40)	sputsi("%d",c);
	if (c>=5)	{
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
	}
	switch(c)	{
	case	0:
	case	1:
	case	2:
	case	3:
		sputs(" ");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	4:
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_k(void)
{	/* K�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_k");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'Q':
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'K':
	case	'N':
	case	'P':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_l(void)
{	/* L�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_l");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if ((c == 'H')|| (c == 'X'))
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'L':
		if (*TOPP != 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'E':
		if (*TOPP > 1)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = woff;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				return;
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'H':
		sputsi("%c ",*TOPP);
		set_flg(off,1);
		off++;
		if (*TOPP > 3 || *TOPP == 0)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'X':
		c = *TOPP;
		sputsi("%c ",c);
		set_flg(off,1);
		off++;
		switch (c)	{
		case	'G':
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			put_str();	/* 2 */
			sputs(",");
			put_str();	/* 1 */
			sputs(":");
			break;
		case	'O':
		case	'L':
		case	'S':
		case	'P':
		case	'R':
		case	'W':
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		case	'C':
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'E':
		put_str();	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	case	'L':	
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'D':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_m(void)
{	/* M�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_m");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'G':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'N':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'T':
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'E':
	case	'J':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
	case	'F':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'D':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'A':
	case	'C':
	case	'L':
	case	'M':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_n(void)
{	/* N�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_n");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if (c == 'D')
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'D':
		sputsi("%c ",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch(c)	{
		case	'+':
		case	'-':
		case	'*':
		case	'/':
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	'A':
		case	'H':
		case	'C':
		case	'D':
		case	'M':
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	case	'O':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'T':
		put_str();	/* 1 */
		sputs(":");
		break;
	case	'I':
	case	'<':
	case	'>':
	case	'=':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'B':
	case	'+':
	case	'-':
	case	'*':
	case	'/':
	case	'&':
	case	'|':
	case	'^':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
	case	'R':
	case	'\\':
	case	'~':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_p(void)
{	/* P�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_p");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'F':
	case	'W':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	2:
		case	3:
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	0:
		case	1:
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	case	'T':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	1:
			if (put_rpo(woff)==0)   return;	/* 5 */
			sputs(",");
		case	2:
			if (put_rpo(woff)==0)   return;	/* 4 */
			sputs(",");
		case	0:
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'G':
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'D':
	case	'N':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_q(void)
{	/* Q�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_q");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'E':
		if (*TOPP > 1)	{
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = woff;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				off = woff;
				return;
			}
		}
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		put_str();	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'P':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'D':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_s(void)
{	/* S�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_s");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'I':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	case	'G':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'X':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		sputsi("%d",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	1:
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 2 */
		case	2:
		case	4:
			sputs(",");
			if (put_rpo(woff)==0)   return;	/* 1 */
		case	3:
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
			}
			break;
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'Q':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'U':
	case	'P':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'L':
	case	'M':
	case	'O':
	case	'S':
	case	'T':
	case	'I':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
}
void	put_tx(void)
{	/* T&X�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_tx");
	tab();
	sputsi("%c ",c = *TOPP);
	set_flg(off,1);
	off++;
	switch (c)	{
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
	}
	dump16(buf,woff,off - woff);
}
void	put_u(void)
{	/* U�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_u");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'C':
	case	'P':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'P':
		put_str();	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'S':
	case	'G':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'C':
	case	'D':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_v(void)
{	/* V�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_v");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	if ((c == 'I')||(c == 'F'))
		sputsi("%c",c);
	else
		sputsi("%c ",c);
	switch(c)	{
	case	'I':
		sputsi("%c ",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	case	'A':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++; 
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'T':
		if (put_rpo(woff)==0)   return;	/* 10 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 9 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 8 */
		sputs(",");
	case	'B':
	case	'C':
		if (put_rpo(woff)==0)   return;	/* 7 */
		sputs(",");
	case	'E':
	case	'P':
	case	'H':
		if (put_rpo(woff)==0)   return;	/* 6 */
		sputs(",");
	case	'S':
		if (put_rpo(woff)==0)   return;	/* 5 */
		sputs(",");
	case	'G':
	case	'J':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'W':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
	case	'V':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 1 */
	case	'F':
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_w(void)
{	/* W�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_w");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'Z':
		sputsi("%d,",*TOPP);
		set_flg(off,1);
		off++;
		break;
	}
	switch(c)	{
	case	'V':
	case	'X':
		if (put_rpo(woff)==0)   return;	/* 4 */
		sputs(",");
	case	'W':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
		}
		break;
	}	
	dump16(buf,woff,off - woff);
}
void	put_z(void)
{	/* Z�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_z");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,2);
	off++;
	c = *TOPP;
	off++;
	sputsi("%c ",c);
	switch(c)	{
	case	'A':
	case	'D':
		sputsi("%d,",c = *TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		return;
	case	'K':
		if (put_rpo(woff)==0)   return;	/* 3 */
		sputs(",");
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
		put_str();	/* 1 */
		sputs(":");
		return;
	case	'Z':
		sputsi("%d,",c = *TOPP);
		set_flg(off,1);
		off++;
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		return;
	case	'T':
		sputsi("%d,",*TOPP);
		c = *TOPP;
		set_flg(off,1);
		off++;
		switch (c)	{
		case	10:
			if (put_rpo(woff)==0)   return;	/* 3 */
			sputs(",");
		case	11:
			if (put_rpo(woff)==0)   return;	/* 2 */
			sputs(",");
		case	0:
		case	1:
		case	2:
		case	3:
		case	4:
		case	5:
			if (put_rpo(woff)==0)   return;	/* 1 */
			sputs(":");
			break;
		default:	/* �R�}���h�G���[ */
			if (pass==0)	{
				reset_flg(woff,off - woff);
				off = len;
				return;
			}
			else	{
				dump_err(buf,woff,off - woff);
				usage("�R�}���h�G���[");
				return;
			}
		}
		dump16(buf,woff,off - woff);
		return;
	}
	switch(c)	{
	case	'C':
	case	'I':
	case	'R':
		if (put_rpo(woff)==0)   return;	/* 2 */
		sputs(",");
	case	'A':
	case	'B':
	case	'D':
	case	'E':
	case	'F':
	case	'G':
	case	'H':
	case	'L':
	case	'M':
	case	'S':
	case	'W':
	case	'Z':
		if (put_rpo(woff)==0)   return;	/* 1 */
		sputs(":");
		break;
	default:	/* �R�}���h�G���[ */
		if (pass==0)	{
			reset_flg(woff,off - woff);
			off = len;
			return;
		}
		else	{
			dump_err(buf,woff,off - woff);
			usage("�R�}���h�G���[");
			return;
		}
	}	
	dump16(buf,woff,off - woff);
}
void	put_y(void)
{	/* Y�n���ߓW�J */
	uchar	c;
	uint	woff;
	woff = off;
	debug(" put_y");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	copy_adv_name(uchar *dp,uchar *sp)
{	/* ADV�t�@�C�������쐬���� */
	int	cnt;
	cnt = 0;
	while (*sp  != 0)	{
		if ((sp[0] == '.') && (toupper(sp[1]) == 'A')
		&& (toupper(sp[2]) == 'D') && (toupper(sp[3]) == 'V'))	{
			strcpy(dp,".ADV");
			return;
		}
		*dp++ = *sp++;
		cnt++;
		if (cnt >= 128)	usage("�\�[�X�t�@�C�������擾�ł��Ȃ�");
	}
}
uchar	*get_adv_name(uint num)
{	/* ALD�t�@�C������NUM�Ԗڂ�ADV�t�@�C�����𓾂� */
	uint	start,ap,mp;
	debug(" get_adv_name");
	mp = ald_buf[0];
	mp += ald_buf[1]*256;
	mp += ald_buf[2]*256*256;
	mp = mp*256;			/* ײ���ؔԍ�ð��قւ̵̾�Ă𓾂� */
	if (num * 3 >= mp)	return	0;	/* �e�[�u���O */
	
retry:	ap = ald_buf[num*3];
	ap += ald_buf[num*3+1]*256;
	ap += ald_buf[num*3+2]*256*256;
	ap = ap*256;			/* ײ����ͯ�ނւ̵̾�Ă𓾂� */
	if (ap == 0)	return	0;
	start = ald_buf[ap];
	start += ald_buf[ap+1]*256;
	start += ald_buf[ap+2]*256*256;
	start += ald_buf[ap+3]*256*256*256;
	if (start > 0x30)	return	0;
	copy_adv_name(advname,ald_buf+ap+start+18);
	return	advname;
}
void	put_advjp(void)
{	/* �y�[�W�R�[���y�[�W�W�����v�n���߂̓W�J */
	uchar	*s;
	uint	c;
	uint	num;
	uint	woff;
	uint	wk,libwk,lenwk;
	uchar	*bufwk,*fbufwk;
	woff = off;
	debug(" put_advjp");
	tab();
	sputsi("%c",*TOPP);
	set_flg(off,1);
	off++;
	c = *TOPP;
	if (c>=0x80)	{
		if (put_rpo(woff)==0)   return;
		sputs(":");
		dump16(buf,woff,off - woff);
		return;
	}	
	if (c>=0x40)	{
		num = c - 0x40;
	}	
	else	{
		set_flg(off,1);
		off++;
		num = c * 256 + *TOPP;
	}
	if (num == 0)	{
		sputs("0");
	}
	else	{
		num++;
		s = get_adv_name(num);
		if (s == 0)	sputsi("%d",num-1);
		else		sputsc("#%s",s);
	}
	set_flg(off,1);
	off++;
	set_flg(off,1);
	off++;
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_loop(void)
{	/* LOOP���ߓW�J */
	uchar	c,s[256],*sw;
	uint	num;
	uint	woff;
	woff = off;
	debug(" put_loop");
	if (pass)	tabcnt++;
	set_flg(off,8);
	off +=8;
	sw = str;
	swait++;
	str = s;
	if (put_rpo(woff)==0)   return;	/* �ϐ� */
	swait--;
	str = sw;
	if (put_rpo(woff)==0)   return;	/* 3 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 2 */
	sputs(",");
	if (put_rpo(woff)==0)   return;	/* 1 */
	sputs(":");
	dump16(buf,woff,off - woff);
}
void	put_loop_end(void)
{	/* LOOP END���ߓW�J */
	uchar	c;
	uint	adr,wk;
	uint	woff;
	woff = off;
	debugi("\nput_loop_end off = %x",off);
	set_flg(off,5);
	off++;
	adr = *TOPP;
	off++;
	adr += *TOPP*256;
	off++;
	adr += *TOPP*256*256;
	off++;
	adr += *TOPP*256*256*256;
	off++;
	if (adr >= (uint)len)	{
		reset_flg(woff,off - woff);
		off = len;
		if (pass == 0)	return;
		dump_err(buf,woff,off - woff);
		usage("���[�v�G���h���������ȃA�h���X�������Ă���");
		return;
	}
	set_loop_adr(adr);
	if (pass)	tabcnt--;
	tab();
	sputs(">");
	dump16(buf,woff,off - woff);
}
int	data_fld_kanji(int f)
{	/* �����f�[�^���`�F�b�N���W�J���� */
	uint	c,wk,cnt,lp;
	uchar	*kana;
/*	debug(" data_fld_kanji");	*/
	cnt = 0;
	wk = off;
loop:	if (kanji_chk(*TOPP) && fbuf[off] == 0)	{
		off++;
		if (kanji_chk2(*TOPP) && fbuf[off] == 0) {
			cnt+=2;	/* �Q�o�C�g�R�[�h */
			off++;
			goto	loop;
		}
		else	{	/* �Q�o�C�g�ڂ��s�� */
			off = wk;
			return	0;
		}
	}
	else
	if (kana_chk(*TOPP) && fbuf[off] == 0)	{
		cnt++;	/* �P�o�C�g�J�i�R�[�h */
		off++;
		goto	loop;
	}
	if (*TOPP != 0 || fbuf[off] != 0 || off >= len)	{
		off = wk;
		return	0;
	}
	off = wk;
	if (f==0)	return	cnt;

	if (cnt)	{
		sputs("\n");
		tab();
		sputs("\"");
		for (lp=0;lp<cnt;lp++)	{
			if (f)	{
				if (kanji_chk(*TOPP))	{
					sputsi("%c",*TOPP);
					off++;
					lp++;
					sputsi("%c",*TOPP);
				}
				else
				if (kana_chk(*TOPP))	{
					kana = kana_zen(*TOPP);
					sputsi("%c",*kana);
					sputsi("%c",*(kana+1));
				}
				else	sputsi("%c",*TOPP);
			}
			off++;
		}
		off++;
		sputs("\"");
		dump16(buf,wk,off-wk);
	}
	return	cnt;
}
int	data_fld_kanjip(int f)
{	/* �����\���R�}���h��W�J���� */
	uint	c,wk,cnt,lp,lp2,cnt2;
	uint	woff,ioff;
	uchar	*kana;
/*	debugi("\ndata_fld_kanjip f = %d",f);	*/
	cnt = 0;
	wk = off;
	kanji_flg = 0;
loop:	if (kanji_chk(*TOPP))	{
		off++;
		if (kanji_chk2(*TOPP)) {
			cnt+=2;	/* �Q�o�C�g�R�[�h */
			off++;
			goto	loop;
		}
		else	{	/* �Q�o�C�g�ڂ��s�� */
			off = wk;
			return	0;
		}
	}
	else
	if (kana_chk(*TOPP))	{
		cnt++;	/* �P�o�C�g�J�i�R�[�h */
		off++;
		goto	loop;
	}
	if (*TOPP == 0 && off < len)	{
		off = wk;
		return	0;
	}
	if (cnt && pass==1 && fbuf[off]==0)	{
		memset(fbuf+wk,0,off - wk);
		off = wk;
		kanji_flg = wk;
		return	0;
	}
	off = wk;
	if (f==0)	return	cnt;
	if (cnt)	{
		woff = off;
		tab();
		sputs("'");
		for (lp=0;lp<cnt;lp++)	{
			if ((cnt2 = chk_adr(off))!=0)	{
				sputs("'");
				dump16(buf,woff,off-woff);
				sputs("\n");
				for (lp2=0;lp2<cnt2;lp2++)	{
					if (pass)	tabcnt--;
					tab();
					sputs("}\n");
				}
				del_adr(off);
				tab();
				sputs("'");
				woff = off;
			}	
			if (kanji_chk(*TOPP))	{
				sputsi("%c",*TOPP);
				set_flg(off,1);
				off++;
				lp++;
				sputsi("%c",*TOPP);
			}
			else
			if (kana_chk(*TOPP))	{
				kana = kana_zen(*TOPP);
				sputsi("%c",*kana);
				sputsi("%c",*(kana+1));
			}
			else	sputsi("%c",*TOPP);
			set_flg(off,1);
			off++;
		}
		sputs("'");
		dump16(buf,woff,off-woff);
	}
	return	cnt;
}
void	data_fld(void)
{	/* �f�[�^�t�B�[���h��W�J���� */
	uint	c,f,cnt,wk,lp,adr,adrf;
	int	woff;
/*	debug(" data_fld");	*/
	woff = off;
	f = 0;
	cnt = 0;	
	adrf = 0;
	do	{
		if (off >= len)	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		if (chk_data_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			sputsi("\n*D_%05x:\n",off);
			adrf = 1;
			f = 0;
			cnt = 0;
		}
		else
		if (chk_label_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			sputsi("\n*L_%05x:\n",off);
			adrf = 0;
			f = 0;
			cnt = 0;
		}
		if (fbuf[off]==1)	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off-woff);
			}
			return;
		}
		c = *TOPP;
		off++;
		if (chk_data_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		else
		if (chk_label_adr(off))	{
			if (cnt>0)	{
				sputs("]");
				dump16(buf,woff,off - woff);
			}
			return;
		}
		c += *TOPP*256;
		off++;
		adr = c + *TOPP*256*256;
		off++;
		adr += *TOPP*256*256*256;
		off++;
		if (adr >= (uint)offtop && adr<(uint)len)	{
			if ((adrf == 1) && (fbuf[adr] == 0))	{
				if (cnt != 0)	{
					sputs("]");
					dump16(buf,woff,off - woff);
				}
				cnt = 0;
				f = 0;
				tab();
				sputsi("_D_%05x:\n",adr);
				set_data_adr(adr);
				dump16(buf,off-4,4);
				continue;
			}
		}
		else	{
			off -= 4;
			if (data_fld_kanji(0)>=2)	{	/* ������`�F�b�N */
				if (cnt>0)	{
					sputs("]");
					dump16(buf,woff,off-woff);
				}
				data_fld_kanji(1);	/* �����񏑂����� */
				cnt = 0;
				f = 0;
				adrf = 0;
				continue;
			}
			off += 4;
		}
		adrf = 0;
		off -=2;
		if (cnt == 0)	{
			sputs("\n");
			tab();
			sputs("[");
			woff = off - 2;
		}
		if (f)	sputs(",");
		else	f = 1;
		sputsi("%d",c);
		cnt++;
		if (cnt >= 8)	{
			sputs("]");
			dump16(buf,woff,off - woff);
			f = 0;
			cnt = 0;
		}
	}	while (fbuf[off] == 0);
	if (cnt>0)	{
		sputs("]\n");
		dump16(buf,woff,off - woff);
	}
}
int	chk_dump(void)
{	/* ��ѐ���v���O�����G���A�Ƃ݂Ȃ��`�F�b�N���� */
	int	woff;
	woff = off;
	if (chk_label_adr(off))	{
		dump();
		if (fbuf[woff]==0)	{
			printf("\nlabel error pre = %d",pre);
			dump_err(buf,woff,32);
		}
		off = woff;
		return	1;
	}
	if (chk_call_adr(off,libcnt))	{
		dump();
		if (fbuf[woff]==0)	{
			printf("\ncall error pre = %d",pre);
			dump_err(buf,woff,32);
		}
		off = woff;
		return	1;
	}
	return	0;
}
void	data_fld_adr_set(void)
{	/* �v���O�����G���A�ƃf�[�^�G���A���\�Ȍ��蕪������ */
	debug(" data_fld_adr_set");
top:	while (fbuf[off]==1 && off <len)	off++;
	if (off >= len)	return;
	if (chk_dump())	goto	top;
	off++;
	if (off >= len)	return;
	goto	top;
}
void	chk_adr_all(void)
{	/* �e��A�h���X���`�F�b�N�B�K�v�Ȃ烉�x�����̑��𐶐����� */
	uchar	*s;
	int	lp,cnt;
	if ((cnt = chk_adr(off))!=0)	{
		for (lp=0;lp<cnt;lp++)	{
			if (pass)	tabcnt--;
			tab();
			sputs("}");
			if (sen_mode==0)	sputs("\n");
		}
		del_adr(off);
	}	
	if (chk_call_adr(off,libcnt))	{
		sputsi("\n**F_%05x_",off);
		s = get_adv_name(libcnt);
		if (s != 0)	sputsc("%s:\n",s);
		else		usage("��ѐ�y�[�W�s��");
	}
	if (chk_label_adr(off))	{
		sputsi("\n*L_%05x:\n",off);
	}
	if (chk_data_adr(off))	{
		sputsi("\n*D_%05x:\n",off);
	}
}
void	dump_sub(void)
{	/* �t�R���p�C���@���ߒP�ʂ̓W�J */
	uint	lp,c,cnt,woff,ioff;
	int	pf,dp;
	uchar	*s;
	if (sen_mode==0)	sputs("\n");
	if (pass)	{ 
		if (fbuf[off] == 0)	{
			ioff = off;
			data_fld();
			if (off >= len)	return;
			if ((uint)off != ioff)	return;
		}
	}
	else	{
		if (fbuf[off] == 1)	{
			off =len;
			return;
		} 
	}
	ioff = off;
	c = *TOPP;
	if (data_fld_kanjip(0))	{	/* ������`�F�b�N */
		chk_adr_all();
		data_fld_kanjip(1);	/* �����񏑂����� */
		return;
	}
	if (kanji_flg)	{
		if (fbuf[off] == 0)	{
			data_fld();
		}
		return;
	}
	chk_adr_all();
	switch (c)	{
	case	']':
	case	'A':
	case	'R':
		put_1();
		break;
	case	'B':
		put_b();
		break;
	case	'C':
		put_c();
		break;
	case	'D':
		put_d();
		break;
	case	'E':
		put_e();
		break;
	case	'F':
		put_f();
		break;
	case	'G':
		put_g();
		break;
	case	'H':
		put_h();
		break;
	case	'I':
		put_i();
		break;
	case	'J':
		put_j();
		break;
	case	'K':
		put_k();
		break;
	case	'L':
		put_l();
		break;
	case	'M':
		put_m();
		break;
	case	'N':
		put_n();
		break;
	case	'P':
		put_p();
		break;
	case	'Q':
		put_q();
		break;
	case	'S':
		put_s();
		break;
	case	'T':
	case	'X':
		put_tx();
		break;
	case	'U':
		put_u();
		break;
	case	'V':
		put_v();
		break;
	case	'W':
		put_w();
		break;
	case	'Y':
		put_y();
		break;
	case	'Z':
		put_z();
		break;
	case	'!':
		if (chk_loop_adr(off))	{
			put_dai2();
		}
		else	put_dai();
		break;
	case	'{':
		if (chk_loop_adr(off))	{
			put_jyo2();
		}
		else	put_jyo();
		break;
	case	'$':
		put_sen();
		break;
	case	'@':
	case	'\\':
		put_goto();
		break;
	case	'~':
		put_call();
		break;
	case	'#':
		put_label();
		break;
	case	'&':
	case	'%':
		put_advjp();
		break;
	case	'<':
		put_loop();
		break;
	case	'>':
		put_loop_end();
		break;
	default:
		if (pass == 0)	{
			off = len; 
			return;
		}
		woff = off;
		do	{
			fbuf[off] = 0;
			if (*TOPP == 0x7f)	break;
			off++;
		}	while(fbuf[off] == 1 && off < len);
		off = woff;
		sputs("\n");
		return;
	}
	if (pass == 0 && ioff == (uint)off)	{	/* �R�}���h�G���[ */
		off = len;
		return;
	}
	if (pass == 1 && ioff == (uint)off)	{	/* �R�}���h�G���[ */
		if (off < len)	fbuf[off] = 0;
	}
}
void	dump_flg(uchar *p,int woff,int byte)
{	/* �����t���O�_���v���X�g */
	int	lp;
	uint	c;
	if (dump_mode==0)	return;
	p = fbuf;
	p += woff;
	sputsi("\n;F A:%06x-",p - ald_flg);
	sputsi("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		sputsi("%02x ",*(p+lp));
	}
	sputs(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				sputsi("%c",c);
				sputsi("%c",*(p+lp));
			}
			else	sputs(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	sputsi("%c",c);
			else	sputs(".");
		}
	}
/*	sputs("\n");	*/
}
void	dump_flg_err(uchar *p,int woff,int byte)
{	/* �G���[�������t���O�_���v���X�g */
	int	lp;
	uint	c;
	p = fbuf;
	p += woff;
	printf("\n;ERR F A:%06x-",p - ald_flg);
	printf("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		printf("%02x ",*(p+lp));
	}
	printf(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				printf("%c",c);
				printf("%c",*(p+lp));
			}
			else	printf(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	printf("%c",c);
			else	printf(".");
		}
	}
	printf("\n");
}
void	dump16(uchar *p,int woff,int byte)
{	/* �f�[�^�_���v���X�g */
	int	lp;
	uint	c;
	dump_flg(p,woff,byte);
	if (dump_mode==0)	return;
	p += woff;
	sputsi("\n;D A:%06x-",p - ald_buf);
	sputsi("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		sputsi("%02x ",*(p+lp));
	}
	sputs(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				sputsi("%c",c);
				sputsi("%c",*(p+lp));
			}
			else	sputs(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	sputsi("%c",c);
			else	sputs(".");
		}
	}
	sputs("\n");
}
void	dump_err(uchar *p,int woff,int byte)
{	/* �G���[���_���v���X�g(�����t���O�t��) */
	int	lp;
	uint	c;
	dump_flg_err(p,woff,byte);
	p += woff;
	printf("\n;ERR D A:%06x-",p - ald_buf);
	printf("S:%04x : ",woff);
	for (lp=0;lp<byte;lp++)	{
		printf("%02x ",*(p+lp));
	}
	printf(":");
	for (lp=0;lp<byte;lp++)	{
		c = *(p+lp);
		if (kanji_chk(c))	{
			if (kanji_chk2(*(p+lp+1)) && lp+1<byte)	{	
				lp++;
				printf("%c",c);
				printf("%c",*(p+lp));
			}
			else	printf(".");
		}
		else	{
			if ((c>=' ') && (c<0x7f))	printf("%c",c);
			else	printf(".");
		}
	}
	printf("\n");
}
void	dump(void)
{	/*�@�t�R���p�C�����t�@�C���̍Ō�܂ŌJ��Ԃ� */
	while (off < len)	{
		dump_sub();
	}		
}
int	get_block(void)
{	/* ALD�t�@�C������eSCO�t�@�C���̈ʒu��A�I�t�Z�b�g�𓾂� */
	uint	ap,byte,start,mp;
	uchar	*p;
	FILE	*sco;
	debugi("\nget_block lincnt = %d",libcnt);
	p = ald_buf;
	if (((p[0]=='S') && (p[1]=='3')&& (p[2]=='5') && (p[3]=='1'))
	|| ((p[0]=='1') && (p[1]=='5')&& (p[2]=='3') && (p[3]=='S')))	{
		if (libcnt >= 2)	return	0;
		
		off = ald_buf[4];
		off += ald_buf[5]*256;
		off += ald_buf[6]*256*256;
		off += ald_buf[7]*256*256*256;
		len = ald_len;
		buf = p;
		fbuf = ald_flg;
		offtop = off;
		return	1;
	}
	if (libcnt == 0)	return	0;

	mp = p[0];
	mp += p[1]*256;
	mp += p[2]*256*256;
	mp = mp*256;			/* ײ���ؔԍ�ð��قւ̵̾�Ă𓾂� */
	if (mp >= (uint)ald_len)	usage("�I�u�W�F�N�g�t�@�C���s��");
	if (libcnt * 3 >= mp)	return	0;	/* �e�[�u���O */

	ap = p[libcnt*3];
	ap += p[libcnt*3+1]*256;
	ap += p[libcnt*3+2]*256*256;
	ap = ap*256;			/* ײ����ͯ�ނւ̵̾�Ă𓾂� */
	if (ap == 0)	return	0;
	debugi("\nap = %08x ",ap);
	if ((p[ap]=='N')&&(p[ap+1]=='L'))	return	0;
	start = p[ap];
	start += p[ap+1]*256;
	start += p[ap+2]*256*256;
	start += p[ap+3]*256*256*256;	/* sco�t�@�C���ւ̃I�t�Z�b�g�𓾂� */
	if (start > 0x30)	return	0;
	debugi("\nstart = %x ",start);
	byte = p[ap+4];
	byte += p[ap+5]*256;
	byte += p[ap+6]*256*256;
	byte += p[ap+7]*256*256*256;	/* sco�t�@�C���̃o�C�g���𓾂� */
	debugi("\nbyte = %08x ",byte);
	off = p[ap+start+4];
	off += p[ap+start+5]*256;
	off += p[ap+start+6]*256*256;
	off += p[ap+start+7]*256*256*256;/* ��۸��ъJ�n�ʒu�ւ̵̾�Ă𓾂� */
	len = byte;
	buf = p+ap+start;
	fbuf = ald_flg+ap+start;
	offtop = off;
	copy_adv_name(advname,buf+18);
	name_set(advname,".SCO");
	if (pass == 1 && sco_mode==1)	{
		if( (sco=fopen(advname,"wb" ))==(FILE *)NULL )
			usage( "���I�u�W�F�N�g�t�@�C�����쐬�ł��܂���B\n" );
		if (fwrite(buf,sizeof(*buf),len,sco) < (size_t)len)
			usage( "���I�u�W�F�N�g�t�@�C���ɏ������߂܂���B\n" );
		fclose(sco);
		printf("\nCreate = %s  lib = %d",advname,libcnt);
	}
	return	1;
}
void	name_set(char *p,char *q)
{	/* �t�@�C���̊g���q���Z�b�g */
	while(*p != 0)	{
		if (*p == '.')	{
			strcpy(p,q);
			break;
		}
		p++;
	}
}
void	set_flg_allarea(int offset,int byte,int flg)
{	/* �����t���O���Z�b�g�����Z�b�g���� */
	int	lp;
	for (lp=0;lp<byte;lp++)	{
		ald_flg[offset+lp] = flg;
	}
}
void	pgm_data(uchar *name)
{	/* �v���O�����G���A���f�[�^�G���A���ăZ�b�g���� */
	int	fh,leng;
	char	buf[512],*p,c;
	int	start,end;
	if (*name == 0)	return;
	if( (fp3=fopen(name,"rt" ))==(FILE *)NULL )
		usage( "�A�h���X�t�@�C�����I�[�v���ł��܂���B\n" );
	while (fgets(buf,512,fp3)!=NULL)	{
		p = buf;
		sscanf(p+1,"%x,%x",&start,&end);
		if (start < offtop)	break;
		if (end < offtop)	break;
		if (start > ald_len)	break;
		if (end > ald_len)	break;
		c = tolower(*p);
		switch (c)	{
		case	'p':	/* �v���O�����G���A */
			set_flg_allarea(start,end - start + 1,1);
			break;
		case	'd':	/* �f�[�^�G���A */
			set_flg_allarea(start,end - start + 1,0);
			break;
		}
	}
	fclose(fp3);
}
int	main(int argc,char *argv[])
{
	int	fh,lp,cnt,non_hed;
	char	name[256],advname[256];

	printf("\nSYSTEM 3.5 & 3.6  DIS COMPILER Ver.1.07  By T.HASEGAWA\n");

      	if( argc < 2 )
		usage("�ǂݍ��݃t�@�C�����w�肵�ĉ�����\n");
	if( (fp=fopen(argv[1],"rb" ))==(FILE *)NULL )
		usage( "�t�@�C�����I�[�v���ł��܂���B\n" );
	fh = fileno( fp );
	ald_len=(uint)filelength(fh);
	ald_buf = chk_malloc(ald_len+32);
	ald_flg = chk_malloc(ald_len+32);
	memset(ald_flg,0,ald_len+32);
	if( (read( fh,(char *)(ald_buf),ald_len ))<(uint)1 )	{
		usage("�t�@�C�����ǂ߂܂���B\n");
	}
	fclose(fp);

	if( (fp2=fopen("DC36C.HED","wt" ))==(FILE *)NULL )
		usage( "�g�d�c�t�@�C�����I�[�v���ł��܂���B\n" );
	fprintf(fp2,"#SYSTEM35\n");

	dump_mode = 0;
	debug_mode = 0;
	pre_mode = 0;
	non_hed = 0;
	name[0] = 0;
	sco_mode = 0;
	for (lp=2;lp<argc;lp++)	{
		switch (tolower(*argv[lp]))	{
		case	't':	debug_mode = 1;break;
		case	'd':	dump_mode = 1;break;
		case	'p':	pre_mode = 1;break;
		case	'a':	strcpy(name,argv[lp]+1);break;
		case	'n':	non_hed = 1;break;
		case	's':	sco_mode = 1;break;
		}
	}

	adr_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* if goto address */

	label_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	label_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);/* label address */
	memset(label_buf,0,sizeof(uint)*MAXTBL);
	memset(label_lib_buf,0,sizeof(uint)*MAXTBL);

	data_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	data_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* label address */
	memset(data_buf,0,sizeof(uint)*MAXTBL);
	memset(data_lib_buf,0,sizeof(uint)*MAXTBL);

	loop_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* loop address */
	loop_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* loop address */
	memset(loop_buf,0,sizeof(uint)*MAXTBL);
	memset(loop_lib_buf,0,sizeof(uint)*MAXTBL);

	call_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* call address */
	call_lib_buf = chk_malloc(sizeof(uint)*MAXTBL);	/* call address */
	memset(call_buf,0,sizeof(uint)*MAXTBL);
	memset(call_lib_buf,0,sizeof(uint)*MAXTBL);

	str = 0;				/* string buff address */

	libcnt = 1;	/* ���C�u�����ԍ� */
	callp = 0;	/* call buffer address offset */
	errcnt = 0;

	varmax = 0;	/* �ϐ��ő吔 */

	labelp = 0;	/* label buffer address offset */
	datap = 0;	/* data buffer address offset */
	loopp = 0;	/* loop buffer address offset */
	pass = 0;	/* pass run */
	swait = 0;	/* ������o�͈ꎞ��~ */
	sen_mode = 0;	/* �I�������W�J���[�h */

	adrp = 0;	/* buff address offset */ 
	tabcnt = 1;	/* �C���f���gTAB�� */

	pre = 0;	/* �v���X�L�����J�E���^�[ */
	kanji_flg = 0;	/* �����t���O */

next:	if (get_block()==0)	{
		if (pre <= 1)	{
			pre++;
			libcnt = 1;
			adrp = 0;
			goto	next;
		}
		if (pass == 0)	{
			debug(" pass = 1");
			libcnt = 1;
			adrp = 0;
			pgm_data(name);
			pass = 1;
			goto	next;
		}
		fclose(fp2);
		if (name[0] != 0 && pre == 2)	{
			pre++;
			libcnt = 1;
			adrp = 0;
			if( (fp2=fopen("DC36C.HED","wt" ))==(FILE *)NULL )
				usage( "�g�d�c�t�@�C�����I�[�v���ł��܂���B\n" );
			fprintf(fp2,"#SYSTEM35\n");
			goto	next;
		}
		return	0;
	}
	if (pass == 0 && pre == 0)	{
		off = offtop;
		dump();
		off = offtop;
		data_fld_adr_set();
		libcnt++;
		goto	next;
	}
	if (pass == 0)	{
		off = offtop;
		data_fld_adr_set();
		libcnt++;
		goto	next;
	}
	copy_adv_name(advname,buf+18);
	if( (fp=fopen(advname,"wt" ))==(FILE *)NULL )
		usage( "�V�i���I�t�@�C�����쐬�ł��܂���B\n" );
	fprintf(fp2,"%s\n",advname);
	printf("\nCreate = %s  lib = %d",advname,libcnt);
	sputsc(";name : %s\n",advname);
	sputsi(";lib  : %d\n",libcnt);
	if (libcnt == 1 && non_hed==0)	{
		for (lp=0;lp<(int)varmax;lp++)	{
			sputsi("\t!VAR%04d:0!\n",lp);
		}
	}
	adrp = 0;	/* buff address offset */ 
	tabcnt = 1;
	dump();
	sputs("\n");
	chk_adr_all();
	if (pre==2)	{
		pass=0;
		off = offtop;
		data_fld_adr_set();
		pass=1;
	}
	fclose(fp);
	libcnt++;
	goto	next;
}
