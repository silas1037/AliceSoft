﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExTransAssist
{
    public class exString
    {
        private string[] str;
        private int[] pos;
        private int[] addlen;
        private int total;

        public exString()
        {
            total = 0;
        }
        public exString(int num)
        {
            total = num;
            str = new string[num];
            pos = new int[num];
            addlen = new int[num];

        }

        public void setString(int i,string strIn,int position,int addlength)
        {
            str[i] = strIn;
            pos[i] = position;
            addlen[i] = addlength;
        }

        public void setStr(int i, string strIn)
        {
            str[i] = strIn;
        }

        public void setPos(int i, int posi)
        {
            pos[i] = posi;
        }
        public void addLength(int i, int addl)
        {
            addlen[i] += addl;
        }

        public string getString(int i)
        {
            return str[i];
        }

        public int getPosition(int i)
        {
            return pos[i];
        }

        public int getAddlen(int i)
        {
            return addlen[i];
        }

        public int getTotal()
        {
            return total;
        }

        public string stringAtPosition(int position)
        {
            string tmp = null;
            for(int i=0; i<total; i++)
            {
                if (pos[i] == position)
                {
                    tmp = str[i];
                    break;
                }
            }
            return tmp;
        }

        public int posOfString(string stringIn)
        {
            int tmpPos = -1;
            for (int i = 0; i < total; i++)
            {
                if (str[i] == stringIn)
                {
                    tmpPos = pos[i];
                    break;
                }
            }
            return tmpPos;
        }

        public void setTotal(int t)
        {
            total = t;
        }

    }
}
