﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ZLibNet;
using System.Runtime.InteropServices;


namespace ExTransAssist
{

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private byte[] table;   //decoding table

        private string filename;
        private string filenameend;
        private MemoryStream pms;

        private exString exstrings;

        private int block_total;
        private int[] block_pos;

        public static Encoding utf8 = Encoding.GetEncoding("utf-8");
        public static Encoding jis = Encoding.GetEncoding("shift-jis");


        private void MainForm_Load(object sender, EventArgs e)
        {
            tablize();  //decoding table init
        }

        private void tablize()
        {
            table = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                int tmpfor = i;
                int tmp = tmpfor;
                tmp = (tmp & 0x55) + ((tmp >> 1) & 0x55);
                tmp = (tmp & 0x33) + ((tmp >> 2) & 0x33);
                tmp = (tmp & 0x0F) + ((tmp >> 4) & 0x0F);
                if ((tmp & 0x01) == 0)
                {
                    tmpfor = ((tmpfor << (8 - tmp)) | (tmpfor >> tmp)) & 0xFF;
                }
                else
                {
                    tmpfor = ((tmpfor >> (8 - tmp)) | (tmpfor << tmp)) & 0xFF;
                }
                table[i] = (byte)tmpfor;
            }
        }

        private void openExFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "all files (*.*)|*.*|ex files (*.ex)|*.ex";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            var bytes = new byte[8 * 1024 * 1024];  //to store decompressed data
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                try
                {
                    if ((filename = openFileDialog1.FileName) != null)
                    {
                        filenameend = Path.GetFileNameWithoutExtension(filename);

                        Stream exfile = openFileDialog1.OpenFile();
                        var br = new BinaryReader(exfile, jis);
                        br.ReadBytes(16);   //ex head
                        block_total = br.ReadInt32();   //the total of data blocks
                        br.ReadBytes(4);    //data mark
                        int comlength = br.ReadInt32();
                        int uncomlength = br.ReadInt32();
                        var combytes = new byte[comlength];

                        for (int i = 0; i < comlength; i++) //decode
                        {
                            combytes[i] = table[br.ReadByte()];
                        }
                        bytes = Decompress(combytes, uncomlength, 0);   //decompress
                        br.Close();
                        exfile.Close();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                toolStripStatusLabel1.Text = "Unpacking " + filenameend + ".ex completed.";

            }

            if (pms != null)
            {
                pms.Close();
            }
            pms = new MemoryStream(bytes);  //store in a global
            var pbr = new BinaryReader(pms, jis);

            int pt = 0;
            //read position of data blocks
            pms.Position = 0;
            block_pos = new int[block_total];
            while (pms.Position >= 0 && pms.Position < pms.Length)
            {
                uint funcid = pbr.ReadUInt32();
                if (funcid < 0x20)
                {

                    int tmplength = pbr.ReadInt32();    //length of current block
                    block_pos[pt++] = (int)pms.Position;
                    pms.Position += tmplength;  //jump to next

                }
            }
            if (pt != block_total)
            {
                MessageBox.Show("Error with the total of blocks.");
                return;
            }


            //read strings
            pt = 0;
            pms.Position = 0;
            exstrings = new exString(256 * 256);
            while (pms.Position >= 0 && pms.Position < pms.Length)
            {
                uint funcid = pbr.ReadUInt32();
                if (funcid == 3)    //function ID of a string
                {
                    int length = pbr.ReadInt32();
                    if ((length % 4 != 0) || (length == 0)) continue;   //probably this 0x03 is a data byte, skip this

                    if (pbr.ReadInt32() == length - 4)  //a unique form of string, we mark it with "tur*"
                    {
                        length = length - 4;
                        if (length == 0) continue;
                        var postmp = (int)pms.Position - 4;
                        var tempb = pbr.ReadBytes(length);
                        int trulength = length;
                        for (int l = 0; l < 4; l++) //eat redundant 0x00
                        {
                            if (tempb[length - 4 + l] == 0x00)
                            {
                                trulength = length - 4 + l;
                                break;
                            }
                        }
                        var strtmp = "tur*" + jis.GetString(tempb, 0, trulength);   //add a mark "tur*"
                        exstrings.setString(pt, strtmp, postmp, 0);
                        pt++;
                    }
                    else    //usual form of string
                    {
                        pms.Position -= 4;
                        if (pbr.PeekChar() < 0x20)
                            continue;
                        var postmp = (int)pms.Position;
                        var tempb = pbr.ReadBytes(length);
                        int trulength = length;
                        for (int l = 0; l < 4; l++)
                        {
                            if (tempb[length - 4 + l] == 0x00)
                            {
                                trulength = length - 4 + l;
                                break;
                            }
                        }
                        var strtmp = jis.GetString(tempb, 0, trulength);
                        exstrings.setString(pt, strtmp, postmp, 0);
                        pt++;

                    }
                }
            }
            exstrings.setTotal(pt);

            //show string in textbox
            string texttoshow = "";
            for (int i = 0; i < exstrings.getTotal(); i++)
            {
                texttoshow += "s" + i + " " + exstrings.getString(i) + "\r\n";
            }
            textBox1.Text = texttoshow;

            saveExFileToolStripMenuItem.Enabled = true;
            outputDecodedExFileToolStripMenuItem.Enabled = true;
            extractStringOutToolStripMenuItem.Enabled = true;
            importStringInToolStripMenuItem.Enabled = true;

        }

        public byte[] Decompress(byte[] bytes, int size, int offset)
        {
            var msd = new MemoryStream(bytes);
            msd.Position = offset;
            ZLibStream zlibStream = new ZLibStream(msd, CompressionMode.Decompress, CompressionLevel.Level9);
            var brDeflate = new BinaryReader(zlibStream);
            try
            {
                return brDeflate.ReadBytes((int)size);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void saveExFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var pbr = new BinaryReader(pms, jis);
            int fileaddlength = (int)pms.Length;    //as length of string is changeable, the data length of file should be changed
            for (int i = 0; i < exstrings.getTotal(); i++)
            {
                fileaddlength += exstrings.getAddlen(i);
            }
            var rems = new MemoryStream(fileaddlength); //new data waiting to be compressed
            var msw = new BinaryWriter(rems, jis);

            int pt = 0; //index to run throuth strings
            //copy memory stream and rewrite str
            pms.Position = 0;
            while (pms.Position >= 0 && pms.Position < pms.Length)
            {
                var total = exstrings.getTotal();
                if ((int)pms.Position == exstrings.getPosition(pt < total ? pt : (total - 1) ))
                {
                    var str = exstrings.getString(pt);
                    if (str.Contains("tur*"))   //string type2
                    {
                        int strblen = jis.GetByteCount(str.ToCharArray());  //number of shift-jis chars
                        pms.Position += (strblen % 4 == 0 ? strblen : (strblen / 4 * 4 + 4)) - exstrings.getAddlen(pt); //source memory stream reader position jump to end of the string data
                        rems.Position -= 4;
                        msw.Write(strblen % 4 == 0 ? strblen : (strblen / 4 * 4 + 4));  //write para1(string length + 0x04)
                        msw.Write((strblen % 4 == 0 ? strblen : (strblen / 4 * 4 + 4)) - 4);    //write para2(string length)
                        msw.Write(jis.GetBytes(str.ToCharArray(4, str.Length - 4)));    //write string
                        while (rems.Position % 4 != 0) msw.Write(false);    //write redundant 0x00 to make data in good order
                        pt++;
                    }
                    else    //string type default
                    {
                        int strblen = jis.GetByteCount(str.ToCharArray());
                        pms.Position += (strblen % 4 == 0 ? strblen : (strblen / 4 * 4 + 4)) - exstrings.getAddlen(pt);
                        rems.Position -= 4;
                        msw.Write(strblen % 4 == 0 ? strblen : (strblen / 4 * 4 + 4));
                        msw.Write(jis.GetBytes(str.ToCharArray()));
                        while (rems.Position % 4 != 0) msw.Write(false);
                        pt++;
                    }
                }
                else    //if it is not a string, copy the bytes
                {
                    msw.Write(pbr.ReadBytes(4));
                }
            }
            msw.Flush();

            pt = 0; //to run through blocks
            int str_pt = 0; //to run through strings
            int offset = 0; //to help locate the changed block position
            //modify block length
            rems.Position = 0;
            while (pt < block_total)
            {
                rems.Position = block_pos[pt] + offset;
                int block_addlen = 0;
                while ((exstrings.getPosition(str_pt) < (pt == block_total - 1 ? pms.Length : block_pos[pt + 1])) && str_pt < exstrings.getTotal())
                {
                    block_addlen += exstrings.getAddlen(str_pt);
                    str_pt++;
                }
                rems.Position -= 4;
                msw.Write((int)(pt == block_total - 1 ? pms.Length : (block_pos[pt + 1] - 8)) - block_pos[pt] + block_addlen);  //write block length
                offset += block_addlen;
                pt++;

            }

            //compress the newly write data
            int uncomlength = (int)rems.Length;
            var uncombytes = new byte[uncomlength];
            rems.Position = 0;
            rems.Read(uncombytes, 0, uncomlength);

            var ms = new MemoryStream(1024 * 1024);

            var zlibStream = new ZLibStream(ms, CompressionMode.Compress, CompressionLevel.Level9);
            zlibStream.Write(uncombytes, 0, uncomlength);
            zlibStream.Flush();
            int comlength = (int)ms.Length;
            var br = new BinaryReader(ms);
            ms.Position = 0;

            //coding the compressed data
            var bytes = new byte[ms.Length];
            for (int i = 0; i < comlength; i++)
            {
                var x = br.ReadByte();
                for (int k = 0; k < 256; k++)
                {
                    if (table[k] == x) bytes[i] = (byte)k;

                }
            }

            br.Close();
            ms.Close();

            //save file
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "ex files (*.ex)|*.ex";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = filenameend;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {

                    byte[] head1 = { 0x48, 0x45, 0x41, 0x44, 0x0c, 0, 0, 0, 0x45, 0x58, 0x54, 0x46, 0x01, 0, 0, 0 };    //head
                    //data head and length parameter
                    byte[] head2 = { (byte)block_total, 0, 0, 0, 0x44, 0x41, 0x54, 0x41, (byte)(comlength & 0xFF), (byte)((comlength & 0xFF00) >> 8), (byte)((comlength & 0xFF0000) >> 16), (byte)((comlength & 0xFF000000) >> 24), (byte)(uncomlength & 0xFF), (byte)((uncomlength & 0xFF00) >> 8), (byte)((uncomlength & 0xFF0000) >> 16), (byte)((uncomlength & 0xFF000000) >> 24) };
                    myStream.Write(head1, 0, 16);
                    myStream.Write(head2, 0, 16);
                    myStream.Write(bytes, 0, (int)comlength);   //write data
                    myStream.Close();
                    toolStripStatusLabel1.Text = "Saving completed.";
                }
            }

        }

        //output decoded and decompressed file
        private void outputDecodedExFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.ex_)|*.ex_";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = filenameend;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {
                    pms.Position = 0;
                    var pbr = new BinaryReader(pms);
                    var bytes = pbr.ReadBytes((int)pms.Length);
                    myStream.Write(bytes, 0, bytes.Length);
                    myStream.Close();
                    toolStripStatusLabel1.Text = "Outputing completed.";

                }
            }
            if(myStream != null)
                myStream.Close();

        }

        private void extractStringOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string strtext = "";
            for (int i = 0; i < exstrings.getTotal(); i++)
            {
                strtext += "s" + i + " " + exstrings.getString(i) + "\r\n";
            }

            Stream myStream;
            SaveFileDialog saveFileDialog2 = new SaveFileDialog();

            saveFileDialog2.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog2.FilterIndex = 2;
            saveFileDialog2.RestoreDirectory = true;
            saveFileDialog2.FileName = filenameend;

            if (saveFileDialog2.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog2.OpenFile()) != null)
                {
                    var sr = new StreamWriter(myStream, utf8);
                    sr.Write(strtext);
                    sr.Flush();
                    sr.Close();
                    myStream.Close();
                    toolStripStatusLabel1.Text = "String extraction completed.";

                }
            }

        }

        private void importStringInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog2 = new OpenFileDialog();

            openFileDialog2.Filter = "txt files (*.txt)|*.txt";
            openFileDialog2.FilterIndex = 2;
            openFileDialog2.RestoreDirectory = true;

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((filename = openFileDialog2.FileName) != null)
                    {
                        Stream txtfile = openFileDialog2.OpenFile();
                        var sr = new StreamReader(txtfile);
                        while (txtfile.Position >= 0 && txtfile.Position < txtfile.Length)
                        {
                            string tmp = sr.ReadLine();
                            while(sr.Peek() != 's')
                            {
                                tmp = tmp + "\n" + sr.ReadLine();
                            }
                            if (tmp.First() != 's') continue;
                            int i = 1;
                            while (char.IsDigit(tmp, i))
                            {
                                i++;
                            }
                            int ind = Convert.ToInt32(tmp.Substring(1, i - 1), 10); //index of string
                            tmp = tmp.Substring(i + 1, tmp.Length - i - 1); //get string
                            if (tmp.Equals(exstrings.getString(ind))) continue; //string with no change
                            int tmplen = jis.GetByteCount(tmp.ToCharArray());   //latter string length
                            int strlen = jis.GetByteCount(exstrings.getString(ind).ToCharArray());  //former string length
                            exstrings.addLength(ind, ((tmplen % 4 == 0) ? tmplen : (tmplen / 4 * 4 + 4)) - ((strlen % 4 == 0) ? strlen : (strlen / 4 * 4 + 4)));    //set addlen
                            exstrings.setStr(ind, tmp); //change string
                        }

                        txtfile.Flush();
                        sr.Close();
                        txtfile.Close();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                string texttoshow = "";
                for (int i = 0; i < exstrings.getTotal(); i++)
                {
                    texttoshow += "s" + i + " " + exstrings.getString(i) + "\r\n";
                }
                textBox1.Text = texttoshow;

                toolStripStatusLabel1.Text = "Importing " + filenameend + ".txt completed.";

            }

        }

        private void KnownToWorkWithToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Files with the extension \".ex\" of alicesoft games published before 2014/7/31");
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Version 0.10\r\nBy Lookinth");
        }

    }
}
