﻿namespace ExTransAssist
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openExFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveExFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outputDecodedExFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extractStringOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importStringInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KnownToWorkWithToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.operationToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(624, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openExFileToolStripMenuItem,
            this.saveExFileToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openExFileToolStripMenuItem
            // 
            this.openExFileToolStripMenuItem.Name = "openExFileToolStripMenuItem";
            this.openExFileToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.openExFileToolStripMenuItem.Text = "Open Ex File";
            this.openExFileToolStripMenuItem.Click += new System.EventHandler(this.openExFileToolStripMenuItem_Click);
            // 
            // saveExFileToolStripMenuItem
            // 
            this.saveExFileToolStripMenuItem.Enabled = false;
            this.saveExFileToolStripMenuItem.Name = "saveExFileToolStripMenuItem";
            this.saveExFileToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.saveExFileToolStripMenuItem.Text = "Save Ex File";
            this.saveExFileToolStripMenuItem.Click += new System.EventHandler(this.saveExFileToolStripMenuItem_Click);
            // 
            // operationToolStripMenuItem
            // 
            this.operationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outputDecodedExFileToolStripMenuItem,
            this.extractStringOutToolStripMenuItem,
            this.importStringInToolStripMenuItem});
            this.operationToolStripMenuItem.Name = "operationToolStripMenuItem";
            this.operationToolStripMenuItem.Size = new System.Drawing.Size(79, 21);
            this.operationToolStripMenuItem.Text = "Operation";
            // 
            // outputDecodedExFileToolStripMenuItem
            // 
            this.outputDecodedExFileToolStripMenuItem.Enabled = false;
            this.outputDecodedExFileToolStripMenuItem.Name = "outputDecodedExFileToolStripMenuItem";
            this.outputDecodedExFileToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.outputDecodedExFileToolStripMenuItem.Text = "Output Decoded Ex File";
            this.outputDecodedExFileToolStripMenuItem.Click += new System.EventHandler(this.outputDecodedExFileToolStripMenuItem_Click);
            // 
            // extractStringOutToolStripMenuItem
            // 
            this.extractStringOutToolStripMenuItem.Enabled = false;
            this.extractStringOutToolStripMenuItem.Name = "extractStringOutToolStripMenuItem";
            this.extractStringOutToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.extractStringOutToolStripMenuItem.Text = "Extract String Out";
            this.extractStringOutToolStripMenuItem.Click += new System.EventHandler(this.extractStringOutToolStripMenuItem_Click);
            // 
            // importStringInToolStripMenuItem
            // 
            this.importStringInToolStripMenuItem.Enabled = false;
            this.importStringInToolStripMenuItem.Name = "importStringInToolStripMenuItem";
            this.importStringInToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.importStringInToolStripMenuItem.Text = "Import String In";
            this.importStringInToolStripMenuItem.Click += new System.EventHandler(this.importStringInToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.KnownToWorkWithToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(47, 21);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // KnownToWorkWithToolStripMenuItem
            // 
            this.KnownToWorkWithToolStripMenuItem.Name = "KnownToWorkWithToolStripMenuItem";
            this.KnownToWorkWithToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.KnownToWorkWithToolStripMenuItem.Text = "Known to work with";
            this.KnownToWorkWithToolStripMenuItem.Click += new System.EventHandler(this.KnownToWorkWithToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("MS Gothic", 12F);
            this.textBox1.Location = new System.Drawing.Point(0, 27);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(624, 390);
            this.textBox1.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 420);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(624, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 442);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "ExTransAssist";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openExFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveExFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outputDecodedExFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extractStringOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importStringInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem KnownToWorkWithToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

