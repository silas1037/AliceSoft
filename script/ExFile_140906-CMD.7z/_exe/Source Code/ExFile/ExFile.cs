using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Data;
using System.Globalization;
using System.Collections.ObjectModel;
using ZLibNet;
using System.CodeDom.Compiler;
using System.Diagnostics;

namespace ExFile
{
    public interface IReadable
    {
        void Read(BinaryReader br);
    }

    public interface IReadable2
    {
        void Read(BinaryReader br, int count);
    }

    public interface IWritable
    {
        void Write(BinaryWriter bw);
    }

    public class ExFieldCollection : Collection<ExField>, IWritable, IReadable2, ICloneable
    {
        public ExFieldCollection()
            : base()
        {

        }

        public ExFieldCollection(int initialCapacity)
            : base(new List<ExField>(initialCapacity))
        {

        }

        public void Write(BinaryWriter bw)
        {
            bw.WriteObjects(this);
        }

        public void Read(BinaryReader br, int count)
        {
            br.ReadObjects(this, count);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var field in this)
            {
                if (sb.Length > 0)
                {
                    sb.Append("\t");
                }
                sb.Append(field.ToString());
            }
            return sb.ToString();
        }

        public ExFieldCollection Clone()
        {
            var clone = new ExFieldCollection(this.Count);
            foreach (var item in this)
            {
                clone.Add(item.Clone());
            }
            return clone;
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            return Clone();
        }

        #endregion
    }

    public class ExField : IReadable, IWritable, IEquatable<ExField>, ICloneable
    {
        public int Type;
        public string Name;
        public int Unknown;
        public int Unknown2;
        public int Unknown3;

        public ExFieldCollection SubFields;

        public void Read(BinaryReader br)
        {
            Type = br.ReadInt32();
            Name = br.ReadLengthIndexedString();
            Unknown = br.ReadInt32();
            Unknown2 = br.ReadInt32();
            if (Unknown != 0)
            {
                Unknown3 = br.ReadInt32();
            }

            if (Type == 4)
            {
                int subFieldCount = br.ReadInt32();
                if (subFieldCount < 0 || subFieldCount > 255)
                {
                    throw new InvalidDataException("Field definition of struct type: Too many members");
                }
                this.SubFields = new ExFieldCollection(subFieldCount);
                this.SubFields.Read(br, subFieldCount);
            }

            if (Type < 0 || Type > 4)
            {
                throw new InvalidDataException("Unknown type for field definition");
            }
        }

        public void Write(BinaryWriter bw)
        {
            bw.Write((int)Type);
            bw.WriteLengthIndexedString(Name);
            bw.Write((int)Unknown);
            bw.Write((int)Unknown2);
            if (Unknown != 0)
            {
                bw.Write((int)Unknown3);
            }

            if (Type == 4)
            {
                bw.Write((int)this.SubFields.Count);
                bw.WriteObjects(this.SubFields);
            }
        }

        private string ToString(string prefix)
        {
            if (Type == 1)
            {
                return "int " + prefix + Name;
            }
            else if (Type == 2)
            {
                return "float " + Name;
            }
            else if (Type == 3)
            {
                return "string " + Name;
            }
            else if (Type == 4)
            {
                StringBuilder sb = new StringBuilder();
                foreach (var subField in SubFields)
                {
                    if (sb.Length > 0)
                    {
                        sb.Append("\t");
                    }
                    sb.Append(subField.ToString(prefix + Name + "."));
                }
                return sb.ToString();
            }
            else
            {

            }
            return base.ToString();
        }

        public override string ToString()
        {
            return ToString("");
        }

        public ExField Clone()
        {
            var clone = (ExField)this.MemberwiseClone();
            if (clone.SubFields != null)
            {
                clone.SubFields = clone.SubFields.Clone();
            }
            return clone;
        }


        #region IEquatable<Field> Members

        public bool Equals(ExField other)
        {
            if (Object.ReferenceEquals(this, other))
            {
                return true;
            }
            if (this == null)
            {
                if (other == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            if (other == null)
            {
                return false;
            }

            bool membersMatch = this.Name == other.Name && this.Type == other.Type;
            if (!membersMatch)
            {
                return false;
            }

            bool subfieldsMatch = false;

            if (this.SubFields == null && other.SubFields == null)
            {
                subfieldsMatch = true;
            }
            if (this.SubFields != null && other.SubFields != null)
            {
                subfieldsMatch = this.SubFields.SequenceEqual(other.SubFields);
            }
            return subfieldsMatch;
        }

        #endregion

        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }

    public class ExRowCollection : Collection<ExRow>, ICloneable
    {
        public ExRowCollection()
            : base()
        {

        }

        public ExRowCollection(int initialCapacity)
            : base(new List<ExRow>(initialCapacity))
        {

        }

        public void AddRange(IEnumerable<string> strings)
        {
            foreach (var str in strings)
            {
                var row = new ExRow(1);
                var exValue = new ExValue() { Type = 3, StringValue = str };
                row.Add(exValue);
                this.Add(row);
            }
        }

        public void AddRange(IEnumerable<ExRow> rows)
        {
            foreach (var row in rows)
            {
                this.Add(row);
            }
        }

        public void Write(BinaryWriter bw)
        {
            bw.WriteObjects(this);
        }

        public void Read(BinaryReader br, int rowCount, int columnCount)
        {
            br.ReadObjects(this, rowCount, columnCount);
        }

        public void Read2(BinaryReader br, int rowCount, int columnCount)
        {
            for (int i = 0; i < rowCount; i++)
            {
                var row = new ExRow(columnCount);
                row.Read2(br, columnCount);
                this.Add(row);
            }
        }

        public int ColumnCount
        {
            get
            {
                var first = this.FirstOrDefault();
                if (first != null)
                {
                    return first.Count;
                }
                else
                {
                    return 0;
                }
            }
        }

        public int RowCount
        {
            get
            {
                return Count;
            }
        }

        public ExRowCollection Clone()
        {
            var clone = new ExRowCollection(this.Count);
            foreach (var item in this)
            {
                clone.Add(item.Clone());
            }
            return clone;
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    //public class ExValueCollection : Collection<ExValue>, IReadable2, IWritable, ICloneable
    //{
    //    public ExValueCollection()
    //        : base()
    //    {

    //    }

    //    public ExValueCollection(int initialCapacity)
    //        : base(new List<ExValue>(initialCapacity))
    //    {

    //    }

    //    public void AddRange(IEnumerable<ExValue> values)
    //    {
    //        foreach (var value in values)
    //        {
    //            this.Add(value);
    //        }
    //    }

    //    public void Read(BinaryReader br, int count)
    //    {
    //        br.ReadObjects(this, count);
    //    }

    //    public void Write(BinaryWriter bw)
    //    {
    //        bw.WriteObjects(this);
    //    }

    //    public ExValueCollection Clone()
    //    {
    //        var clone = new ExValueCollection(this.Count);
    //        foreach (var item in this)
    //        {
    //            clone.Add(item.Clone());
    //        }
    //        return clone;
    //    }

    //    #region ICloneable Members

    //    object ICloneable.Clone()
    //    {
    //        return this.Clone();
    //    }

    //    #endregion
    //}

    public class ExValue : IReadable, IWritable, ICloneable
    {
        public int Type;
        public string StringValue;
        public int IntValue;
        public float FloatValue;
        public ExRowCollection SubValues;

        public virtual void Read(BinaryReader br)
        {
            this.Type = br.ReadInt32();
            ReadValue(br);
        }

        public void ReadValue(BinaryReader br)
        {
            if (Type == 1)
            {
                this.IntValue = br.ReadInt32();
            }
            else if (Type == 2)
            {
                this.FloatValue = br.ReadSingle();
            }
            else if (Type == 3)
            {
                this.StringValue = br.ReadLengthIndexedString();
            }
            else if (Type == 4)
            {
                ReadSubvalues(br);
            }
            else if (Type == 5)
            {
                ReadSubvaluesArray(br);
            }
            else
            {
                throw new InvalidDataException("Unknown type for table value");
            }
        }

        public static ExRowCollection ReadArray(BinaryReader br)
        {
            int rowCount = br.ReadInt32();
            ExRowCollection rows = new ExRowCollection();
            rows.Read2(br, rowCount, 1);

            //for (int i = 0; i < rowCount; i++)
            //{
            //    ExValue2 value = new ExValue2();
            //    value.Read(br);
            //    var newRow = new ExRow(1);
            //    newRow.Add(value);
            //    rows.Add(newRow);
            //}
            return rows;
        }

        protected void ReadSubvaluesArray(BinaryReader br)
        {
            this.SubValues = ReadArray(br);
        }

        public virtual void Write(BinaryWriter bw)
        {
            bw.Write((int)Type);
            WriteValue(bw);
        }

        public void WriteValue(BinaryWriter bw)
        {
            if (Type == 1)
            {
                bw.Write(this.IntValue);
            }
            else if (Type == 2)
            {
                bw.Write(this.FloatValue);
            }
            else if (Type == 3)
            {
                bw.WriteLengthIndexedString(this.StringValue);
            }
            else if (Type == 4)
            {
                WriteSubvalues(bw);
            }
            else if (Type == 5)
            {
                WriteSubvaluesArray(bw);
            }
        }

        protected void ReadSubvalues(BinaryReader br)
        {
            int subvalueColumnCount = br.ReadInt32();
            int subvalueRowCount = br.ReadInt32();

            if (subvalueColumnCount < 0 || subvalueColumnCount > 255)
            {
                throw new InvalidDataException("Invalid value for subvalue column count");
            }
            if (subvalueRowCount < 0 || subvalueRowCount > 0x1000000)
            {
                throw new InvalidDataException("Invalid value for subvalue row count");
            }

            this.SubValues = new ExRowCollection(subvalueRowCount);
            this.SubValues.Read(br, subvalueRowCount, subvalueColumnCount);
        }

        protected void WriteSubvalues(BinaryWriter bw)
        {
            int subvalueColumnCount = this.SubValues.ColumnCount;
            int subvalueRowCount = this.SubValues.RowCount;

            bw.Write(subvalueColumnCount);
            bw.Write(subvalueRowCount);
            if (this.SubValues == null)
            {
                throw new InvalidDataException("Attempting to write null subvalues");
            }
            bw.WriteObjects(this.SubValues);
        }

        protected void WriteSubvaluesArray(BinaryWriter bw)
        {
            WriteArray(bw, SubValues);
        }

        public static void WriteArray(BinaryWriter bw, ExRowCollection SubValues)
        {
            int rowCount = SubValues.Count;
            bw.Write(rowCount);
            SubValues.Write(bw);

            //for (int i = 0; i < rowCount; i++)
            //{
            //    var row = SubValues[i];
            //    var value = row.FirstOrDefault();
            //    value.Write(bw);
            //}
        }

        public override string ToString()
        {
            if (Type == 1)
            {
                return this.IntValue.ToString(CultureInfo.InvariantCulture);
            }
            else if (Type == 2)
            {
                double doubleValue = this.FloatValue;
                return doubleValue.ToString(CultureInfo.InvariantCulture);
            }
            else if (Type == 3)
            {
                return Util.EscapeString(this.StringValue);
            }
            else if (Type == 4 || Type == 5)
            {
                if (this.SubValues != null)
                {
                    if (this.SubValues.ColumnCount == 1)
                    {
                        if (this.SubValues.RowCount == 1)
                        {
                            return this.SubValues.FirstOrDefault().FirstOrDefault().ToString();
                        }
                        else if (this.SubValues.RowCount < 10)
                        {
                            StringBuilder sb = new StringBuilder();
                            sb.Append("{");
                            for (int i = 0; i < this.SubValues.RowCount; i++)
                            {
                                if (i > 0)
                                {
                                    sb.Append(", ");
                                }
                                var row = this.SubValues[i];
                                var value = row.FirstOrDefault();
                                if (value != null)
                                {
                                    sb.Append(value.ToString());
                                }
                            }
                            sb.Append("}");
                            return sb.ToString();
                        }
                    }
                }
                else
                {
                    return "";
                }
            }
            return "";
        }

        public ExValue Clone()
        {
            return (ExValue)(((ICloneable)this).Clone());
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            ExValue clone = (ExValue)this.MemberwiseClone();
            if (clone.SubValues != null)
            {
                clone.SubValues = clone.SubValues.Clone();
            }
            return clone;
        }

        #endregion
    }

    public class ExValue2 : ExValue, IWritable, IReadable
    {
        public int Length;
        public override void Read(BinaryReader br)
        {
            this.Type = br.ReadInt32();
            this.Length = br.ReadInt32();
            long startPos = br.BaseStream.Position;
            ReadValue(br);

            //if (Type == 0 && Length == 0)
            //{
            //    return;
            //}

            //if (Type == 1)
            //{
            //    this.IntValue = br.ReadInt32();
            //}
            //else if (Type == 2)
            //{
            //    this.FloatValue = br.ReadSingle();
            //}
            //else if (Type == 3)
            //{
            //    this.StringValue = br.ReadLengthIndexedString();
            //}
            //else if (Type == 4)
            //{
            //    //Unknown if this ever happens
            //    this.ReadSubvalues(br);
            //}
            //else
            //{
            //    throw new InvalidDataException("Unknown Type for list value");
            //}

            long currentPos = br.BaseStream.Position;
            int actualLength = (int)(currentPos - startPos);
            if (actualLength != Length)
            {
                throw new InvalidDataException("Wrong length, should be " + Length.ToString() + " but is actually " + actualLength.ToString());
            }
        }

        public override void Write(BinaryWriter bw)
        {
            bw.Write((int)Type);
            long positionOfLengthWord = bw.BaseStream.Position;
            bw.Write((int)0);
            long startPos = bw.BaseStream.Position;
            WriteValue(bw);

            //if (Type == 1)
            //{
            //    bw.Write(this.IntValue);
            //}
            //else if (Type == 2)
            //{
            //    bw.Write(this.FloatValue);
            //}
            //else if (Type == 3)
            //{
            //    bw.WriteLengthIndexedString(this.StringValue);
            //}
            //else if (Type == 4)
            //{
            //    //unknown if this ever happens
            //    this.WriteSubvalues(bw);
            //}

            long endPos = bw.BaseStream.Position;
            int length = (int)(endPos - startPos);

            bw.BaseStream.Position = positionOfLengthWord;
            bw.Write((int)length);
            bw.BaseStream.Position = endPos;
        }

        public new ExValue2 Clone()
        {
            return (ExValue2)((ICloneable)this).Clone();
        }
    }

    public class ExValue3 : ExValue2
    {
        public string Name;
        public override void Read(BinaryReader br)
        {
            this.Type = br.ReadInt32();
            this.Length = br.ReadInt32();
            long startPos = br.BaseStream.Position;
            this.Name = br.ReadLengthIndexedString();

            ReadValue(br);

            long currentPos = br.BaseStream.Position;
            int actualLength = (int)(currentPos - startPos);
            if (actualLength != Length)
            {
                throw new InvalidDataException("Wrong length, should be " + Length.ToString() + " but is actually " + actualLength.ToString());
            }
        }

        public override void Write(BinaryWriter bw)
        {
            bw.Write((int)Type);
            long positionOfLengthWord = bw.BaseStream.Position;
            bw.Write((int)0);
            long startPos = bw.BaseStream.Position;
            bw.WriteLengthIndexedString(this.Name);

            WriteValue(bw);

            long endPos = bw.BaseStream.Position;
            int length = (int)(endPos - startPos);

            bw.BaseStream.Position = positionOfLengthWord;
            bw.Write((int)length);
            bw.BaseStream.Position = endPos;
        }

        public new ExValue3 Clone()
        {
            return (ExValue3)((ICloneable)this).Clone();
        }
    }

    public class ExRow : Collection<ExValue>, IWritable, IReadable2, ICloneable
    {
        public ExRow()
            : base()
        {

        }
        public ExRow(int initialCapacity)
            : base(new List<ExValue>(initialCapacity))
        {

        }

        public void Read(BinaryReader br, int columnCount)
        {
            br.ReadObjects(this, columnCount);
        }

        public void Read2(BinaryReader br, int columnCount)
        {
            for (int i = 0; i < columnCount; i++)
            {
                var exValue2 = new ExValue2();
                exValue2.Read(br);
                this.Add(exValue2);
            }
        }

        public void Write(BinaryWriter bw)
        {
            bw.WriteObjects(this);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var column in this)
            {
                if (sb.Length > 0)
                {
                    sb.Append(", ");
                }
                sb.Append(column.ToString());
            }
            return sb.ToString();
        }

        public ExRow Clone()
        {
            var clone = new ExRow(this.Count);
            foreach (var item in this)
            {
                if (item != null)
                {
                    clone.Add(item.Clone());
                }
                else
                {
                    clone.Add(null);
                }
            }
            return clone;
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }



    public class ExFile
    {
        public ExTableCollection Tables = new ExTableCollection();
        public string FileName;
        static Encoding utf8Bom = new UTF8Encoding(true);

        public void ReadFile(string fileName)
        {
            byte[] bytes = ExLoader.ReadExFile(fileName);
            ReadFile(bytes);
            this.FileName = fileName;
        }

        public void ReadFile(byte[] bytes)
        {
            var br = new BinaryReader(new MemoryStream(bytes));
            ReadFile(br);
        }

        public void ReadFile(BinaryReader br)
        {
            while (br.BaseStream.Position < br.BaseStream.Length)
            {
                var table = new ExTable();
                table.Read(br);
                Tables.Add(table);
            }
        }

        public void ExportTables(string outputPath)
        {
            string tablesPath = Path.Combine(outputPath, "tables");
            string listsPath = Path.Combine(outputPath, "lists");
            string treesPath = Path.Combine(outputPath, "trees");
            string remainingFilename = Path.Combine(outputPath, Path.GetFileNameWithoutExtension(FileName) + "_ex_remaining.txt");
            StringBuilder remainingText = new StringBuilder();

            foreach (var table in Tables)
            {
                if (table.BlockType == 4)
                {
                    string tabSeparatedFile = table.ToTabSeparatedFile();
                    if (!Directory.Exists(tablesPath))
                    {
                        Directory.CreateDirectory(tablesPath);
                    }
                    string outputFileName = Path.Combine(tablesPath, table.Name + ".txt");
                    File.WriteAllText(outputFileName, tabSeparatedFile, utf8Bom);
                }
                else if (table.BlockType == 5)
                {
                    string tabSeparatedFile = table.ToTabSeparatedFile();
                    if (!Directory.Exists(listsPath))
                    {
                        Directory.CreateDirectory(listsPath);
                    }
                    string outputFileName = Path.Combine(listsPath, table.Name + ".txt");
                    File.WriteAllText(outputFileName, tabSeparatedFile, utf8Bom);
                }
                else if (table.BlockType == 6)
                {
                    string tabSeparatedFile = table.ToTabSeparatedFile();
                    if (!Directory.Exists(treesPath))
                    {
                        Directory.CreateDirectory(treesPath);
                    }
                    string outputFileName = Path.Combine(treesPath, table.Name + ".txt");
                    File.WriteAllText(outputFileName, tabSeparatedFile, utf8Bom);
                }
                else
                {
                    remainingText.AppendLine(table.ToString());
                }
                if (remainingText.Length > 0)
                {
                    File.WriteAllText(remainingFilename, remainingText.ToString(), utf8Bom);
                }
            }
        }

        public bool ImportTables(string inputPath)
        {
            bool didAnything = false;

            string tablesPath = Path.Combine(inputPath, "tables");
            string listsPath = Path.Combine(inputPath, "lists");
            string treesPath = Path.Combine(inputPath, "trees");
            string remainingFilename = Path.Combine(inputPath, Path.GetFileNameWithoutExtension(FileName) + "_ex_remaining.txt");

            Dictionary<string, string> remainingFileValues = new Dictionary<string, string>();

            if (File.Exists(remainingFilename))
            {
                Encoding remainingFileEncoding = EncodingDetector.DetectEncoding(remainingFilename);
                string[] remainingFileLines = File.ReadAllLines(remainingFilename, remainingFileEncoding);
                foreach (var line in remainingFileLines)
                {
                    if (line.Contains('='))
                    {
                        string[] pieces = line.Split('=');
                        string variableName = pieces[0].Trim();
                        string value = pieces[1].Trim();

                        remainingFileValues[variableName] = value;
                    }
                }
            }

            foreach (var table in Tables)
            {
                string inputFileName = "";

                if (table.BlockType == 4)
                {
                    inputFileName = Path.Combine(tablesPath, table.Name.Trim() + ".txt");
                }
                else if (table.BlockType == 5)
                {
                    inputFileName = Path.Combine(listsPath, table.Name.Trim() + ".txt");
                }
                else if (table.BlockType == 6)
                {
                    inputFileName = Path.Combine(treesPath, table.Name.Trim() + ".txt");
                }
                else
                {
                    inputFileName = "";
                    if (remainingFileValues.ContainsKey(table.Name))
                    {
                        string value = remainingFileValues[table.Name];

                        if (table.BlockType == 1)
                        {
                            int intValue;
                            if (int.TryParse(value, out intValue))
                            {
                                table.IntValue = intValue;
                                didAnything = true;
                            }
                        }
                        else if (table.BlockType == 2)
                        {
                            double doubleValue;
                            if (double.TryParse(value, out doubleValue))
                            {
                                float floatValue = (float)doubleValue;
                                table.FloatValue = floatValue;
                                didAnything = true;
                            }
                        }
                        else if (table.BlockType == 3)
                        {
                            string stringValue = Util.UnescapeString(value);
                            table.StringValue = stringValue;
                            didAnything = true;
                        }
                    }
                }

                if (File.Exists(inputFileName))
                {
                    var encoding = EncodingDetector.DetectEncoding(inputFileName);
                    string fileText = File.ReadAllText(inputFileName, encoding);

                    table.ReadTabSeparatedFileText(fileText);
                    didAnything = true;
                }
            }
            if (!didAnything)
            {
                return false;
            }
            return true;
        }

        public DataSet ToDataSet(bool flattenTables)
        {
            DataSet dataSet = new DataSet();
            foreach (var table in Tables)
            {
                var dataTable = table.ToDataTable();
                if (flattenTables)
                {
                    dataTable = ExTable.FlattenDataTable(dataTable);
                }
                dataTable.TableName = table.Name;
                dataSet.Tables.Add(dataTable);
            }
            return dataSet;
        }

        public void SaveRawFile(string fileName)
        {
            using (var fileStream = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                BinaryWriter bw = new BinaryWriter(fileStream);
                SaveRawFile(bw);
                fileStream.Flush();
            }

        }

        private void SaveRawFile(BinaryWriter bw)
        {
            foreach (var table in this.Tables)
            {
                table.Write(bw);
            }
        }

        public void SaveFile()
        {
            //back up to filename.ex_ORIGINAL
            if (!File.Exists(this.FileName + "_ORIGINAL"))
            {
                File.Copy(this.FileName, this.FileName + "_ORIGINAL");
            }
            //force output file to not be read only
            var fileInfo = new FileInfo(this.FileName);
            if (0 != (fileInfo.Attributes & FileAttributes.ReadOnly))
            {
                fileInfo.Attributes &= ~FileAttributes.ReadOnly;
            }
            //overwrite input file
            SaveFile(this.FileName);
        }

        static Encoding utf8 = Encoding.GetEncoding("utf-8");

        public void SaveFile(string fileName)
        {
            byte[] rawBytes;
            {
                MemoryStream msRaw = new MemoryStream();
                BinaryWriter bwRaw = new BinaryWriter(msRaw);

                SaveRawFile(bwRaw);
                rawBytes = msRaw.ToArray();
            }

            MemoryStream msOutput = new MemoryStream();
            ZLibStream zlibStream = new ZLibStream(msOutput, CompressionMode.Compress, CompressionLevel.BestCompression, true);
            BinaryWriter bwZlib = new BinaryWriter(zlibStream);

            bwZlib.Write(rawBytes);
            zlibStream.Flush();
            zlibStream.Close();

            var zlibBytes = msOutput.ToArray();

            ExLoader.EncodeData(zlibBytes);

            using (var fileStream = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                BinaryWriter bw = new BinaryWriter(fileStream);
                bw.Write(utf8.GetBytes("HEAD"));
                bw.Write((int)0x0C);
                bw.Write(utf8.GetBytes("EXTF"));
                bw.Write((int)1);
                bw.Write((int)Tables.Count);
                bw.Write(utf8.GetBytes("DATA"));
                bw.Write((int)zlibBytes.Length);
                bw.Write((int)rawBytes.Length);
                bw.Write(zlibBytes);
            }
        }
    }

    public class ExTableCollection : Collection<ExTable>, ICloneable
    {

        public ExTableCollection Clone()
        {
            var clone = new ExTableCollection();
            foreach (var item in this)
            {
                clone.Add(item.Clone());
            }
            return clone;
        }


        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }

    public class ExTree : IReadable, IWritable, ICloneable
    {
        public string Name;
        public List<ExTree> Children = null;
        public Dictionary<string, int> ChildNameToIndex = null;

        public ExValue3 Value = null;
        public bool HasChildren
        {
            get
            {
                return this.Children != null && this.Children.Count > 0 && this.Value == null;
            }
        }

        public void Read(BinaryReader br)
        {
            this.Name = br.ReadLengthIndexedString();
            int isLeafNode = br.ReadInt32();
            if (isLeafNode == 0)
            {
                int childCount = br.ReadInt32();
                this.Children = new List<ExTree>();
                this.ChildNameToIndex = new Dictionary<string, int>();
                for (int i = 0; i < childCount; i++)
                {
                    ExTree tree = new ExTree();
                    tree.Read(br);
                    Children.Add(tree);
                    ChildNameToIndex[tree.Name] = Children.Count - 1;
                }
            }
            else if (isLeafNode == 1)
            {
                this.Value = new ExValue3();
                this.Value.Read(br);
                if (this.Name != Value.Name)
                {
                    throw new InvalidDataException("Names to not match: " + this.Name + " and " + Value.Name);
                }
                int zero = br.ReadInt32();
                if (zero != 0)
                {
                    throw new InvalidDataException("Expected zero after reading value");
                }
            }
            else
            {
                throw new InvalidDataException("Leaf Node Flag must be 0 or 1");
            }
        }

        public void Write(BinaryWriter bw)
        {
            bw.WriteLengthIndexedString(this.Name);
            if (this.HasChildren)
            {
                bw.Write((int)0);
                bw.Write((int)Children.Count);
                for (int i = 0; i < Children.Count; i++)
                {
                    Children[i].Write(bw);
                }
            }
            else
            {
                bw.Write((int)1);
                this.Value.Write(bw);
                bw.Write((int)0);
            }
        }

        private void ToString(StringBuilder sb, string prefix)
        {
            if (this.HasChildren)
            {
                for (int i = 0; i < Children.Count; i++)
                {
                    Children[i].ToString(sb, prefix + this.Name + ".");
                }
            }
            else if (Value != null)
            {
                sb.AppendLine(prefix + this.Name + " = " + Value.ToString());
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            ToString(sb, "");
            return sb.ToString();
        }

        public void ToTable(ExTable table)
        {
            var tableConverter = new TableConverter();
            tableConverter.ConvertToTable(this, table);
            if (Debugger.IsAttached)
            {
                //RoundTripTest(table);
            }
        }

        private void RoundTripTest(ExTable table)
        {
            //test code
            //var copy = this.Clone();
            string text = table.ToTabSeparatedFile();
            var dataTable = ExTable.TabSeparatedFileToDataTable(text, 6);
            var tableClone = table.Clone();
            tableClone.ReadDataTable(dataTable);
            var tree = this.Clone();
            tree.ReadTable(tableClone);

            if (tree.ToString() != this.ToString())
            {

            }
        }

        public ExTree Clone()
        {
            ExTree clone = new ExTree();
            clone.Name = this.Name;
            if (this.HasChildren)
            {
                clone.Children = this.Children.Select(c => c.Clone()).ToList();
                clone.ChildNameToIndex = new Dictionary<string, int>(ChildNameToIndex);
            }
            else
            {
                clone.Value = this.Value.Clone();
            }
            return clone;
        }

        class TableConverter
        {
            const string NodePrefixName = "Node Prefix";
            Dictionary<string, int> FieldNameToFieldIndex = new Dictionary<string, int>();

            void ConvertFields(ExTree tree, ExTable table)
            {
                if (tree.HasChildren)
                {
                    int lastFieldIndex = -1;

                    for (int i = 0; i < tree.Children.Count; i++)
                    {
                        var node = tree.Children[i];
                        if (node.HasChildren)
                        {
                            ConvertFields(node, table);
                        }
                        else
                        {
                            int nodePrefixFieldIndex;
                            ExField nodePrefixField;
                            if (!FieldNameToFieldIndex.ContainsKey("3" + NodePrefixName))
                            {
                                nodePrefixField = new ExField() { Name = NodePrefixName, Type = 3 };
                                nodePrefixFieldIndex = table.Fields.Count;
                                table.Fields.Add(nodePrefixField);
                                FieldNameToFieldIndex["3" + NodePrefixName] = nodePrefixFieldIndex;
                            }
                            else
                            {
                                nodePrefixFieldIndex = FieldNameToFieldIndex["3" + NodePrefixName];
                                nodePrefixField = table.Fields[nodePrefixFieldIndex];
                            }

                        tryAgain:
                            ExField field;
                            int fieldIndex;
                            ExValue3 value = node.Value;
                            string combinedFieldName = value.Type.ToString("X") + value.Name;
                            if (!FieldNameToFieldIndex.ContainsKey(combinedFieldName))
                            {
                                field = new ExField() { Name = value.Name, Type = value.Type };
                                fieldIndex = table.Fields.Count;
                                table.Fields.Add(field);
                                FieldNameToFieldIndex[combinedFieldName] = fieldIndex;

                                if (value.Type == 5)
                                {
                                    var firstSubValue = value.SubValues.FirstOrDefault().FirstOrDefault();
                                    var subField = new ExField() { Name = "values", Type = firstSubValue.Type };
                                    field.SubFields = new ExFieldCollection();
                                    field.SubFields.Add(subField);
                                }
                            }
                            else
                            {
                                fieldIndex = FieldNameToFieldIndex[combinedFieldName];
                                field = table.Fields[fieldIndex];
                            }

                            //if (fieldIndex < lastFieldIndex)
                            //{
                            //    //move field
                            //    //lastFieldIndex is in the wrong place, and should be moved to fieldIndex

                            //    var lastField = table.Fields[lastFieldIndex];

                            //    table.Fields.RemoveAt(lastFieldIndex);
                            //    table.Fields.Insert(fieldIndex, lastField);
                            //    RebuildFieldDictionary(table);
                            //    goto tryAgain;
                            //}
                            lastFieldIndex = fieldIndex;
                        }
                    }
                }
            }

            private void RebuildFieldDictionary(ExTable table)
            {
                this.FieldNameToFieldIndex.Clear();
                for (int i = 0; i < table.Fields.Count; i++)
                {
                    var field = table.Fields[i];
                    string combinedName = field.Type.ToString("X") + field.Name;
                    this.FieldNameToFieldIndex[combinedName] = i;
                }
            }

            public void ConvertToTable(ExTree tree, ExTable table)
            {
                ConvertFields(tree, table);
                if (table.Name == tree.Name && tree.HasChildren)
                {
                    ConvertToTable(tree, table, "");
                }
                else
                {
                    ConvertToTable(tree, table, tree.Name);
                }
            }

            public void ConvertToTable(ExTree tree, ExTable table, string nodePrefix)
            {

                if (tree.HasChildren)
                {
                    ExRow row = null;

                    for (int i = 0; i < tree.Children.Count; i++)
                    {
                        var node = tree.Children[i];
                        if (node.HasChildren)
                        {
                            ConvertToTable(node, table, nodePrefix + node.Name + ".");
                        }
                        else
                        {
                            if (row == null)
                            {
                                row = new ExRow();
                                table.Rows.Add(row);

                                int nodePrefixFieldIndex = FieldNameToFieldIndex["3" + NodePrefixName];
                                ExField nodePrefixField = table.Fields[nodePrefixFieldIndex];

                                //if (!FieldNameToFieldIndex.ContainsKey(NodePrefixName))
                                //{
                                //    nodePrefixField = new ExField() { Name = NodePrefixName, Type = 3 };
                                //    nodePrefixFieldIndex = table.Fields.Count;
                                //    table.Fields.Add(nodePrefixField);
                                //    FieldNameToFieldIndex[NodePrefixName] = nodePrefixFieldIndex;
                                //}
                                //else
                                //{
                                //    nodePrefixFieldIndex = FieldNameToFieldIndex[NodePrefixName];
                                //    nodePrefixField = table.Fields[nodePrefixFieldIndex];
                                //}
                                string prefix = nodePrefix;
                                if (prefix.EndsWith("."))
                                {
                                    prefix = prefix.Substring(0, prefix.Length - 1);
                                }

                                var nodePrefixValue = new ExValue3() { Type = 3, StringValue = prefix, Name = NodePrefixName };
                                row.SetOrAdd(nodePrefixFieldIndex, nodePrefixValue);
                            }

                            ExValue3 value = node.Value;
                            string combinedFieldName = value.Type.ToString("X") + value.Name;
                            int fieldIndex = FieldNameToFieldIndex[combinedFieldName];
                            ExField field = table.Fields[fieldIndex];

                            //if (!FieldNameToFieldIndex.ContainsKey(combinedFieldName))
                            //{
                            //    field = new ExField() { Name = value.Name, Type = value.Type };
                            //    fieldIndex = table.Fields.Count;
                            //    table.Fields.Add(field);
                            //    FieldNameToFieldIndex[combinedFieldName] = fieldIndex;

                            //    if (value.Type == 5)
                            //    {
                            //        var firstSubValue = value.SubValues.FirstOrDefault().FirstOrDefault();
                            //        var subField = new ExField() { Name = "values", Type = firstSubValue.Type };
                            //        field.SubFields = new ExFieldCollection();
                            //        field.SubFields.Add(subField);
                            //    }
                            //}
                            //else
                            //{
                            //    fieldIndex = FieldNameToFieldIndex[combinedFieldName];
                            //    field = table.Fields[fieldIndex];
                            //}

                            row.SetOrAdd(fieldIndex, value);
                        }
                    }
                }
            }
        }
        class TableConverter2
        {
            HashSet<ExTree> NodesToDelete = new HashSet<ExTree>();

            void MarkAllToDelete(ExTree tree)
            {
                NodesToDelete.Add(tree);
                if (tree.HasChildren)
                {
                    foreach (var childNode in tree.Children)
                    {
                        MarkAllToDelete(childNode);
                    }
                }
            }

            void DeleteMarkedNodes(ExTree tree)
            {
                if (tree.HasChildren)
                {
                    int i = 0;
                    bool dirty = false;
                    while (i < tree.Children.Count)
                    {
                        var childNode = tree.Children[i];
                        if (NodesToDelete.Contains(childNode))
                        {
                            tree.Children.RemoveAt(i);
                            dirty = true;
                            i--;
                        }
                        else
                        {
                            DeleteMarkedNodes(childNode);
                        }
                        i++;
                    }

                    if (dirty)
                    {
                        tree.ChildNameToIndex.Clear();
                        for (i = 0; i < tree.Children.Count; i++)
                        {
                            var childNode = tree.Children[i];
                            tree.ChildNameToIndex[childNode.Name] = i;
                        }
                    }
                }
            }

            public void ReadTable(ExTree tree, ExTable table)
            {
                MarkAllToDelete(tree);
                NodesToDelete.Remove(tree);

                tree.Name = table.Name;
                for (int rowIndex = 0; rowIndex < table.RowCount; rowIndex++)
                {
                    var row = table.Rows[rowIndex];
                    var firstValue = row.FirstOrDefault();
                    string nodePrefix = "";
                    if (firstValue == null || String.IsNullOrEmpty(firstValue.StringValue))
                    {

                    }
                    else
                    {
                        nodePrefix = firstValue.StringValue;
                    }

                    for (int columnIndex = 1; columnIndex < table.Fields.Count; columnIndex++)
                    {
                        var field = table.Fields[columnIndex];
                        var value = row.GetOrNull(columnIndex);
                        if (value != null)
                        {
                            if (value.SubValues != null && value.SubValues.FirstOrDefault().FirstOrDefault() == null)
                            {

                            }
                            else
                            {

                                string fieldName = field.Name;
                                if (fieldName.EndsWith("_2"))
                                {
                                    fieldName = fieldName.Substring(fieldName.Length - 2);
                                }
                                SetValue(tree, nodePrefix, fieldName, value);
                            }
                        }
                    }
                }

                if (NodesToDelete.Count > 0)
                {
                    DeleteMarkedNodes(tree);
                }
            }

            public void SetValue(ExTree tree, string nodePrefix, string fieldName, ExValue value)
            {
                NodesToDelete.Remove(tree);

                if (String.IsNullOrEmpty(nodePrefix))
                {
                    ExValue3 value3 = ConvertValue(fieldName, value);

                    int childIndex;
                    ExTree childNode;

                    if (tree.Children == null)
                    {
                        tree.Children = new List<ExTree>();
                        tree.ChildNameToIndex = new Dictionary<string, int>();
                    }

                    if (tree.ChildNameToIndex.ContainsKey(fieldName))
                    {
                        childIndex = tree.ChildNameToIndex[fieldName];
                        childNode = tree.Children[childIndex];
                    }
                    else
                    {
                        childIndex = tree.Children.Count;
                        childNode = new ExTree();
                        tree.Children.SetOrAdd(childIndex, childNode);
                        tree.ChildNameToIndex[fieldName] = childIndex;
                    }
                    NodesToDelete.Remove(childNode);
                    childNode.Name = fieldName;
                    childNode.Value = value3;
                }
                else
                {
                    int indexOfDot = nodePrefix.IndexOf('.');
                    string nodeName, remainingPrefix;


                    if (indexOfDot == -1)
                    {
                        nodeName = nodePrefix;
                        remainingPrefix = "";
                    }
                    else
                    {
                        nodeName = nodePrefix.Substring(0, indexOfDot);
                        remainingPrefix = nodePrefix.Substring(indexOfDot + 1);
                    }

                    if (tree.Children == null)
                    {
                        tree.Children = new List<ExTree>();
                        tree.ChildNameToIndex = new Dictionary<string, int>();
                    }
                    int childIndex;
                    ExTree childNode;
                    if (tree.ChildNameToIndex.ContainsKey(nodeName))
                    {
                        childIndex = tree.ChildNameToIndex[nodeName];
                        childNode = tree.Children[childIndex];
                    }
                    else
                    {
                        childNode = new ExTree();
                        childNode.Name = nodeName;
                        childIndex = tree.Children.Count;
                        tree.Children.Add(childNode);
                        tree.ChildNameToIndex[nodeName] = childIndex;
                    }
                    SetValue(childNode, remainingPrefix, fieldName, value);
                }
            }
            private static ExValue3 ConvertValue(string fieldName, ExValue value)
            {
                ExValue3 value3 = new ExValue3();
                value3.Name = fieldName;
                value3.Type = value.Type;
                value3.IntValue = value.IntValue;
                value3.FloatValue = value.FloatValue;
                value3.StringValue = value.StringValue;
                if (value.SubValues != null)
                {
                    if (value.SubValues.ColumnCount == 1)
                    {
                        value3.Type = 5;
                    }
                    value3.SubValues = new ExRowCollection();
                    for (int i = 0; i < value.SubValues.RowCount; i++)
                    {
                        var row = value.SubValues[i];
                        var newRow = new ExRow(row.Count);
                        for (int c = 0; c < row.Count; c++)
                        {
                            var arrayElement = row[c];
                            var value2 = new ExValue2();

                            //TODO: fix null array value problem

                            value2.Type = arrayElement.Type;
                            value2.IntValue = arrayElement.IntValue;
                            value2.FloatValue = arrayElement.FloatValue;
                            value2.StringValue = arrayElement.StringValue;

                            newRow.Add(value2);
                        }
                        value3.SubValues.Add(newRow);
                    }
                }
                return value3;
            }
        }

        public void ReadTable(ExTable table)
        {
            var converter2 = new TableConverter2();
            converter2.ReadTable(this, table);
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }

    //public class ExTable6Reader
    //{
    //    ExTable parent;
    //    public string Name;
    //    public Dictionary<string, int> FieldNameToFieldIndex = new Dictionary<string, int>();
    //    public ExFieldCollection Fields = new ExFieldCollection();
    //    public ExRowCollection Rows = new ExRowCollection();

    //    public ExTable6Reader(ExTable parent)
    //    {
    //        this.parent = parent;
    //        parent.Fields = this.Fields;
    //        parent.Rows = this.Rows;
    //    }

    //    public void ReadValue(BinaryReader br, string fieldPrefix, ExRow row, ExRowCollection rows)
    //    {

    //    }



    //    public void Read(BinaryReader br, int tableEndAddress)
    //    {
    //        //redo this, it's actually a simple tree
    //        //0 = internal node: childCount, name
    //        //1 = leaf node: type, length, name, data


    //        int _startPos, _length, _endPos;

    //        int tableStartAddress = (int)br.BaseStream.Position;
    //        //int tableEndAddress = tableStartAddress + parent.SizeInBytes;

    //        this.Name = br.ReadLengthIndexedString();
    //        if (this.Name != parent.Name)
    //        {
    //            throw new InvalidDataException("Wrong table name: " + this.Name + " does not match " + parent.Name);
    //        }
    //        //this.Fields.Add(new ExField() { Name = "_ROW", Type = 1 });
    //        //this.FieldNameToFieldIndex["_ROW"] = 0;

    //        this.Fields.Add(new ExField() { Name = "Node Name", Type = 3 });
    //        this.FieldNameToFieldIndex["Node Name"] = 0;



    //        var row = new ExRow();

    //        int unknownZeroValue1 = br.ReadInt32();
    //        if (unknownZeroValue1 != 0)
    //        {
    //            throw new InvalidDataException("Expected 0, got " + unknownZeroValue1.ToString("X") + " instead.");
    //        }


    //        int rowCountHint = br.ReadInt32();
    //        //string firstNodeName = br.ReadLengthIndexedString();
    //        //row.SetOrAdd(0, new ExValue() { Type = 3, StringValue = firstNodeName });

    //        //row.SetOrAdd(0, new ExValue() { Type = 1, IntValue = Rows.Count });

    //        //int hasAnotherFirstNodeName = br.ReadInt32();
    //        //int fieldCountHint = br.ReadInt32();
    //        //int unknown4c = -1;
    //        //int zero1b = -1;

    //        //string firstNodeName2 = null;
    //        //string firstNodeName3 = null;

    //        //if (hasAnotherFirstNodeName != 0)
    //        //{
    //        //    rowCountHint -= 2;

    //        //    if (hasAnotherFirstNodeName != 1)
    //        //    {
    //        //        throw new InvalidDataException("Expected 1, got " + zero1.ToString("X") + " instead.");
    //        //    }

    //        //    _length = br.ReadInt32();
    //        //    _startPos = (int)br.BaseStream.Position;
    //        //    _endPos = _startPos + _length;

    //        //    firstNodeName2 = br.ReadLengthIndexedString();
    //        //    if (firstNodeName2 != firstNodeName)
    //        //    {
    //        //        throw new InvalidDataException("Names do not match: " + firstNodeName + " and " + firstNodeName2);
    //        //    }
    //        //    unknown4c = br.ReadInt32();
    //        //    if (_endPos != br.BaseStream.Position)
    //        //    {
    //        //        br.BaseStream.Position -= 4;
    //        //        firstNodeName3 = br.ReadLengthIndexedString();
    //        //    }
    //        //    if (_endPos != br.BaseStream.Position)
    //        //    {
    //        //        throw new InvalidDataException("Read Pointer does not match what length says it should be");
    //        //    }

    //        //    zero1b = br.ReadInt32();

    //        //    if (zero1b != 0)
    //        //    {
    //        //        throw new InvalidDataException("Expected 0, got " + zero1b.ToString("X") + " instead.");
    //        //    }
    //        //}

    //        //int lastFieldIndex = 0;

    //        int unknownRowValue = -1;
    //        int unknownColumnValue = -1;

    //        while (br.BaseStream.Position < tableEndAddress)
    //        {
    //            string fieldName1 = br.ReadLengthIndexedString();
    //            int hasValue = br.ReadInt32();
    //            //int unknown7;

    //            if (hasValue == 0)
    //            {
    //                unknownRowValue = br.ReadInt32();
    //                if (row != null && row.Count > 0)
    //                {
    //                    Rows.Add(row);
    //                }
    //                row = new ExRow();
    //                //row.SetOrAdd(0, new ExValue() { Type = 1, IntValue = Rows.Count });
    //                row.SetOrAdd(0, new ExValue() { Type = 3, StringValue = fieldName1 });
    //            }
    //            else if (hasValue == 1)
    //            {
    //                int fieldType = br.ReadInt32();
    //                int fieldLength = br.ReadInt32();
    //                long fieldEndAddress = br.BaseStream.Position + fieldLength;

    //                int fieldIndex;

    //                ExField field;

    //                string combinedFieldName = fieldType.ToString("X") + fieldName1;

    //                if (FieldNameToFieldIndex.ContainsKey(combinedFieldName))
    //                {
    //                    fieldIndex = FieldNameToFieldIndex[combinedFieldName];
    //                    field = this.Fields[fieldIndex];
    //                }
    //                else
    //                {
    //                    fieldIndex = Fields.Count;
    //                    Fields.SetOrAdd(fieldIndex, new ExField() { Name = fieldName1, Type = fieldType });
    //                    FieldNameToFieldIndex[combinedFieldName] = fieldIndex;
    //                    field = this.Fields[fieldIndex];
    //                }

    //                //if (fieldIndex < lastFieldIndex)
    //                //{
    //                //    this.Rows.Add(row);
    //                //    row = new ExRow();
    //                //    lastFieldIndex = 0;
    //                //}

    //                string fieldName2 = br.ReadLengthIndexedString();
    //                if (fieldName1 != fieldName2)
    //                {
    //                    throw new InvalidDataException("Field Name does not match previous copy of Field Name: " + fieldName1 + " and " + fieldName2);
    //                }

    //                if (fieldType <= 0 || fieldType >= 6)
    //                {
    //                    throw new InvalidDataException("Unknown Field Type: " + fieldType.ToString("X"));
    //                }

    //                ExValue value = new ExValue();
    //                value.Type = fieldType;

    //                if (fieldType == 1)
    //                {
    //                    value.IntValue = br.ReadInt32();
    //                }
    //                else if (fieldType == 2)
    //                {
    //                    value.FloatValue = br.ReadSingle();
    //                }
    //                else if (fieldType == 3)
    //                {
    //                    value.StringValue = br.ReadLengthIndexedString();
    //                }
    //                else if (fieldType == 4)
    //                {
    //                    throw new InvalidDataException("Field Type 4 not supported");
    //                }
    //                else if (fieldType == 5)
    //                {
    //                    //needs confirmation?
    //                    //Array
    //                    int arrCount = br.ReadInt32();

    //                    var newRows = new ExRowCollection();

    //                    for (int i = 0; i < arrCount; i++)
    //                    {
    //                        int arrElementType = br.ReadInt32();

    //                        //create subfield if it doesn't already exist
    //                        if (field.SubFields == null)
    //                        {
    //                            field.SubFields = new ExFieldCollection();
    //                        }
    //                        if (field.SubFields.Count == 0)
    //                        {
    //                            ExField newField = new ExField();
    //                            newField.Type = arrElementType;
    //                            if (arrElementType == 1)
    //                            {
    //                                newField.Name = "intValue";
    //                            }
    //                            else if (arrElementType == 2)
    //                            {
    //                                newField.Name = "floatValue";
    //                            }
    //                            else if (arrElementType == 3)
    //                            {
    //                                newField.Name = "stringValue";
    //                            }
    //                            else
    //                            {
    //                                throw new InvalidDataException("Array element type " + arrElementType.ToString("X") + " not supported");
    //                            }
    //                            field.SubFields.Add(newField);
    //                        }

    //                        ExValue value2 = new ExValue();
    //                        value2.Type = arrElementType;
    //                        int length = br.ReadInt32();
    //                        if (arrElementType == 1)
    //                        {
    //                            int intValue = br.ReadInt32();
    //                            value2.IntValue = intValue;
    //                        }
    //                        else if (arrElementType == 2)
    //                        {
    //                            float floatValue = br.ReadSingle();
    //                            value2.FloatValue = floatValue;
    //                        }
    //                        else if (arrElementType == 3)
    //                        {
    //                            string stringValue = br.ReadLengthIndexedString();
    //                            value2.StringValue = stringValue;
    //                        }
    //                        else
    //                        {
    //                            throw new InvalidDataException("Array element type " + arrElementType.ToString("X") + " not supported");
    //                        }
    //                        var newRow = new ExRow(1);
    //                        newRow.Add(value2);
    //                        newRows.Add(newRow);
    //                    }
    //                    value.SubValues = newRows;
    //                }

    //                row.SetOrAdd(fieldIndex, value);

    //                long endAddress = br.BaseStream.Position;
    //                if (fieldEndAddress != endAddress)
    //                {
    //                    throw new InvalidDataException("Value has the wrong length");
    //                }

    //                unknownColumnValue = br.ReadInt32();
    //                if (unknownColumnValue != 0)
    //                {
    //                    throw new InvalidDataException("Expected 0, got " + unknownColumnValue.ToString("X") + " instead");
    //                }
    //                //lastFieldIndex = fieldIndex;
    //            }
    //            else
    //            {
    //                throw new InvalidDataException("Expected 0 or 1, got " + hasValue.ToString("X") + " instead");
    //            }
    //        }
    //        if (row != null && row.Count > 1)
    //        {
    //            this.Rows.Add(row);
    //        }
    //        if (rowCountHint != Rows.Count)
    //        {

    //        }
    //        //if (fieldCountHint + 1 != Fields.Count)
    //        //{

    //        //}
    //    }
    //}

    public class ExTable : IReadable, IWritable, ICloneable
    {
        public int StartAddress;
        public int BlockType;
        public string Name;
        public string StringValue;
        public int IntValue;
        public float FloatValue;

        public byte[] OriginalBytes;

        public int SizeInBytes;
        public ExFieldCollection Fields = new ExFieldCollection();
        public ExRowCollection Rows = new ExRowCollection();

        public void Read(BinaryReader br)
        {
            StartAddress = (int)(br.BaseStream.Position);
            BlockType = br.ReadInt32();
            SizeInBytes = br.ReadInt32();

            if (SizeInBytes < 0 || SizeInBytes + br.BaseStream.Position > br.BaseStream.Length)
            {
                throw new InvalidDataException("Invalid size for data block");
            }

            this.Name = br.ReadLengthIndexedString();

            int pos = (int)br.BaseStream.Position;
            int byteOffsetWithinData = (int)br.BaseStream.Position - StartAddress;

            int bytesToRead = SizeInBytes + 8 - (byteOffsetWithinData);
            OriginalBytes = br.ReadBytes(bytesToRead);
            br.BaseStream.Position = StartAddress + byteOffsetWithinData;


            int endAddress = StartAddress + SizeInBytes + 8;

            switch (BlockType)
            {
                case 1: //int
                    {
                        this.IntValue = br.ReadInt32();
                    }
                    break;
                case 2: //float
                    {
                        this.FloatValue = br.ReadSingle();
                    }
                    break;
                case 3: //string
                    {
                        this.StringValue = br.ReadLengthIndexedString();
                    }
                    break;
                case 4: //table
                    {
                        int fieldCount = br.ReadInt32();
                        this.Fields.Read(br, fieldCount);
                        int columnCount = br.ReadInt32();
                        int rowCount = br.ReadInt32();
                        Rows.Read(br, rowCount, columnCount);
                    }
                    break;
                case 5: //list of values (strings, etc)
                    {
                        int rowCount = br.ReadInt32();
                        Rows.Read2(br, rowCount, 1);
                    }
                    break;
                case 6: //???
                    {
                        var tree = new ExTree();
                        tree.Read(br);
                        tree.ToTable(this);

                        //var reader = new ExTable6Reader(this);
                        //reader.Read(br, endAddress);

                        //br.BaseStream.Position += bytesToRead;

                        //string[] strings = Util.GetStrings(OriginalBytes);
                        //Rows.AddRange(strings);
                    }
                    break;
                default:
                    {
                        throw new InvalidDataException("Invalid block type " + BlockType.ToString());
                    }
                    break;
            }

            if (br.BaseStream.Position != endAddress)
            {
                throw new InvalidDataException("Not at the correct address after reading a block.");
            }
        }

        public void Write(BinaryWriter bw)
        {
            this.StartAddress = (int)bw.BaseStream.Position;

            bw.Write(BlockType);
            long addressOfSizeWord = bw.BaseStream.Position;
            //SizeInBytes placeholder
            bw.Write(0);
            long dataStartAddress = bw.BaseStream.Position;

            bw.WriteLengthIndexedString(this.Name);

            switch (BlockType)
            {
                case 1: //int
                    {
                        bw.Write((int)this.IntValue);
                    }
                    break;
                case 2: //float
                    {
                        bw.Write((float)this.FloatValue);
                    }
                    break;
                case 3: //string
                    {
                        bw.WriteLengthIndexedString(this.StringValue);
                    }
                    break;
                case 4: //table
                    {
                        bw.Write((int)Fields.Count);
                        Fields.Write(bw);
                        bw.Write(Rows.ColumnCount);
                        bw.Write(Rows.RowCount);
                        Rows.Write(bw);
                    }
                    break;
                case 5: //list of values (strings, etc)
                    {
                        bw.Write(Rows.RowCount);
                        Rows.Write(bw);
                    }
                    break;
                case 6: //???
                    {
                        MemoryStream originalStream = new MemoryStream(this.OriginalBytes);
                        BinaryReader br = new BinaryReader(originalStream);
                        ExTree originalTree = new ExTree();
                        originalTree.Read(br);

                        var tree = originalTree.Clone();
                        tree.ReadTable(this);
                        tree.Write(bw);

                        if (Debugger.IsAttached)
                        {

                            MemoryStream temp = new MemoryStream();
                            BinaryWriter bwTemp = new BinaryWriter(temp);

                            tree.Write(bwTemp);

                            byte[] newBytes = temp.ToArray();
                            if (!this.OriginalBytes.SequenceEqual(newBytes))
                            {
                                File.WriteAllBytes("C:\\original.bin", OriginalBytes);
                                File.WriteAllBytes("C:\\bad.bin", newBytes);

                            }
                        }

                        ////not yet figured out, just dump strings for now
                        //var strings = getRowsAsStrings();

                        //byte[] newBytes = Util.ReplaceStrings(OriginalBytes, strings);
                        //bw.Write(newBytes);
                    }
                    break;
                default:
                    {
                        throw new InvalidDataException("Invalid block type " + BlockType.ToString());
                    }
                    break;
            }
            long endPos = bw.BaseStream.Position;
            this.SizeInBytes = (int)(endPos - dataStartAddress);

            bw.BaseStream.Position = addressOfSizeWord;
            bw.Write((int)this.SizeInBytes);
            bw.BaseStream.Position = endPos;
        }

        private string[] getRowsAsStrings()
        {
            var strings = this.Rows.Select(r => r[0].StringValue).ToArray();
            return strings;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            if (this.BlockType == 4)
            {
                foreach (var field in Fields)
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(", ");
                    }
                    sb.Append(field.ToString());
                }

                return Name + ": " + sb.ToString();
            }
            else if (this.BlockType == 1)
            {
                return Name + " = " + IntValue.ToString();
            }
            else if (this.BlockType == 2)
            {
                return Name + " = " + FloatValue.ToString();
            }
            else if (this.BlockType == 3)
            {
                return Name + " = " + StringValue;
            }
            else if (this.BlockType == 5)
            {
                return Name + ": " + Rows.Count.ToString() + " rows";
            }
            return base.ToString();
        }

        static class DataTableToExTable
        {
            public static void GetFieldsFromDataTable(DataTable dataTable, ICollection<ExField> dataTableFields)
            {
                foreach (DataColumn column in dataTable.Columns)
                {
                    ExField field = new ExField();
                    field.Name = column.ColumnName;
                    if (column.DataType == typeof(int))
                    {
                        field.Type = 1;
                    }
                    else if (column.DataType == typeof(float))
                    {
                        field.Type = 2;
                    }
                    else if (column.DataType == typeof(string))
                    {
                        field.Type = 3;
                    }
                    else if (column.DataType == typeof(DataTable))
                    {
                        if (column.ExtendedProperties.ContainsKey("template"))
                        {
                            field.Type = 4;
                            var tableTemplate = column.ExtendedProperties["template"] as DataTable;
                            field.SubFields = new ExFieldCollection();
                            GetFieldsFromDataTable(tableTemplate, field.SubFields);
                        }
                    }
                    else
                    {

                    }
                    dataTableFields.Add(field);
                }
            }

            public static void GetValuesFromDataTableRow(DataTable dataTable, int y, ICollection<ExValue> columns)
            {
                DataRow row = dataTable.Rows[y];
                for (int x = 0; x < dataTable.Columns.Count; x++)
                {
                    ExValue col;
                    if (row.IsNull(x))
                    {
                        col = null;
                    }
                    else
                    {
                        col = new ExValue();

                        DataColumn column = dataTable.Columns[x];
                        if (column.DataType == typeof(int))
                        {
                            col.Type = 1;
                            col.IntValue = row.Field<int>(x);
                        }
                        else if (column.DataType == typeof(float))
                        {
                            col.Type = 2;
                            col.FloatValue = row.Field<float>(x);
                        }
                        else if (column.DataType == typeof(string))
                        {
                            col.Type = 3;
                            col.StringValue = row.Field<string>(x);
                        }
                        else if (column.DataType == typeof(DataTable))
                        {
                            col.Type = 4;
                            var subTable = row.Field<DataTable>(x);
                            col.SubValues = new ExRowCollection();
                            GetRowsFromDataTable(subTable, col.SubValues);
                        }
                    }
                    columns.Add(col);
                }
            }

            public static void GetRowsFromDataTable(DataTable dataTable, ICollection<ExRow> rows)
            {
                int y = 0;

                foreach (DataRow dataRow in dataTable.Rows)
                {
                    ExRow row = new ExRow();
                    GetValuesFromDataTableRow(dataTable, y, row);
                    rows.Add(row);
                    y++;
                }
            }
        }

        public void ReadDataTable(DataTable dataTable)
        {
            int rowCount = this.RowCount;
            int columnCount = this.ColumnCount;

            dataTable = ExTable.ReNestDataTable(dataTable);

            if (this.BlockType == 4)
            {
                var newFields = new ExFieldCollection();
                DataTableToExTable.GetFieldsFromDataTable(dataTable, newFields);

                if (newFields.SequenceEqual(this.Fields))
                {

                }
                else
                {
                    this.Fields = newFields;
                }
            }

            this.Rows.Clear();
            if (!String.IsNullOrEmpty(dataTable.TableName))
            {
                this.Name = dataTable.TableName;
            }
            DataTableToExTable.GetRowsFromDataTable(dataTable, this.Rows);

            if (this.BlockType == 1)
            {
                this.IntValue = this[0][1].IntValue;
            }
            else if (this.BlockType == 2)
            {
                this.FloatValue = this[0][1].FloatValue;
            }
            else if (this.BlockType == 3)
            {
                this.StringValue = this[0][1].StringValue;
            }
            else if (this.BlockType == 5)
            {
                for (int i = 0; i < this.Rows.Count; i++)
                {
                    var row = this.Rows[i];
                    var value = row[0];
                    row[0] = new ExValue2() { Type = value.Type, FloatValue = value.FloatValue, IntValue = value.IntValue, StringValue = value.StringValue };
                }
            }
        }

        public void ReadTabSeparatedFileText(string fileText)
        {
            var dataTable = TabSeparatedFileToDataTable(fileText, this.BlockType);
            ReadDataTable(dataTable);
        }

        public static DataTable TabSeparatedFileToDataTable(string tabSeparatedFile, int blockType)
        {
            DataTable table = new DataTable();
            if (blockType <= 3)
            {
                string[] pieces = tabSeparatedFile.Split('=');
                if (pieces.Length >= 2)
                {
                    var col1 = table.Columns.Add("name");
                    var col2 = table.Columns.Add("value");
                    string name = pieces[0];
                    string stringValue = pieces[1];
                    table.TableName = name;

                    if (blockType == 1)
                    {
                        col2.DataType = typeof(int);
                        int intValue = 0;
                        if (int.TryParse(stringValue, out intValue))
                        {
                            table.Rows.Add(name, intValue);
                        }
                        else
                        {
                            table.Rows.Add(name, DBNull.Value);
                        }
                    }
                    else if (blockType == 2)
                    {
                        col2.DataType = typeof(float);
                        double doubleValue = 0;
                        if (double.TryParse(stringValue, out doubleValue))
                        {
                            float floatValue = (float)doubleValue;
                            table.Rows.Add(name, floatValue);
                        }
                        else
                        {
                            table.Rows.Add(name, DBNull.Value);
                        }
                    }
                    else if (blockType == 3)
                    {
                        col2.DataType = typeof(string);
                        stringValue = Util.UnescapeString(stringValue);
                        table.Rows.Add(name, stringValue);
                    }
                }
            }
            else if (blockType >= 4)
            {
                string tableName = "";
                string[] lines = tabSeparatedFile.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                bool hasName = blockType == 4 || blockType == 5 || blockType == 6;
                bool hasSchema = blockType == 4 || blockType == 5 || blockType == 6;
                bool anyStructs = false;

                if (!hasSchema)
                {
                    table.Columns.Add("data", typeof(string));
                }

                for (int lineNumber = 0; lineNumber < lines.Length; lineNumber++)
                {
                    string line = lines[lineNumber];
                    if (line.StartsWith("#"))
                    {
                        continue;
                    }
                    if (line.Length == 0)
                    {
                        if (lineNumber == lines.Length - 1)
                        {
                            continue;
                        }
                        if (table.Columns.Count > 1)
                        {
                            continue;
                        }
                    }
                    if (hasName)
                    {
                        tableName = line.Trim();
                        table.TableName = tableName;
                        hasName = false;
                        continue;
                    }
                    if (hasSchema)
                    {
                        if (line.StartsWith("int ", StringComparison.OrdinalIgnoreCase) ||
                            line.StartsWith("float ", StringComparison.OrdinalIgnoreCase) ||
                            line.StartsWith("string ", StringComparison.OrdinalIgnoreCase))
                        {
                            string[] fields = line.Split('\t');

                            for (int x = 0; x < fields.Length; x++)
                            {
                                string field = fields[x].Trim();
                                string dataType, fieldName;

                                bool hasSpace = SplitOnce(field, ' ', out dataType, out fieldName);
                                if (!hasSpace)
                                {
                                    throw new InvalidDataException("Field must contain Datatype, a space, then the field name");
                                }
                                var column = table.Columns.Add(fieldName);
                                if (dataType.Equals("int", StringComparison.OrdinalIgnoreCase))
                                {
                                    column.DataType = typeof(int);
                                }
                                else if (dataType.Equals("float", StringComparison.OrdinalIgnoreCase))
                                {
                                    column.DataType = typeof(float);
                                }
                                else if (dataType.Equals("string", StringComparison.OrdinalIgnoreCase))
                                {
                                    column.DataType = typeof(string);
                                }
                                else
                                {
                                    throw new InvalidDataException("Unknown data type: " + dataType);
                                }
                            }
                            hasSchema = false;
                            continue;
                        }
                        else
                        {
                            table.Columns.Add("value", typeof(string));
                            hasSchema = false;
                        }
                    }

                    string[] values = line.Split('\t');

                    if (values.Length != table.Columns.Count)
                    {
                        if (values.Length > table.Columns.Count)
                        {
                            values = values.Take(table.Columns.Count).ToArray();
                        }
                        else if (values.Length < table.Columns.Count)
                        {
                            values = values.Concat(Enumerable.Repeat("", table.Columns.Count - values.Length)).ToArray();
                        }

                        OnWarning("line does not have the correct numer of columns");
                    }

                    var row = table.Rows.Add();

                    for (int x = 0; x < values.Length; x++)
                    {
                        string value = values[x];
                        var dataType = table.Columns[x].DataType;
                        if (dataType == typeof(int))
                        {
                            int intValue = 0;
                            if (int.TryParse(value, out intValue))
                            {
                                row.SetField(x, intValue);
                            }
                            else
                            {
                                row.SetField(x, DBNull.Value);
                            }
                        }
                        else if (dataType == typeof(float))
                        {
                            double doubleValue = 0;
                            if (double.TryParse(value, out doubleValue))
                            {
                                float floatValue = (float)doubleValue;
                                row.SetField(x, floatValue);
                            }
                            else
                            {
                                row.SetField(x, DBNull.Value);
                            }

                        }
                        else if (dataType == typeof(string))
                        {
                            string stringValue = value as string;
                            if (stringValue == "")
                            {
                                row.SetField(x, DBNull.Value);
                            }
                            else
                            {
                                stringValue = Util.UnescapeString(value as string);
                                row.SetField(x, stringValue);
                            }
                        }
                    }
                }
            }
            return table;
        }

        public static event EventHandler<ErrorEventArgs> Warning;

        public static void OnWarning(string warningMessage)
        {
            if (Warning != null)
            {
                Warning(null, new ErrorEventArgs(new Exception(warningMessage)));
            }
        }

        static bool SplitOnce(string str, char c, out string str1, out string str2)
        {
            int index = str.IndexOf(c);
            if (index == -1)
            {
                str1 = str;
                str2 = "";
                return false;
            }
            str1 = str.Substring(0, index);
            str2 = str.Substring(index + 1).Trim();
            return true;
        }

        public static DataTable ReNestDataTable(DataTable dataTable)
        {
            return DataTableNester.ReNestDataTable(dataTable);
        }

        class DataTableNester
        {
            DataTable dataTable, newDataTable;

            public static DataTable ReNestDataTable(DataTable dataTable)
            {
                bool needsNesting = false;
                needsNesting = dataTable.Columns.OfType<DataColumn>().Any(c => c.ColumnName.Contains('.'));
                if (!needsNesting)
                {
                    return dataTable;
                }

                var newDataTable = new DataTable();
                var dataTableNester = new DataTableNester(dataTable, newDataTable);
                dataTableNester.ReNestDataTable();
                return newDataTable;
            }

            private void ReNestDataTable()
            {
                ReNestColumns();
                ReNestData();

            }

            static bool ValueIsNull(object value)
            {
                return value == null || value == DBNull.Value;// || (value as string) == "";
            }

            private void ReNestData()
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    //find lowest recursion level in the row
                    int lowestNonNullRecursionDepth = int.MaxValue;
                    for (int x = 0; x < dataTable.Columns.Count; x++)
                    {
                        object value = row.ItemArray[x];
                        if (!ValueIsNull(value))
                        {
                            int recursionDepth = RecursionDepthByColumn[x];
                            if (recursionDepth < lowestNonNullRecursionDepth)
                            {
                                lowestNonNullRecursionDepth = recursionDepth;
                            }
                        }
                    }

                    if (lowestNonNullRecursionDepth == 0)
                    {
                        int x = 0;
                        CreateAndCopyRow(newDataTable, row, ref x);
                    }
                    else
                    {
                        for (int x = 0; x < dataTable.Columns.Count; x++)
                        {
                            if (RecursionDepthByColumn[x] == lowestNonNullRecursionDepth && !ValueIsNull(row.ItemArray[x]))
                            {
                                var subTable = this.columnToMostRecentElement[x];
                                CreateAndCopyRow(subTable, row, ref x);
                                x--;
                            }
                        }
                    }
                }
            }

            private void CreateAndCopyRow(DataTable newDataTable, DataRow originalRow, ref int x)
            {
                var newRow = newDataTable.Rows.Add();
                for (int c = 0; c < newDataTable.Columns.Count; c++)
                {
                    DataColumn column = newDataTable.Columns[c];
                    if (column.DataType == typeof(DataTable))
                    {
                        var template = column.ExtendedProperties["template"] as DataTable;
                        var subTable = template.Clone();
                        newRow.SetField<DataTable>(c, subTable);
                        this.columnToMostRecentElement[x] = subTable;
                        CreateAndCopyRow(subTable, originalRow, ref x);
                    }
                    else
                    {
                        newRow[c] = originalRow[x];
                        x++;
                    }
                }
            }

            List<int> RecursionDepthByColumn = new List<int>();
            Dictionary<int, DataColumn> sourceColumnToDestColumn = new Dictionary<int, DataColumn>();
            Dictionary<string, DataColumn> columnNameToColumn = new Dictionary<string, DataColumn>();
            Dictionary<int, DataTable> columnToMostRecentElement = new Dictionary<int, DataTable>();

            DataColumn GetColumn(string structName)
            {
                var existingColumn = columnNameToColumn.GetOrNull(structName);
                if (existingColumn != null)
                {
                    return existingColumn;
                }
                else
                {
                    int lastDot = structName.LastIndexOf('.');
                    if (lastDot >= 0)  //contains dot, add this to a parent column
                    {

                        string structName2 = structName.Substring(0, lastDot);
                        string memberName = structName.Substring(lastDot + 1);

                        var parentColumn = GetColumn(structName2);
                        DataTable parentTable;
                        if (parentColumn.DataType != typeof(DataTable))
                        {
                            parentColumn.DataType = typeof(DataTable);
                            parentTable = new DataTable(structName2);
                            parentColumn.ExtendedProperties.Add("template", parentTable);
                        }
                        else
                        {
                            parentTable = parentColumn.ExtendedProperties["template"] as DataTable;
                        }

                        var newColumn = new DataColumn(memberName);
                        parentTable.Columns.Add(newColumn);
                        columnNameToColumn[structName] = newColumn;
                        return newColumn;
                    }
                    else //no dot, make a new column which will become a parent
                    {
                        var newColumn = new DataColumn(structName, typeof(DataTable));
                        var template = new DataTable(structName);
                        newColumn.ExtendedProperties["template"] = template;
                        this.newDataTable.Columns.Add(newColumn);
                        columnNameToColumn[structName] = newColumn;
                        return newColumn;
                    }
                }
            }

            private void ReNestColumns()
            {
                this.RecursionDepthByColumn.Clear();
                for (int i = 0; i < dataTable.Columns.Count; i++)
                {
                    DataColumn column = dataTable.Columns[i];
                    string columnName = column.ColumnName;
                    int lastDot = columnName.LastIndexOf('.');
                    if (lastDot != -1)
                    {
                        var newColumn = GetColumn(columnName);
                        newColumn.DataType = column.DataType;

                        int dotCount = GetDotCount(columnName);
                        this.RecursionDepthByColumn.Add(dotCount);
                        sourceColumnToDestColumn[i] = newColumn;
                    }
                    else
                    {
                        var newColumn = this.newDataTable.Columns.Add(column.ColumnName, column.DataType);
                        this.RecursionDepthByColumn.Add(0);
                        sourceColumnToDestColumn[i] = newColumn;
                    }
                }
            }

            private static int GetDotCount(string columnName)
            {
                int dotCount = columnName.Count(c => c == '.');
                return dotCount;
            }

            private DataTableNester(DataTable dataTable, DataTable newDataTable)
            {
                this.dataTable = dataTable;
                this.newDataTable = newDataTable;
            }
        }

        class DataTableFlattener
        {
            DataTable dataTable, newDataTable;
            List<List<tickEvent>> tickEvents = new List<List<tickEvent>>();
            List<int> lastY = new List<int>();
            List<int> cursors = new List<int>();
            List<int> Ys = new List<int>();
            int highestRecursionLevel = 0;

            DataRow outputRow;

            private DataTableFlattener(DataTable dataTable, DataTable newDataTable)
            {
                this.dataTable = dataTable;
                this.newDataTable = newDataTable;
            }

            class tickEvent
            {
                public int y;
                public int depth;
                public object value;
                public int[] parentYs;
            }

            public static DataTable FlattenDataTable(DataTable dataTable)
            {
                if (!AnyNestedTables(dataTable))
                {
                    return dataTable;
                }

                DataTable newDataTable = new DataTable();
                newDataTable.TableName = dataTable.TableName;
                DataTableFlattener flattener = new DataTableFlattener(dataTable, newDataTable);
                flattener.FlattenTable();
                return newDataTable;
            }

            private void FlattenTable()
            {
                tickEvents.Clear();
                cursors.Clear();
                lastY.Clear();
                FlattenColumns("", newDataTable, dataTable);
                for (int i = 0; i < newDataTable.Columns.Count; i++)
                {
                    tickEvents.Add(new List<tickEvent>());
                    cursors.Add(0);
                    lastY.Add(0);
                }
                FlattenData();
            }

            private void FlattenData()
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    FlattenDataRow(row);
                }
            }

            private void FlattenDataRow(DataRow row)
            {
                for (int i = 0; i < this.tickEvents.Count; i++)
                {
                    this.cursors[i] = 0;
                    this.tickEvents[i].Clear();
                    this.lastY[i] = 0;
                }
                BuildTickEvents(row);
                PlayTickEvents();
            }

            private void BuildTickEvents(DataTable subTable, ref int x, int recursionLevel, List<int> parentY)
            {
                if (recursionLevel > highestRecursionLevel)
                {
                    highestRecursionLevel = recursionLevel;
                }
                int x0 = x;
                for (int y = 0; y < subTable.Rows.Count; y++)
                {
                    x = x0;
                    var row = subTable.Rows[y];
                    for (int c = 0; c < subTable.Columns.Count; c++)
                    {
                        object value = row[c];
                        var subTable2 = value as DataTable;
                        if (subTable2 != null)
                        {
                            parentY.Add(y);
                            BuildTickEvents(subTable2, ref x, recursionLevel + 1, parentY);
                            parentY.RemoveAt(parentY.Count - 1);
                        }
                        else
                        {
                            this.tickEvents[x].Add(new tickEvent() { depth = recursionLevel, y = y, value = value, parentYs = parentY.ToArray() });
                            x++;
                        }
                    }
                }
            }

            private void BuildTickEvents(DataRow row)
            {
                int x = 0;
                List<int> parentY = new List<int>();
                parentY.Add(0);

                for (int c = 0; c < dataTable.Columns.Count; c++)
                {
                    object value = row[c];
                    var subTable = value as DataTable;
                    if (subTable != null)
                    {
                        BuildTickEvents(subTable, ref x, 1, parentY);
                    }
                    else
                    {
                        this.tickEvents[x].Add(new tickEvent() { depth = 0, y = 0, value = value, parentYs = new int[] { -1 } });
                        x++;
                    }
                }
            }

            private void PlayTickEvents()
            {
                outputRow = null;
                PlayTickEventsAllColumns();
                int y = 1;
                int recursionLevel = this.highestRecursionLevel;

                Ys.Clear();
                for (int i = 0; i < this.highestRecursionLevel + 1; i++)
                {
                    Ys.Add(0);
                }

                outputRow = null;
                while (true)
                {
                    //look for Y incrementing at the same recursion level
                    if (PeekRow(y, recursionLevel))
                    {
                        if (outputRow == null)
                        {
                            outputRow = newDataTable.Rows.Add();
                        }
                        for (int x = 0; x < this.tickEvents.Count; x++)
                        {
                            if (Peek2(x, y, recursionLevel))
                            {
                                PlayTickEvent(x);
                            }
                        }
                        outputRow = null;
                        y++;

                    }
                    else
                    {
                    DecrementAgain:
                        Ys[recursionLevel] = y;
                        recursionLevel--;
                        if (recursionLevel <= 0)
                        {
                            return;
                        }
                        y = Ys[recursionLevel];
                        y++;
                        Ys[recursionLevel] = y;

                    tryAgain:
                        if (PeekRow(y, recursionLevel))
                        {
                            if (outputRow == null)
                            {
                                outputRow = newDataTable.Rows.Add();
                            }
                            for (int x = 0; x < this.tickEvents.Count; x++)
                            {
                                if (Peek2(x, y, recursionLevel))
                                {
                                    PlayTickEvent(x);
                                }
                            }
                            recursionLevel++;
                            Ys[recursionLevel] = 0;
                            y = 0;
                            if (recursionLevel < highestRecursionLevel)
                            {
                                goto tryAgain;
                            }


                            recursionLevel = highestRecursionLevel;
                            y = 0;
                        }
                        else
                        {
                            goto DecrementAgain;
                        }
                    }
                }

            }

            bool PeekRow(int y, int recursionLevel)
            {
                for (int x = 0; x < this.tickEvents.Count; x++)
                {
                    bool found = Peek2(x, y, recursionLevel);
                    if (found)
                    {
                        return true;
                    }
                }
                return false;
            }

            private bool Peek2(int x, int y, int recursionLevel)
            {
                var ev = PeekTickEvent(x);
                if (ev != null && ev.depth == recursionLevel && ev.y == y)
                {
                    var desiredParentYs = Ys.Take(recursionLevel);
                    if (ev.parentYs.SequenceEqual(desiredParentYs))
                    {
                        return true;
                    }
                    else
                    {

                    }
                }
                return false;
            }


            tickEvent PeekTickEvent(int x)
            {
                int cursor = this.cursors[x];
                var tickEvents = this.tickEvents[x];
                var tickEvent = tickEvents.GetOrNull(cursor);
                return tickEvent;
            }


            private void PlayTickEvent(int x)
            {
                int cursor = this.cursors[x];
                var tickEvents = this.tickEvents[x];
                var tickEvent = tickEvents.GetOrNull(cursor);
                cursor++;
                this.cursors[x] = cursor;
                if (tickEvent != null)
                {
                    this.lastY[x] = tickEvent.y;
                    if (outputRow == null)
                    {
                        outputRow = newDataTable.Rows.Add();
                    }
                    outputRow[x] = tickEvent.value;
                }
            }

            private void PlayTickEventsAllColumns()
            {
                for (int x = 0; x < tickEvents.Count; x++)
                {
                    PlayTickEvent(x);
                }
            }

            private static void FlattenColumns(string prefix, DataTable newDataTable, DataTable dataTable)
            {
                for (int i = 0; i < dataTable.Columns.Count; i++)
                {
                    var column = dataTable.Columns[i];
                    if (column.DataType != typeof(DataTable))
                    {
                        newDataTable.Columns.Add(prefix + column.ColumnName, column.DataType);
                    }
                    else
                    {
                        var template = column.ExtendedProperties["template"] as DataTable;
                        FlattenColumns(prefix + column.ColumnName + ".", newDataTable, template);
                    }
                }
            }

            private static bool AnyNestedTables(DataTable dataTable)
            {
                bool anyNestedTables;
                anyNestedTables = dataTable.Columns.OfType<DataColumn>().Any(c => c.DataType == typeof(DataTable));
                return anyNestedTables;
            }
        }

        public DataTable ToDataTable()
        {
            DataTable newDataTable = new DataTable();
            newDataTable.TableName = this.Name;
            newDataTable.ExtendedProperties.Add("BlockType", this.BlockType);
            if (this.BlockType <= 3)
            {
                newDataTable.Columns.Add("VariableName", typeof(string));
                if (this.BlockType == 1)
                {
                    newDataTable.Columns.Add("IntValue", typeof(int));
                    var row = newDataTable.Rows.Add(this.Name, this.IntValue);
                }
                else if (this.BlockType == 2)
                {
                    newDataTable.Columns.Add("FloatValue", typeof(float));
                    var row = newDataTable.Rows.Add(this.Name, this.FloatValue);
                }
                else if (this.BlockType == 3)
                {
                    newDataTable.Columns.Add("StringValue", typeof(string));
                    var row = newDataTable.Rows.Add(this.Name, this.StringValue);
                }
            }
            else
            {
                if (this.BlockType == 6)
                {

                }

                AddColumnsForFields(newDataTable);

                //build table data
                ToDataTable(newDataTable, this.Rows);
            }
            return newDataTable;
        }

        private void AddColumnsForFields(DataTable newDataTable)
        {
            if (this.BlockType == 4 || this.BlockType == 6)
            {
                foreach (var field in Fields)
                {
                    DataColumn dataColumn = FieldToDataColumn(field);
                    if (newDataTable.Columns.Contains(dataColumn.ColumnName))
                    {
                        dataColumn.ColumnName += "_2";
                        newDataTable.Columns.Add(dataColumn);
                    }
                    else
                    {
                        newDataTable.Columns.Add(dataColumn);
                    }
                }
            }
            else if (this.BlockType == 5)
            {
                bool allMatch = true;
                //check for common data type
                var firstElement = this.GetFirstElement();
                if (firstElement != null)
                {
                    foreach (var row in this.Rows)
                    {
                        foreach (var element in row)
                        {
                            if (element.Type != firstElement.Type)
                            {
                                allMatch = false;
                                goto exitLoop;
                            }
                        }
                    }
                exitLoop:
                    ;
                }
                if (allMatch)
                {
                    if (firstElement.Type == 1)
                    {
                        newDataTable.Columns.Add("intValue", typeof(int));
                    }
                    if (firstElement.Type == 2)
                    {
                        newDataTable.Columns.Add("floatValue", typeof(float));
                    }
                    if (firstElement.Type == 3)
                    {
                        newDataTable.Columns.Add("stringValue", typeof(string));
                    }
                }
                else
                {
                    newDataTable.Columns.Add("mixedValue", typeof(string));
                }
            }
            else if (this.BlockType == 6)
            {
                //newDataTable.Columns.Add("extractedString", typeof(string));
            }
        }

        private static void ToDataTable(DataTable dataTable, IEnumerable<ExRow> rows)
        {
            foreach (var row in rows)
            {
                var tableRow = dataTable.Rows.Add();
                int x = 0;
                foreach (var value in row)
                {
                    if (value != null)
                    {
                        var template = dataTable.Columns[x].ExtendedProperties["template"] as DataTable;
                        if (value.Type == 4 || value.Type == 5 || template != null)
                        {
                            if (template != null)
                            {
                                var newDataTable = template.Clone();
                                if (value.SubValues == null)
                                {
                                    if (value.Type == 1)
                                    {
                                        newDataTable.Rows.Add(value.IntValue);
                                    }
                                    else if (value.Type == 2)
                                    {
                                        newDataTable.Rows.Add(value.FloatValue);
                                    }
                                    else if (value.Type == 3)
                                    {
                                        newDataTable.Rows.Add(value.StringValue);
                                    }
                                    else
                                    {

                                    }
                                }
                                else
                                {
                                    ToDataTable(newDataTable, value.SubValues);
                                }
                                tableRow.SetField(x, newDataTable);
                            }
                        }
                        else if (value.Type == 1)
                        {
                            tableRow.SetField(x, value.IntValue);
                        }
                        else if (value.Type == 2)
                        {
                            tableRow.SetField(x, value.FloatValue);
                        }
                        else if (value.Type == 3)
                        {
                            tableRow.SetField(x, value.StringValue);
                        }
                    }
                    else
                    {
                        tableRow.SetField<DBNull>(x, DBNull.Value);
                    }
                    x++;
                }
            }
        }

        private static DataColumn FieldToDataColumn(ExField field)
        {
            DataColumn dataColumn = new DataColumn();
            dataColumn.ColumnName = field.Name;
            if (field.Type == 1)
            {
                dataColumn.DataType = typeof(int);
            }
            else if (field.Type == 2)
            {
                dataColumn.DataType = typeof(float);
            }
            else if (field.Type == 3)
            {
                dataColumn.DataType = typeof(string);
            }
            else if (field.Type == 4 || field.Type == 5)
            {
                dataColumn.DataType = typeof(DataTable);

                DataTable templateTable = new DataTable();
                templateTable.TableName = field.Name;

                foreach (var subField in field.SubFields)
                {
                    DataColumn subFieldColumn = FieldToDataColumn(subField);
                    templateTable.Columns.Add(subFieldColumn);
                }
                dataColumn.ExtendedProperties.Add("template", templateTable);
            }
            else if (field.Type == 5)
            {

            }
            return dataColumn;
        }

        public string ToTabSeparatedFile()
        {
            var dataTable = FlattenDataTable(this.ToDataTable());
            if (this.BlockType == 4 || this.BlockType == 5 || this.BlockType == 6)
            {
                StringBuilder sb = new StringBuilder();
                StringBuilder line = new StringBuilder();
                //if (this.BlockType != 6)
                {
                    sb.AppendLine(this.Name + "".PadLeft(dataTable.Columns.Count - 1, '\t'));
                    line.Length = 0;
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        if (line.Length > 0)
                        {
                            line.Append('\t');
                        }
                        if (column.DataType == typeof(int))
                        {
                            line.Append("int ");
                        }
                        else if (column.DataType == typeof(float))
                        {
                            line.Append("float ");
                        }
                        else if (column.DataType == typeof(string))
                        {
                            line.Append("string ");
                        }
                        line.Append(column.ColumnName);
                    }
                    sb.AppendLine(line.ToString());
                    line.Length = 0;
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    int x = 0;
                    foreach (object value in row.ItemArray)
                    {
                        if (x > 0)
                        {
                            sb.Append('\t');
                        }
                        if (value is int)
                        {
                            int intValue = (int)value;
                            sb.Append(intValue.ToString(CultureInfo.InvariantCulture));
                        }
                        else if (value is float)
                        {
                            float floatValue = (float)value;
                            double doubleValue = floatValue;
                            sb.Append(doubleValue.ToString(CultureInfo.InvariantCulture));
                        }
                        else if (value is string)
                        {
                            string stringValue = value as string;
                            sb.Append(Util.EscapeString(stringValue));
                        }
                        else if (value == DBNull.Value || value == null)
                        {
                            //do nothing
                        }
                        x++;
                    }
                    sb.AppendLine();
                }
                return sb.ToString();
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                string variableName = dataTable.Rows[0].Field<string>(0);
                sb.Append(variableName + "=");
                object value = dataTable.Rows[0].ItemArray[1];
                if (value is int)
                {
                    int intValue = (int)value;
                    sb.Append(intValue.ToString(CultureInfo.InvariantCulture));
                }
                else if (value is float)
                {
                    float floatValue = (float)value;
                    double doubleValue = floatValue;
                    sb.Append(doubleValue.ToString(CultureInfo.InvariantCulture));
                }
                else if (value is string)
                {
                    string stringValue = value as string;
                    sb.Append(Util.EscapeString(stringValue));
                }
                return sb.ToString();
            }
        }

        public ExRow this[int index]
        {
            get
            {
                return this.Rows[index];
            }
            set
            {
                this.Rows[index] = value;
            }
        }

        public int RowCount
        {
            get
            {
                return Rows.RowCount;
            }
        }

        public int ColumnCount
        {
            get
            {
                return Rows.ColumnCount;
            }
        }

        ExValue GetFirstElement()
        {
            if (this.Rows == null)
            {
                return null;
            }
            if (this.Rows.Count == 0)
            {
                return null;
            }
            return Rows.FirstOrDefault().FirstOrDefault();
        }

        public static DataTable FlattenDataTable(DataTable dataTable)
        {
            return DataTableFlattener.FlattenDataTable(dataTable);
        }

        public ExTable Clone()
        {
            var clone = (ExTable)this.MemberwiseClone();
            if (clone.Fields != null)
            {
                clone.Fields = clone.Fields.Clone();
            }
            if (clone.OriginalBytes != null)
            {
                clone.OriginalBytes = (byte[])clone.OriginalBytes.Clone();
            }
            if (clone.Rows != null)
            {
                clone.Rows = clone.Rows.Clone();
            }
            return clone;
        }

        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        #endregion
    }
}
