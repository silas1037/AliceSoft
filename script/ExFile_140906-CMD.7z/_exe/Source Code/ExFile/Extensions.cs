using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace ExFile
{
    public static class Extensions
    {
        private static Encoding shiftJis = Encoding.GetEncoding("shift-jis");

        public static string ReadLengthIndexedString(this BinaryReader br)
        {
            int length = br.ReadInt32();
            if ((length & 3) != 0 || length < 0 || length > 4096)
            {
                throw new InvalidDataException("Invalid string length");
            }
            if (br.BaseStream.Position + length > br.BaseStream.Length)
            {
                throw new InvalidDataException("String would exceed bounds of data stream");
            }
            byte[] bytes = br.ReadBytes(length);
            int numberOfValidBytes = TextConverter.NumberOfValidBytesAtPosition(bytes, 0);
            int numberOfValidBytesPadded = ((numberOfValidBytes - 1) | 3) + 1;
            if (numberOfValidBytesPadded != length)
            {
                throw new InvalidDataException("Actual string length does not match stated string length");
            }
            string str = shiftJis.GetString(bytes, 0, numberOfValidBytes);
            return str;
        }

        public static void WriteLengthIndexedString(this BinaryWriter bw, string text)
        {
            byte[] bytes = shiftJis.GetBytes(text);
            int length = bytes.Length;
            int lengthPadded = ((length - 1) | 3) + 1;

            //sanity check - make sure characters validate if read back
            if (length != TextConverter.NumberOfValidBytesAtPosition(bytes, 0))
            {
                throw new InvalidDataException("String would be rejected when reading it back");
            }


            bw.Write(lengthPadded);

            bw.Write(bytes);



            int bytesWritten = length;
            while (bytesWritten < lengthPadded)
            {
                bw.Write((byte)0);
                bytesWritten++;
            }
        }

        public static T ReadObject<T>(this BinaryReader br) where T : IReadable, new()
        {
            var obj = new T();
            obj.Read(br);
            return obj;
        }

        public static T ReadObject<T>(this BinaryReader br, int count) where T : IReadable2, new()
        {
            var obj = new T();
            obj.Read(br, count);
            return obj;
        }

        public static void ReadObjects<T>(this BinaryReader br, ICollection<T> list, int count) where T : IReadable, new()
        {
            for (int i = 0; i < count; i++)
            {
                var obj = br.ReadObject<T>();
                list.Add(obj);
            }
        }

        public static void ReadObjects<T>(this BinaryReader br, ICollection<T> list, int count, int count2) where T : IReadable2, new()
        {
            for (int i = 0; i < count; i++)
            {
                var obj = br.ReadObject<T>(count2);
                list.Add(obj);
            }
        }

        public static T[] ReadObjects<T>(this BinaryReader br, int count) where T : IReadable, new()
        {
            List<T> list = new List<T>();
            for (int i = 0; i < count; i++)
            {
                var obj = br.ReadObject<T>();
                list.Add(obj);
            }
            return list.ToArray();
        }

        public static void WriteObject<T>(this BinaryWriter bw, T obj) where T : IWritable, new()
        {
            obj.Write(bw);
        }

        public static void WriteObjects<T>(this BinaryWriter bw, IEnumerable<T> objs) where T : IWritable, new()
        {
            foreach (var obj in objs)
            {
                bw.WriteObject(obj);
            }
        }

        public static T GetOrNull<T>(this IList<T> list, int index)
        {
            if (index >= 0 && index < list.Count)
            {
                return list[index];
            }
            else
            {
                return default(T);
            }
        }

        public static TValue GetOrNull<TKey, TValue>(this IDictionary<TKey, TValue> dic, TKey key)
        {
            if (dic.ContainsKey(key))
            {
                return dic[key];
            }
            else
            {
                return default(TValue);
            }
        }

        public static void SetOrAdd<T>(this IList<T> list, int index, T value)
        {
            if (index >= 0 && index < list.Count)
            {
                list[index] = value;
                return;
            }
            if (index < 0)
            {
                throw new IndexOutOfRangeException();
            }
            while (list.Count < index)
            {
                list.Add(default(T));
            }
            list.Add(value);
        }
    }
}
