using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using ZLibNet;

namespace ExFile
{
    static class ExLoader
    {
        static byte[] table = GetTable();
        static byte[] tableInverse = GetTableInverse();
        private static byte[] GetTable()
        {
            byte[] table = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                int tmpfor = i;
                int tmp = tmpfor;
                tmp = (tmp & 0x55) + ((tmp >> 1) & 0x55);
                tmp = (tmp & 0x33) + ((tmp >> 2) & 0x33);
                tmp = (tmp & 0x0F) + ((tmp >> 4) & 0x0F);
                if ((tmp & 0x01) == 0)
                {
                    tmpfor = ((tmpfor << (8 - tmp)) | (tmpfor >> tmp)) & 0xFF;
                }
                else
                {
                    tmpfor = ((tmpfor >> (8 - tmp)) | (tmpfor << tmp)) & 0xFF;
                }
                table[i] = (byte)tmpfor;
            }
            return table;
        }

        private static byte[] GetTableInverse()
        {
            var table = GetTable();
            byte[] tableInverse = new byte[256];
            for (int i = 0; i < 256; i++)
            {
                int x = table[i];
                tableInverse[x] = (byte)i;
            }
            return tableInverse;
        }

        public static byte[] ReadExFile(string fileName)
        {
            int dummy;
            return ReadExFile(fileName, out dummy);
        }

        public static byte[] ReadExFile(string fileName, out int numberOfDataBlocks)
        {
            using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                var br = new BinaryReader(fs);
                byte[] header = br.ReadBytes(16);
                numberOfDataBlocks = br.ReadInt32();
                byte[] dataMark = br.ReadBytes(4);
                int compressedSize = br.ReadInt32();
                int uncompressedSize = br.ReadInt32();

                byte[] compressedData = br.ReadBytes(compressedSize);
                byte[] test = (byte[])compressedData.Clone();
                DecodeData(compressedData);
                byte[] decompressedData = Decompress(compressedData, uncompressedSize);
                return decompressedData;
            }
        }

        private static byte[] Decompress(byte[] compressedData, int uncompressedSize)
        {
            var zlibStream = new ZLibStream(new MemoryStream(compressedData), CompressionMode.Decompress);
            var br = new BinaryReader(zlibStream);
            byte[] bytes = br.ReadBytes(uncompressedSize);
            return bytes;
        }

        public static void DecodeData(byte[] compressedData)
        {
            for (int i = 0; i < compressedData.Length; i++)
            {
                compressedData[i] = table[compressedData[i]];
            }
        }

        public static void EncodeData(byte[] compressedData)
        {
            for (int i = 0; i < compressedData.Length; i++)
            {
                compressedData[i] = tableInverse[compressedData[i]];
            }
        }

    }
}
