using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace ExFile
{
    static class EncodingDetector
    {
        public static Encoding DetectEncoding(string fileName)
        {
            var utf8 = new UTF8Encoding(true, true);
            var shiftJis = Encoding.GetEncoding("shift-jis", EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
            var ascii = Encoding.GetEncoding("ascii", EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
            var asciiDecoder = ascii.GetDecoder();
            var utf8Decoder = utf8.GetDecoder();
            var shiftJisDecoder = shiftJis.GetDecoder();

            //bool hasBom = false;

            using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                byte[] first2Bytes = new byte[2];
                fs.Read(first2Bytes, 0, 2);
                fs.Position = 0;

                if (first2Bytes[0] == 0xFF && first2Bytes[1] == 0xFE)
                {
                    return new UnicodeEncoding(false, true, true);
                }
                else if (first2Bytes[0] == 0xFE && first2Bytes[1] == 0xFF)
                {
                    return new UnicodeEncoding(true, true, true);
                }

                //byte[] first3Bytes = new byte[3];
                //fs.Read(first3Bytes, 0, 3);
                //fs.Position = 0;
                //if (first3Bytes[0] == 0xEF && first3Bytes[1] == 0xBB && first3Bytes[2] == 0xBF)
                //{
                //    hasBom = true;
                //}

                long length = fs.Length;
                int readSize = 4096;
                byte[] bytes = null;
                while (true)
                {
                    if (length - fs.Position < readSize)
                    {
                        readSize = (int)(length - fs.Position);
                        bytes = new byte[readSize];
                    }
                    else
                    {
                        if (bytes == null)
                        {
                            bytes = new byte[readSize];
                        }
                    }

                    if (bytes.Length == 0)
                    {
                        return utf8;
                    }

                    fs.Read(bytes, 0, readSize);

                    bool asciiOnly = true;

                    for (int i = 0; i < bytes.Length; i++)
                    {
                        if (bytes[i] >= 0x80)
                        {
                            asciiOnly = false;
                            break;
                        }
                    }

                    if (asciiOnly)
                    {
                        //had no characters outside of ASCII range
                        continue;
                    }

                    int utf8CharacterCount;
                    try
                    {
                        utf8CharacterCount = utf8Decoder.GetCharCount(bytes, 0, bytes.Length, false);
                    }
                    catch (DecoderFallbackException)
                    {
                        utf8CharacterCount = -1;
                    }

                    int shiftJisCharacterCount;
                    try
                    {
                        shiftJisCharacterCount = shiftJisDecoder.GetCharCount(bytes, 0, bytes.Length, false);
                    }
                    catch (DecoderFallbackException)
                    {
                        shiftJisCharacterCount = -1;
                    }

                    if (shiftJisCharacterCount > 0 && utf8CharacterCount == -1)
                    {
                        shiftJis.DecoderFallback = DecoderFallback.ReplacementFallback;
                        shiftJis.EncoderFallback = EncoderFallback.ReplacementFallback;
                        return shiftJis;
                    }
                    if (utf8CharacterCount > 0 && shiftJisCharacterCount == -1)
                    {
                        return new UTF8Encoding(false, false);
                        return utf8;
                    }
                    0.GetHashCode();
                    {
                        shiftJis.DecoderFallback = DecoderFallback.ReplacementFallback;
                        shiftJis.EncoderFallback = EncoderFallback.ReplacementFallback;
                        return shiftJis;
                    }
                }
            }
        }
    }
}
