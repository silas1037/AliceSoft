using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace ExFile
{
    public static class Util
    {
        static Encoding shiftJis = Encoding.GetEncoding("shift-jis");
        public static string[] GetStrings(byte[] bytes, int startAddress, int endAddress)
        {
            List<string> strings = new List<string>();
            int address = startAddress;
            while (address < endAddress - 4)
            {
                int desiredStringLength = BitConverter.ToInt32(bytes, address);
                address += 4;
                if (desiredStringLength >= 2 && ((desiredStringLength & 3) == 0) && desiredStringLength < 4096)
                {
                    int numberOfValidBytes = TextConverter.NumberOfValidBytesAtPosition(bytes, address);
                    if (numberOfValidBytes >= 2)
                    {
                        int validBytesPadded = ((numberOfValidBytes - 1) | 3) + 1;
                        if (validBytesPadded > desiredStringLength)
                        {
                            validBytesPadded = desiredStringLength;
                            numberOfValidBytes = desiredStringLength;
                        }

                        if (validBytesPadded == desiredStringLength)
                        {
                            string str = shiftJis.GetString(bytes, address, numberOfValidBytes);
                            strings.Add(str);
                            address += validBytesPadded;
                        }
                        else if (validBytesPadded < desiredStringLength)
                        {

                        }
                    }
                }
            }
            return strings.ToArray();
        }

        public static string[] GetStrings(byte[] bytes)
        {
            return GetStrings(bytes, 0, bytes.Length);
        }

        public static string EscapeString(string stringToEscape)
        {
            bool quoteString = false;
            if (stringToEscape.Contains('"'))
            {
                quoteString = true;
            }

            if (stringToEscape == "")
            {
                return "\"\\\"\"\"";  // "\"""
            }

            int defaultCapacity = stringToEscape.Length;
            StringBuilder sb = new StringBuilder(defaultCapacity);

            if (quoteString)
            {
                sb.Append('"');
            }

            foreach (var c in stringToEscape)
            {
                if (c == '\r')
                {
                    sb.Append("\\r");
                }
                else if (c == '\n')
                {
                    sb.Append("\\n");
                }
                else if (c == '\t')
                {
                    sb.Append("\\t");
                }
                else if (c == '\\')
                {
                    sb.Append(@"\\");
                }
                else if (c == '"')
                {
                    sb.Append("\"\"");
                }
                else
                {
                    sb.Append(c);
                }
            }

            if (quoteString)
            {
                sb.Append('"');
            }

            return sb.ToString();
        }

        public static string UnescapeString(string stringToUnescape)
        {
            if (stringToUnescape.StartsWith("\"") && stringToUnescape.EndsWith("\"") && stringToUnescape.Length >= 2)
            {
                stringToUnescape = stringToUnescape.Substring(1, stringToUnescape.Length - 2);
                stringToUnescape = stringToUnescape.Replace("\"\"", "\"");
            }

            if (stringToUnescape == "\\\"")
            {
                return "";
            }

            StringBuilder sb = new StringBuilder(16);
            StringReader sr = new StringReader(stringToUnescape);

            while (true)
            {
                int charInt = sr.Read();
                if (charInt == -1)
                {
                    break;
                }
                char c = (char)charInt;

                if (c == '\\')
                {
                    charInt = sr.Read();
                    if (charInt == -1)
                    {
                        break;
                    }
                    c = (char)charInt;
                    if (c == 'r')
                    {
                        c = '\r';
                    }
                    else if (c == 'n')
                    {
                        c = '\n';
                    }
                    else if (c == 't')
                    {
                        c = '\t';
                    }
                    //else if (c == '\r')
                    //{
                    //    charInt = sr.Peek();
                    //    if (charInt == '\n')
                    //    {
                    //        sr.Read();
                    //        continue;
                    //    }
                    //    continue;
                    //}
                    //else if (c == '\n')
                    //{
                    //    continue;
                    //}
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

        public static void SetOrAdd<T>(ref T[] arr, int index, T element)
        {
            if (index < 0)
            {
                throw new IndexOutOfRangeException();
            }
            if (index >= 0x1000000 && index >= arr.Length)
            {
                throw new ArgumentException("index is too big");
            }
            if (index >= arr.Length)
            {
                var newArr = new T[index + 1];
                Array.Copy(arr, newArr, arr.Length);
                newArr[index] = element;
                arr = newArr;
            }
            else
            {
                arr[index] = element;
            }
        }

        public static void SetOrAdd<T>(List<T> list, int index, T element)
        {
            if (index < 0)
            {
                throw new IndexOutOfRangeException();
            }
            if (index >= 0x1000000 && index >= list.Count)
            {
                throw new ArgumentException("index is too big");
            }
            if (index >= list.Count)
            {
                while (list.Count < index)
                {
                    list.Add(default(T));
                }
                list.Add(element);
            }
            else
            {
                list[index] = element;
            }
        }

        public static byte[] ReplaceStrings(byte[] bytes, string[] newStrings)
        {
            var originalStrings = GetStrings(bytes);
            if (newStrings.Length > originalStrings.Length)
            {
                newStrings = newStrings.Take(originalStrings.Length).ToArray();
            }

            if (newStrings.SequenceEqual(originalStrings))
            {
                return bytes;
            }

            MemoryStream outputStream = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(outputStream);

            int startAddress = 0;
            int endAddress = bytes.Length;

            int strIndex = 0;

            int address = startAddress;
            int lastWriteAddress = startAddress;
            while (address < endAddress - 4)
            {
                int desiredStringLength = BitConverter.ToInt32(bytes, address);
                address += 4;
                if (desiredStringLength >= 2 && ((desiredStringLength & 3) == 0) && desiredStringLength < 4096)
                {
                    int numberOfValidBytes = TextConverter.NumberOfValidBytesAtPosition(bytes, address);
                    if (numberOfValidBytes >= 2)
                    {
                        int validBytesPadded = ((numberOfValidBytes - 1) | 3) + 1;
                        if (validBytesPadded > desiredStringLength)
                        {
                            validBytesPadded = desiredStringLength;
                            numberOfValidBytes = desiredStringLength;
                        }

                        if (validBytesPadded == desiredStringLength)
                        {
                            //string originalStr = shiftJis.GetString(bytes, address, numberOfValidBytes);

                            string replacementStr = newStrings[strIndex];
                            strIndex++;

                            int catchUpAddress = address - 4;
                            //catch up
                            outputStream.Write(bytes, lastWriteAddress, catchUpAddress - lastWriteAddress);

                            bw.WriteLengthIndexedString(replacementStr);


                            address += validBytesPadded;
                            lastWriteAddress = address;
                        }
                    }
                }
            }
            outputStream.Write(bytes, lastWriteAddress, bytes.Length - lastWriteAddress);
            return outputStream.ToArray();


        }
    }
}
