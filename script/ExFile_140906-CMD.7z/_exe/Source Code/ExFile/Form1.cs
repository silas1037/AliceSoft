using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Windows.Forms;
using ZLibNet;
using System.Diagnostics;

namespace ExFile
{
    public partial class Form1 : Form
    {
        ExFile loadedFile = null;
        string loadedFileName
        {
            get
            {
                if (loadedFile != null)
                {
                    return loadedFile.FileName;
                }
                return null;
            }
        }

        DataSet loadedDataSet = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;

            var args = Environment.GetCommandLineArgs();
            if (args.Length > 1 && File.Exists(args[1]))
            {
                OpenFile(args[1]);
            }
        }

        private void LoadDataSet(DataSet dataSet)
        {
            dataGridView1.DataSource = dataSet;
            var tableNames = dataSet.Tables.Cast<DataTable>().Select(t => t.TableName).ToArray();
            listBox1.DataSource = tableNames;
            listBox1.SelectedIndex = 0;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tableName = listBox1.SelectedValue as string;
            SelectTable(tableName);
        }

        private void SelectTable(string tableName)
        {
            dataGridView1.DataMember = null;
            dataGridView1.DataMember = tableName;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                int i = column.Index;
                if (column.ValueType == typeof(int))
                {
                    column.ToolTipText = "int";
                }
                if (column.ValueType == typeof(float))
                {
                    column.ToolTipText = "float";
                }
                if (column.ValueType == typeof(string))
                {
                    column.ToolTipText = "string";
                }
                column.ToolTipText += " " + column.Name;
            }
            dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void OpenFile()
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "EX Files (*.ex)|*.ex|All Files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    OpenFile(openFileDialog.FileName);
                }
            }
        }

        private void OpenFile(string fileName)
        {
            if (!File.Exists(fileName))
            {
                return;
            }
            bool okay = false;

            if (Debugger.IsAttached)
            {
                this.loadedFile = new ExFile();
                this.loadedFile.ReadFile(fileName);
                okay = true;
            }
            else
            {
                try
                {
                    this.loadedFile = new ExFile();
                    this.loadedFile.ReadFile(fileName);
                    okay = true;
                }
                catch (InvalidDataException ex)
                {
                    MessageBox.Show("An exception occurred when loading a file:" + "\n" + ex.Message + "\n" +
                        "This usually means that the input file is corrupt, malformed, or otherwise unsupported." + "\n" +
                        "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show("An unauthorized access exception occurred when loading a file:" + "\n" + ex.Message + "\n" +
                        "Make sure you have permissions to read the file." + "\n" +
                        "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                catch (IOException ex)
                {
                    MessageBox.Show("An IO exception occurred when loading a file:" + "\n" + ex.Message + "\n" +
                        "Make sure filenames and directory names are okay, and your hard drive isn't broken." + "\n" +
                        "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An exception occurred when loading a file:" + "\n" + ex.Message + "\n" +
                        "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            if (!okay)
            {
                this.loadedFile = null;
                return;
            }
            this.loadedDataSet = this.loadedFile.ToDataSet(true);
            LoadDataSet(this.loadedDataSet);
        }

        private void exportToTXTFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportTextFiles();
        }

        private void ExportTextFiles()
        {
            if (String.IsNullOrEmpty(this.loadedFileName))
            {
                return;
            }
            string exportDirectory = PromptForExportDirectory();
            if (exportDirectory != null)
            {
                //check for overwriting files
                if (Directory.Exists(Path.Combine(exportDirectory, "tables")))
                {
                    var result = MessageBox.Show("Overwrite files?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                    if (result == DialogResult.No || result == DialogResult.Cancel)
                    {
                        return;
                    }
                }
                if (Debugger.IsAttached)
                {
                    loadedFile.ExportTables(exportDirectory);
                }
                else
                {
                    try
                    {
                        loadedFile.ExportTables(exportDirectory);
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        MessageBox.Show("An unauthorized access exception occurred when exporting text:" + "\n" + ex.Message + "\n" +
                            "Make sure you have write permissions to the directory." + "\n" +
                            "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show("An IO exception occurred when exporting text:" + "\n" + ex.Message + "\n" +
                            "Make sure filenames or directory names are okay, your hard drive isn't broken, and that you have enough disk space." + "\n" +
                            "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    catch (InvalidDataException ex)
                    {
                        MessageBox.Show("An exception occurred when exporting text:" + "\n" + ex.Message + "\n" +
                            "Something has gone screwy and the data was corrupt in memory?" + "\n" +
                            "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An exception occurred when exporting text:" + "\n" + ex.Message + "\n" +
                            "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
            }
        }

        private static string PromptForExportDirectory()
        {
            string exportDirectory = null;
            using (var saveFileDialog = new SaveFileDialog())
            {
                try
                {
                    saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                    saveFileDialog.OverwritePrompt = false;
                    saveFileDialog.FileName = "PICK A DIRECTORY TO EXPORT TO";
                    saveFileDialog.ValidateNames = false;
                    saveFileDialog.SupportMultiDottedExtensions = true;
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = saveFileDialog.FileName;
                        if (Directory.Exists(fileName))
                        {
                            exportDirectory = fileName;
                        }
                        else
                        {
                            fileName = Path.GetDirectoryName(fileName);
                            if (Directory.Exists(fileName))
                            {
                                exportDirectory = fileName;
                            }
                        }
                    }
                }
                catch
                {

                }
            }
            return exportDirectory;
        }

        private void importTXTFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImportTextFiles();
        }

        private void ImportTextFiles()
        {
            if (String.IsNullOrEmpty(this.loadedFileName))
            {
                return;
            }
            string importDirectory = PromptForImportDirectory();
            if (importDirectory != null)
            {
                bool success = loadedFile.ImportTables(importDirectory);
                if (!success)
                {
                    MessageBox.Show("No files imported!  Make sure you have specified the correct directory to import from.");
                }
                else
                {
                    bool okay = false;
                    if (Debugger.IsAttached)
                    {
                        ExTable.Warning += new EventHandler<ErrorEventArgs>(ExTable_Warning);
                        loadedFile.SaveFile();
                        ExTable.Warning -= new EventHandler<ErrorEventArgs>(ExTable_Warning);
                        okay = true;
                    }
                    else
                    {

                        try
                        {
                            ExTable.Warning += new EventHandler<ErrorEventArgs>(ExTable_Warning);
                            loadedFile.SaveFile();
                            okay = true;
                        }
                        catch (UnauthorizedAccessException ex)
                        {
                            MessageBox.Show("An unauthorized access exception occurred when importing text:" + "\n" + ex.Message + "\n" +
                                "Make sure you have read permissions for the text, or write permissions for the EX file." + "\n" +
                                "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        catch (IOException ex)
                        {
                            MessageBox.Show("An IO exception occurred when importing text:" + "\n" + ex.Message + "\n" +
                                "Make sure filenames or directory names are okay, your hard drive isn't broken, and that you have enough disk space." + "\n" +
                                "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        catch (InvalidDataException ex)
                        {
                            MessageBox.Show("An exception occurred when importing text:" + "\n" + ex.Message + "\n" +
                                "Maybe there are errors in the text files?" + "\n" +
                                "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An exception occurred when importing text:" + "\n" + ex.Message + "\n" +
                                "Function: " + ex.TargetSite.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        finally
                        {
                            ExTable.Warning -= new EventHandler<ErrorEventArgs>(ExTable_Warning);
                        }
                    }

                    if (!okay)
                    {
                        return;
                    }
                    this.loadedDataSet = loadedFile.ToDataSet(true);
                    LoadDataSet(this.loadedDataSet);
                }
            }
        }

        void ExTable_Warning(object sender, ErrorEventArgs e)
        {
            MessageBox.Show("Warning: " + e.GetException().Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private static string PromptForImportDirectory()
        {
            string importDirectory = null;
            using (var openFileDialog = new OpenFileDialog())
            {
                try
                {
                    openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                    openFileDialog.CheckFileExists = false;
                    openFileDialog.CheckPathExists = false;
                    openFileDialog.FileName = "PICK A DIRECTORY TO IMPORT FROM";
                    openFileDialog.ValidateNames = false;
                    openFileDialog.SupportMultiDottedExtensions = true;
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = openFileDialog.FileName;
                        if (Directory.Exists(fileName))
                        {
                            importDirectory = fileName;
                        }
                        else
                        {
                            fileName = Path.GetDirectoryName(fileName);
                            if (Directory.Exists(fileName))
                            {
                                importDirectory = fileName;
                            }
                        }
                    }
                }
                catch
                {

                }
            }
            if (importDirectory != null)
            {
                if (!Directory.Exists(Path.Combine(importDirectory, "tables")))
                {
                    if (Directory.Exists(Path.Combine(importDirectory, "..\\tables")))
                    {
                        importDirectory = Path.GetFullPath(Path.Combine(importDirectory, ".."));
                    }
                }
            }
            return importDirectory;
        }

        private void exportRAWFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.FileName = this.loadedFileName + "_";
                saveFileDialog.Filter = "EX_ Files (*.ex_)|*.ex_|All Files (*.*)|*.*";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    ExportRaw(saveFileDialog.FileName);
                }
            }
        }

        private void ExportRaw(string outputFileName)
        {
            if (String.IsNullOrEmpty(this.loadedFileName))
            {
                return;
            }
            var bytes = ExLoader.ReadExFile(this.loadedFileName);
            File.WriteAllBytes(outputFileName, bytes);
        }

        private void Form1_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false))
            {
                var files = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null)
                {
                    OpenFile(files[0]);
                }
            }
        }

        private void fileToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            bool enableItems = this.loadedFileName != null;

            this.exportRAWFileToolStripMenuItem.Enabled = enableItems;
            this.exportToTXTFilesToolStripMenuItem.Enabled = enableItems;
            this.importTXTFilesToolStripMenuItem.Enabled = enableItems;
        }

        string incomingClipboardText = "";

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex == -1)
                {
                    if (e.ColumnIndex >= 0 && e.ColumnIndex < this.dataGridView1.Columns.Count)
                    {
                        var column = this.dataGridView1.Columns[e.ColumnIndex];
                        incomingClipboardText = column.Name;
                    }
                }
                else if (e.RowIndex >= 0 && e.RowIndex < this.dataGridView1.Rows.Count)
                {
                    var row = this.dataGridView1.Rows[e.RowIndex];
                    if (e.ColumnIndex >= 0 && e.ColumnIndex < this.dataGridView1.Columns.Count)
                    {
                        var cell = row.Cells[e.ColumnIndex];
                        incomingClipboardText = cell.Value.ToString();
                    }
                }
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(incomingClipboardText);
            }
            catch
            {

            }
        }
    }
}
